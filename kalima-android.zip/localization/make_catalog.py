from pathlib import Path
import json,re
ROOT = Path(__file__).resolve().parents[1]
langs=['en','ar','ur','fa','tr','ru','fr']; tables={x:{} for x in langs}
for line in (ROOT / 'localization/catalog.tsv').read_text().splitlines():
 if not line.strip():continue
 row=line.split('|');assert len(row)==7,(len(row),row[0]);key=row[0]
 assert key not in tables['en'],key
 for lang,text in zip(langs,row):tables[lang][key]=text
aliases={
"The file couldn't be opened.":"Couldn't open that backup.","The backup couldn't be opened.":"Couldn't open that backup.","That file isn't a Kalima backup.":"This isn't a Kalima backup.",
"Kalima couldn't get an answer. Try again.":"The reply couldn't be read. Try again.","Kalima couldn't complete this request. Try again.":"The reply couldn't be read. Try again.",
"Kalima couldn't connect to its shared service. Try again later.":"Shared access is unavailable. Try later or add a personal key in Settings.",
"Shared access isn't available yet. Please contact the person who maintains Kalima, or add an optional personal Gemini key in Settings.":"Shared access is unavailable. Try later or add a personal key in Settings.",
"Kalima is temporarily unavailable. Try again later, or use an optional personal Gemini key in Settings.":"Shared access is unavailable. Try later or add a personal key in Settings.",
"Kalima's shared allowance is used up for now. Try again later, or add an optional personal Gemini key in Settings.":"Shared limit reached. Try later or use a personal key in Settings.",
"Kalima's connection needs to be restored. Open Advanced and restore the defaults.":"Restore the default server configuration under Advanced in Settings.",
"Your personal Gemini key isn't valid. Check it in Settings.":"Check your personal key in Settings, or switch it off to use shared access.",
"The request couldn't be completed. Try again, or turn off your personal key in Settings.":"Check your personal key in Settings, or switch it off to use shared access.",
"This key can't be used here. Check it in Settings, or create a new one in AI Studio.":"Check your personal key in Settings, or switch it off to use shared access.",
"Your personal key couldn't complete this lookup. Turn it off in Settings to use Kalima's shared access, or restore the defaults under Advanced.":"Check your personal key in Settings, or switch it off to use shared access.",
}
for key,base in aliases.items():
 for lang in langs:tables[lang][key]=key if lang=='en' else tables[lang][base]
for lang in langs:tables[lang]['Kalima · 0.8']='Kalima · 0.8'
p=(ROOT / 'app/src/main/assets/ui-translations.json');p.write_text(json.dumps(tables,ensure_ascii=False,indent=2))
print(len(tables['en']),'catalog entries in each of',len(langs),'languages')
# Native Android labels used by system UI follow the app/device locale where supported.
from xml.sax.saxutils import escape
for lang in langs:
 d=(ROOT / 'app/src/main/res')/('values' if lang=='en' else 'values-'+lang);d.mkdir(exist_ok=True)
 text=tables[lang]['Look up in Kalima'].replace("'","\\'")
 (d/'locale-strings.xml').write_text('<resources><string name="lookup_action">'+escape(text)+'</string></resources>')
