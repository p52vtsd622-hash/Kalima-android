# Build and distribute Kalima 0.9 through GitHub

1. Download the supplied **kalima-android.zip** and **build.yml**. Keep the ZIP zipped and its exact filename (remove any download suffix such as `(1)`).
2. In your existing Kalima Android repository, open its build workflow under **.github/workflows**. Replace its contents with **build.yml** and commit. Keep just one active Kalima build workflow. This new workflow is needed for OTA updates; the old workflow only published an APK.
3. Upload **kalima-android.zip** to the repository root, replacing the previous ZIP, and commit. If the interim workflow-change run used the old ZIP and failed, use the newer run triggered by the ZIP upload.
4. Keep these existing Actions secrets unchanged: **KALIMA_KEYSTORE_BASE64**, **KALIMA_KEYSTORE_PASSWORD**, **KALIMA_KEY_ALIAS**, **KALIMA_KEY_PASSWORD**. Do not upload the private signing backup. No new secret or GitHub token is required.
5. Your release downloads must be **public** for friends to use in-app updates without signing in. If the repository is private, the workflow keeps the APK as a run artifact but stops public-release publishing with an explanation. Tell the developer if you need a separate public release repository.
6. Open **Actions > Build Kalima APK**. After both files are replaced, the latest run builds 0.9, runs checks and publishes **Kalima.apk**, a version-specific APK and **update.json** under Releases > latest. No manual editing of repository URLs or update metadata is needed.
7. People already on main 0.8 get Update/Later after the successful publication, when they next open or return to Kalima online. Anyone still on an older version needs **Kalima.apk** shared manually once. Install over existing main **Kalima**, without uninstalling or clearing storage. It does not replace **Kalima Test**.
8. For a later release, upload a project with a higher main version code. Friends reopening Kalima will see Update/Later. Update downloads the APK and asks Android to install it; Later waits until their next reopening. Settings > About > Check for updates also works. The first in-app install may need “Allow from this source” for Kalima.

The permanent signing certificate must remain SHA-256 b3015109ce8b212b6549381ef0b274b0954f22e382a064b06481135928b84500. If Android refuses an update, do not uninstall or generate another key to work around it; check the build, installed version and signing setup.

Before wider rollout, check 0.9 over an existing main 0.8 install: Update, Later/reopen, offline startup, interrupted download, permission approval and installer cancellation. No GitHub workflow or live OTA installation has been run from this workspace.
