# Set up Kalima once, then update it normally

The supplied Kalima.apk is version 0.6, named **Kalima**, with the original app identity. It is signed with the new permanent key in **Kalima-Private-Signing-Backup.zip**. Your old key was not saved in the provided workflow, so an update over your old installation is unlikely to be accepted. Future builds using this new key can update this installation normally.

## 1. Save your words first

Open your currently installed Kalima. Export a **JSON backup** of saved words and save it in your phone's Downloads or Files, outside the app. Check that the file exists and opens. If you used Kalima Preview, export its words too. Keep the account passcode or personal API key you use; those settings must be entered again after a reinstall.

## 2. Keep the permanent key privately

Download **Kalima-Private-Signing-Backup.zip** and keep a safe private copy. Extract it. On iPhone, tapping the ZIP in Files usually extracts it into a folder. Inside are the signing file and four text files. Do not upload this ZIP, its signing file or its text files to the public repository. The values go only into GitHub's Secrets settings.

## 3. Add four GitHub secrets once

Open https://github.com/p52vtsd622-hash/Kalima-android/settings/secrets/actions in your browser, signed into your GitHub account. Choose **New repository secret**. For each row below, enter the Name exactly as shown, open the matching text file, copy its entire contents into the Secret box, and tap **Add secret**.

| Name | Copy the contents of this file |
| --- | --- |
| KALIMA_KEYSTORE_BASE64 | KALIMA_KEYSTORE_BASE64.txt |
| KALIMA_KEYSTORE_PASSWORD | KALIMA_KEYSTORE_PASSWORD.txt |
| KALIMA_KEY_ALIAS | KALIMA_KEY_ALIAS.txt |
| KALIMA_KEY_PASSWORD | KALIMA_KEY_PASSWORD.txt |

You do not need to understand or change these values. Keep them the same for future updates.

## 4. Update your two public project files

Open your repository's existing build workflow under **.github/workflows**. Edit it and replace its contents with the supplied **build.yml**. Keep its existing filename; there should be one active Kalima build workflow. Commit the change.

Upload the updated project ZIP to the repository root with the exact name **kalima-android.zip**, replacing the old ZIP. If your phone downloaded it with `(2)` or another number, rename it before uploading. Keep it zipped.

Only the project ZIP and workflow belong in the public repository. The signing backup stays private.

GitHub will build automatically after these changes. Open **Actions → Build Kalima APK** to check progress. When it succeeds, the Releases page contains **Kalima.apk**, signed with the same key as the APK supplied here. If the intermediate workflow-change run fails because it used an older project ZIP, use the run triggered by uploading this updated ZIP.

## 5. Move to the new installation

After your saved-words backup is safe, download the supplied **Kalima.apk** on your Android phone and try installing it. If Android accepts it as an update, keep the existing installation. If Android refuses it because the signatures differ, uninstall your old Kalima, install this APK, then use **Import backup** to restore your words. Enter your account details again.

This is the one-time transition. Future APKs from the configured GitHub workflow use this key and can update this Kalima installation without uninstalling it. Each future project version must have a higher version number. Updates are installed by downloading and tapping the new APK; the app does not install them automatically.

Kalima Preview, if installed, is separate. After exporting and importing any words you saved there, you can remove Preview if you wish.

## For future work on this app

Keep name **Kalima**, application ID **app.kalima**, and this permanent signing key. Increase versionCode for each distributed update (this build is 6). Never generate another signing key for ordinary updates. The private ZIP is the key backup. The main project ZIP contains no private signing credentials.

GitHub secret setup follows the official guide: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets
