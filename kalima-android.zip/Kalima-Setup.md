# Update Kalima through GitHub

1. Upload the supplied project ZIP to your repository root, replacing **kalima-android.zip**. Keep that exact filename, without (1) or other suffixes. Do not unzip it on GitHub.
2. Keep the existing working build workflow and the four KALIMA signing secrets unchanged. A reference copy of the corrected workflow is inside this project.
3. GitHub Actions builds and tests version 0.7. When the run succeeds, download Kalima.apk from Releases and install it as an update. Keep the permanent signing key; do not generate another one.

## Before sharing version 0.7

The app no longer asks for or sends a class passcode. If your Cloudflare Worker still requires it, the Worker must be updated first. Supply the current Worker code so its passcode check can be removed while retaining Gemini/Groq and the existing limits. Do not send your provider keys or their secret values.

Ordinary users will then install and start looking up words. Personal Gemini keys remain optional in Settings; saving one enables it and a switch lets a user return to shared access while keeping their key saved.

Model and server configuration are hidden under Advanced. Saved words and review progress remain in the existing app storage.

No installable APK is included in this ZIP. This version's build and test status is recorded in VALIDATION.md; the GitHub run provides the build verification.
