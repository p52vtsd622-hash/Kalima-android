plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.kalima"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.kalima"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "0.6"
        manifestPlaceholders["appLabel"] = "Kalima"
    }

    val signingPath = providers.environmentVariable("KALIMA_KEYSTORE_PATH").orNull
    val signingPassword = providers.environmentVariable("KALIMA_KEYSTORE_PASSWORD").orNull
    val signingAlias = providers.environmentVariable("KALIMA_KEY_ALIAS").orNull
    val signingKeyPassword = providers.environmentVariable("KALIMA_KEY_PASSWORD").orNull
    val signingValues = listOf(signingPath, signingPassword, signingAlias, signingKeyPassword)
    val hasSigning = signingValues.all { !it.isNullOrBlank() }
    require(signingValues.all { it.isNullOrBlank() } || hasSigning) {
        "Supply all four KALIMA signing settings. See START-HERE.md."
    }
    require(providers.environmentVariable("CI").orNull != "true" || hasSigning) {
        "Kalima updates need the same saved signing key. Install the supplied GitHub workflow and signing secrets; see START-HERE.md."
    }
    if (hasSigning) {
        signingConfigs.create("kalima") {
            storeFile = file(signingPath!!)
            storePassword = signingPassword
            keyAlias = signingAlias
            keyPassword = signingKeyPassword
        }
    }

    buildTypes {
        debug {
            if (hasSigning) signingConfig = signingConfigs.getByName("kalima")
        }
        release {
            isMinifyEnabled = false
            if (hasSigning) signingConfig = signingConfigs.getByName("kalima")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
