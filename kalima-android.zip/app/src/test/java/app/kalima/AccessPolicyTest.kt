package app.kalima

import org.junit.Assert.*
import org.junit.Test

class AccessPolicyTest {
    @Test fun freshInstallCanUseSharedAccessWithoutCredentials() {
        assertTrue(AccessPolicy.useShared("shared", ""))
        assertTrue(AccessPolicy.hasAccess("shared", "", Config.DEFAULT_PROXY))
    }
    @Test fun personalChoiceWithoutKeyFallsBackToShared() {
        assertTrue(AccessPolicy.useShared("own", ""))
        assertTrue(AccessPolicy.hasAccess("own", "   ", Config.DEFAULT_PROXY))
    }
    @Test fun enabledPersonalKeyUsesPersonalAccess() {
        assertFalse(AccessPolicy.useShared("own", "personal-key"))
        assertTrue(AccessPolicy.hasAccess("own", "personal-key", ""))
    }
    @Test fun disabledPersonalKeyStaysSavedWithoutBeingUsed() {
        assertTrue(AccessPolicy.useShared("shared", "personal-key"))
    }
    @Test fun sharedAccessStillNeedsServerAddress() {
        assertFalse(AccessPolicy.hasAccess("shared", "personal-key", ""))
    }
    @Test fun sharedLimitExplainsOptionalKeyWithoutNamingModel() {
        val message = Gemini.friendly(ApiError("http_429"), true)
        assertTrue(message.contains("personal Gemini key"))
        assertFalse(message.contains("gemini-2.5"))
    }
    @Test fun sharedErrorsDoNotExposeProviderDetails() {
        val message = Gemini.friendly(ApiError("http_502", "Groq internal upstream model details"), true)
        assertFalse(message.contains("Groq"))
        assertFalse(message.contains("model"))
    }
}
