package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ConjugationPresentationTest {
    @Test fun missingPersonsRetainFourteenPositions() {
        val rows = ConjugationPresentation.rows(JSONArray(), 0, "past")
        assertEquals(14, rows.size)
        assertTrue(rows.all { it.size == 7 && it.all { f -> f.text == "—" && !f.canListen && !f.matched } })
    }
    @Test fun allTensesMapToTheirOwnHeaderWithoutShiftingPersons() {
        val names = listOf("past", "present", "subjunctive", "jussive", "imperative", "passivePast", "passivePresent")
        val data = JSONArray()
        repeat(14) { i -> data.put(JSONObject().also { row -> names.forEach { row.put(it, "$i:$it") } }) }
        val rows = ConjugationPresentation.rows(data, 13, "passivePresent")
        names.forEachIndexed { col, name -> repeat(14) { i -> assertEquals("$i:$name", rows[i][col].text) } }
        assertTrue(rows[13][6].matched)
        assertEquals(1, rows.flatten().count { it.matched })
    }
    @Test fun invalidValuesCannotBeSpokenOrHighlighted() {
        val row = JSONObject().put("past", JSONObject.NULL).put("present", "null").put("subjunctive", 12)
            .put("jussive", "  ").put("imperative", JSONObject()).put("passivePast", false).put("passivePresent", "—")
        val forms = ConjugationPresentation.rows(JSONArray().put(row), 0, "past")[0]
        assertTrue(forms.all { it.text == "—" && !it.canListen && !it.matched })
    }
    @Test fun formsKeepVowelsAndTrimOnlySurroundingWhitespace() {
        val forms = ConjugationPresentation.rows(JSONArray().put(JSONObject().put("past", "  كَتَبَ  ")), 0, "past")[0]
        assertEquals("كَتَبَ", forms[0].text)
        assertTrue(forms[0].canListen)
        assertTrue(forms[0].matched)
    }
    @Test fun outOfRangeOrUnknownMatchDoesNotHighlightAnUnrelatedForm() {
        val data = JSONArray().put(JSONObject().put("past", "كَتَبَ"))
        assertTrue(ConjugationPresentation.rows(data, 14, "past").flatten().none { it.matched })
        assertTrue(ConjugationPresentation.rows(data, 0, "unknown").flatten().none { it.matched })
    }
    @Test fun malformedPersonDoesNotShiftTheNextPersonsForms() {
        val data = JSONArray().put("broken").put(JSONObject().put("past", "كَتَبَا"))
        val rows = ConjugationPresentation.rows(data, 1, "past")
        assertEquals("—", rows[0][0].text)
        assertEquals("كَتَبَا", rows[1][0].text)
        assertTrue(rows[1][0].matched)
    }
}
