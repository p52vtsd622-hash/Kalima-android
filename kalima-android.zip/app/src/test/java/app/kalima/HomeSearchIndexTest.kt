package app.kalima

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class HomeSearchIndexTest {
    private fun entry(id: String, meaning: String = "book") = JSONObject().put("id", id).put("box", 4).put("due", 123L)
        .put("data", JSONObject().put("word", id).put("transliteration", "kitāb").put("meaning", JSONObject().put("en", meaning)))
    @Test fun arabicVowelsTatweelAndAlefVariantsMatchWithoutChangingDisplay() {
        val row = entry("إِسْلَامٌ")
        val result = HomeSearchIndex.search(HomeSearchIndex.build(listOf(row)), "اِسْـلا")
        assertEquals("إِسْلَامٌ", result.single().arabic)
    }
    @Test fun distinctVocalizedWordsAreNotMergedByTheSearchKey() {
        val index = HomeSearchIndex.build(listOf(entry("كَتَبَ", "write"), entry("كُتُبٌ", "books")))
        assertEquals(listOf("كَتَبَ", "كُتُبٌ"), HomeSearchIndex.search(index, "كتب").map { it.id })
    }
    @Test fun frenchAccentsAndCaseMatchCachedTranslations() {
        val row = entry("كَتَبَ").also { it.getJSONObject("data").put("trans", JSONObject().put("fr", JSONObject().put("meaning", "Écrire une lettre"))) }
        assertEquals(1, HomeSearchIndex.search(HomeSearchIndex.build(listOf(row)), "ECRIRE").size)
    }
    @Test fun persianLettersAndInvisibleFormattingNormalizeForArabicMatching() {
        assertEquals(HomeSearchIndex.normalize("كتاب"), HomeSearchIndex.normalize("کِـتَاب"))
        assertEquals(HomeSearchIndex.normalize("عربي"), HomeSearchIndex.normalize("عَرَبِی\u200c"))
    }
    @Test fun exactAndPrefixWordMatchesRankBeforeDefinitionMatches() {
        val rows = listOf(entry("قَلَمٌ", "كتب and pens"), entry("كَتَبُوا"), entry("كُتُبٌ"))
        val result = HomeSearchIndex.search(HomeSearchIndex.build(rows), "كتب")
        assertEquals("كُتُبٌ", result.first().id)
        assertEquals("كَتَبُوا", result[1].id)
        assertEquals("قَلَمٌ", result.last().id)
    }
    @Test fun blankQueriesAndZeroLimitsDoNotReturnAnEntireDictionary() {
        val index = HomeSearchIndex.build(listOf(entry("كِتَابٌ")))
        assertTrue(HomeSearchIndex.search(index, "   ").isEmpty())
        assertTrue(HomeSearchIndex.search(index, "book", 0).isEmpty())
    }
    @Test fun invalidRowsAndNonTextFieldsAreNotSearchMaterial() {
        val row = entry("كِتَابٌ").also { it.getJSONObject("data").put("trans", JSONObject().put("fr", "malformed")) }
        val index = HomeSearchIndex.build(listOf(JSONObject().put("id", "bad"), JSONObject().put("data", JSONObject()), row))
        assertEquals(1, index.size)
        assertTrue(HomeSearchIndex.search(index, "malformed").isEmpty())
        assertTrue(HomeSearchIndex.search(index, "meaning").isEmpty())
    }
    @Test fun searchDoesNotMutateStoredDataOrReviewProgress() {
        val row = entry("كِتَابٌ"); val before = row.toString()
        HomeSearchIndex.search(HomeSearchIndex.build(listOf(row)), "kitab")
        assertEquals(before, row.toString()); assertEquals(4, row.getInt("box")); assertEquals(123L, row.getLong("due"))
    }
    @Test fun resultsAreBoundedAndOnlyDuplicateIdentitiesAreRemoved() {
        val rows = (1..10).map { entry("word$it") }
        val index = HomeSearchIndex.build(rows + rows.first())
        assertEquals(10, index.size)
        assertEquals(6, HomeSearchIndex.search(index, "book").size)
    }
}
