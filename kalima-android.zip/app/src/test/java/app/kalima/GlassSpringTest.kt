package app.kalima

import org.junit.Assert.*
import org.junit.Test

class GlassSpringTest {
    @Test fun draggingChoosesNearestTabAndClampsAtEnds() {
        assertEquals(0, GlassSpring.nearest(-5f))
        assertEquals(0, GlassSpring.nearest(0.49f))
        assertEquals(1, GlassSpring.nearest(0.51f))
        assertEquals(2, GlassSpring.nearest(1.9f))
        assertEquals(3, GlassSpring.nearest(7f))
    }
    @Test fun lensSettlesAfterCrossingWholeBar() {
        var x = 0f; var v = 0f
        repeat(180) { val next = GlassSpring.advance(x, v, 3f, 1f / 60f); x = next.first; v = next.second }
        assertEquals(3f, x, 0.001f)
        assertEquals(0f, v, 0.001f)
    }
    @Test fun reversingDirectionSettlesWithoutInvalidNumbers() {
        var x = 0f; var v = 0f
        repeat(8) { val next = GlassSpring.advance(x, v, 3f, 1f / 60f); x = next.first; v = next.second }
        repeat(180) { val next = GlassSpring.advance(x, v, 0f, 1f / 60f); x = next.first; v = next.second }
        assertTrue(x.isFinite() && v.isFinite())
        assertEquals(0f, x, 0.001f)
    }
    @Test fun stalledFrameUsesBoundedIntegration() {
        assertEquals(GlassSpring.advance(0f, 0f, 3f, 0.032f), GlassSpring.advance(0f, 0f, 3f, 4f))
    }
}
