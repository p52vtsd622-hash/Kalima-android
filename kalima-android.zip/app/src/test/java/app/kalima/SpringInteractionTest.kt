package app.kalima
import org.junit.Assert.*
import org.junit.Test
class SpringInteractionTest {
    @Test fun reducedMotionSettlesAndClosesWithoutFrames() = kotlinx.coroutines.runBlocking {
        val state = SpringSheetState(); state.height = 600f; state.offset = 180f; state.reduced = true
        state.settle(0f, 200f); assertEquals(0f, state.offset, .001f)
        state.hide(); assertEquals(600f, state.offset, .001f)
        assertFalse(state.settling)
    }

    @Test fun sheetReversesWithoutResettingAndClampsAtRest() {
        val state = SpringSheetState()
        state.height = 600f; state.offset = 180f
        assertEquals(60f, state.drag(60f), .001f)
        assertEquals(-30f, state.drag(-30f), .001f)
        assertEquals(210f, state.offset, .001f)
        state.drag(-900f); assertEquals(0f, state.offset, .001f)
        state.drag(900f); assertEquals(600f, state.offset, .001f)
    }
    @Test fun closingSheetDoesNotAcceptASecondGesture() {
        val state = SpringSheetState(); state.height = 600f; state.offset = 300f; state.closing = true
        assertEquals(0f, state.drag(100f), .001f)
        assertEquals(300f, state.offset, .001f)
    }
    @Test fun releaseUsesDistanceAndDirection() {
        assertFalse(sheetShouldDismiss(100f, 600f, 0f))
        assertTrue(sheetShouldDismiss(250f, 600f, 0f))
        assertTrue(sheetShouldDismiss(100f, 600f, 1400f))
        assertFalse(sheetShouldDismiss(250f, 600f, -1400f))
    }
    @Test fun navigationRetainsBoundedReleaseVelocityWithoutMoving() {
        val motion = GlassMotion(0f); motion.beginDrag(0L); motion.dragTo(1.25f, 16L)
        motion.endDrag()
        assertEquals(1.25f, motion.position, .001f)
        assertEquals(4f, motion.velocity, .001f)
    }
}
