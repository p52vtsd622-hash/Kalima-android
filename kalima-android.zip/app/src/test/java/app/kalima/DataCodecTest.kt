package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class DataCodecTest {
    private fun word() = JSONObject("""{"word":"كَتَبَ","meaning":{"en":"to write","ar":"خَطَّ"},"root":["ك","ت","ب"],"verb":{"dictionaryForm":"كَتَبَ","conjugation":[]},"examples":[{"ar":"كَتَبَ","en":"He wrote"}],"synonyms":[],"antonyms":[]}""")
    private fun entry() = JSONObject().put("id", "كَتَبَ").put("addedAt", 123L).put("box", 4).put("due", 987654L).put("data", word())
    private fun table() = JSONArray().also { a -> repeat(14) { a.put(JSONObject().put("past", "كَتَبَ")) } }

    @Test fun acceptsWebBackupAndPreservesProgress() {
        val e = entry(); e.remove("addedAt"); e.put("added", 321)
        val text = JSONObject().put("app", "kalima").put("version", 1).put("words", JSONArray().put(e)).toString()
        val decoded = DataCodec.decodeBackup(text).single()
        assertEquals(321L, decoded.getLong("addedAt")); assertEquals(4, decoded.getInt("box")); assertEquals(987654L, decoded.getLong("due"))
    }
    @Test fun movesOldAndroidConjugationsInsideWord() {
        val e = entry().put("conjs", table())
        val decoded = DataCodec.decodeBackup(JSONArray().put(e).toString()).single()
        assertFalse(decoded.has("conjs"))
        assertEquals(14, decoded.getJSONObject("data").getJSONObject("verb").getJSONArray("conjugation").length())
        assertEquals("كَتَبَ", Word.fromJson(decoded.getJSONObject("data")).verb!!.past[0])
    }
    @Test fun recordsKnownLanguageAndDoesNotRelabelItOnSwitch() {
        val d = word(); d.getJSONObject("meaning").put("tx", "لکھنا")
        d.getJSONArray("examples").getJSONObject(0).put("tx", "اس نے لکھا")
        val migrated = DataCodec.normalizeData(d, "ur")
        assertEquals("لکھنا", Word.fromJson(migrated, "ur").meaningTx)
        assertEquals("اس نے لکھا", Word.fromJson(migrated, "ur").examples[0].tx)
        assertEquals("", Word.fromJson(migrated, "fa").meaningTx)
        assertFalse(migrated.getJSONObject("meaning").has("tx"))
    }
    @Test fun doesNotGuessLanguageOfOldAndroidTranslation() {
        val d = word(); d.getJSONObject("meaning").put("tx", "نوشتن")
        val migrated = DataCodec.normalizeData(d)
        assertEquals("نوشتن", migrated.getJSONObject("trans").getJSONObject("legacy").getString("meaning"))
        assertEquals("", Word.fromJson(migrated, "ur").meaningTx)
    }
    @Test fun acceptsLegacyUrduWebFields() {
        val d = word(); d.getJSONObject("meaning").put("ur", "لکھنا"); d.put("rootGlossUr", "لکھنا")
        val migrated = DataCodec.normalizeData(d)
        assertEquals("لکھنا", Word.fromJson(migrated, "ur").meaningTx)
        assertEquals("لکھنا", Word.fromJson(migrated, "ur").rootGlossTx)
    }
    @Test fun enrichesDuplicateWithoutResettingProgressOrReplacingTranslation() {
        val old = entry(); val incoming = entry().put("box", 0).put("due", 0L).put("addedAt", 999L)
        old.getJSONObject("data").put("trans", JSONObject().put("ur", JSONObject().put("meaning", "original")))
        incoming.getJSONObject("data").put("trans", JSONObject().put("ur", JSONObject().put("meaning", "replacement")).put("fa", JSONObject().put("meaning", "نوشتن")))
        incoming.getJSONObject("data").getJSONObject("verb").put("conjugation", table())
        val merged = DataCodec.merge(old, incoming)
        assertEquals(4, merged.getInt("box")); assertEquals(987654L, merged.getLong("due")); assertEquals(123L, merged.getLong("addedAt"))
        assertEquals("original", Word.fromJson(merged.getJSONObject("data"), "ur").meaningTx)
        assertEquals("نوشتن", Word.fromJson(merged.getJSONObject("data"), "fa").meaningTx)
        assertEquals(14, merged.getJSONObject("data").getJSONObject("verb").getJSONArray("conjugation").length())
        assertFalse(old.getJSONObject("data").getJSONObject("trans").has("fa"))
    }
    @Test fun exportRoundTripRetainsTranslationsExtrasAndProgress() {
        val e = entry(); e.getJSONObject("data").put("trans", JSONObject().put("ru", JSONObject().put("meaning", "писать")))
        e.getJSONObject("data").put("extras", JSONObject().put("rootWords_ru", JSONArray().put(JSONObject().put("ar", "كِتَابٌ"))))
        val restored = DataCodec.decodeBackup(DataCodec.export(listOf(e))).single()
        assertEquals(4, restored.getInt("box")); assertEquals("писать", Word.fromJson(restored.getJSONObject("data"), "ru").meaningTx)
        assertEquals(1, restored.getJSONObject("data").getJSONObject("extras").getJSONArray("rootWords_ru").length())
    }
    @Test fun malformedWordRejectsWholeBackup() {
        try { DataCodec.decodeBackup(JSONArray().put(entry()).put(JSONObject().put("id", "invalid")).toString()); fail("Must reject invalid record") }
        catch (_: IllegalArgumentException) { }
    }
    @Test fun csvHasUtf8MarkerAndEscapesQuotes() {
        val e = entry(); e.getJSONObject("data").getJSONObject("meaning").put("en", "write, \"record\"")
        val csv = DataCodec.csv(listOf(e)); assertTrue(csv.startsWith("\uFEFF")); assertTrue(csv.contains("\"write, \"\"record\"\"\"")); assertTrue(csv.contains("كَتَبَ"))
    }
    @Test fun fastPromptDoesNotRequestRelatedArraysInSchema() {
        val p = Prompts.lookup("كتب", "ur", "fast")
        assertTrue(p.contains("\"forms\": []")); assertTrue(p.contains("\"synonyms\": []")); assertTrue(p.contains("\"antonyms\": []"))
        assertFalse(p.contains("\"forms\": [\""))
    }
    @Test fun correctReviewAdvancesAndMissedReviewResets() {
        val e = entry().put("box", 2)
        val correct = gradeEntry(e, true); assertEquals(3, correct.getInt("box")); assertTrue(correct.getLong("due") > System.currentTimeMillis())
        assertEquals(0, gradeEntry(e, false).getInt("box")); assertEquals(2, e.getInt("box"))
    }
    @Test fun duplicateTranslationCannotMoveOntoDifferentExamples() {
        val old = entry(); val incoming = entry()
        incoming.getJSONObject("data").getJSONArray("examples").getJSONObject(0).put("en", "A different sentence")
        incoming.getJSONObject("data").put("trans", JSONObject().put("fa", JSONObject().put("meaning", "نوشتن").put("examples", JSONArray().put("Different translation"))))
        val merged = DataCodec.merge(old, incoming)
        assertEquals("", Word.fromJson(merged.getJSONObject("data"), "fa").examples[0].tx)
        assertEquals("نوشتن", Word.fromJson(merged.getJSONObject("data"), "fa").meaningTx)
    }
    @Test fun duplicateTranslationCannotReplaceAnotherSense() {
        val old = entry(); val incoming = entry()
        incoming.getJSONObject("data").getJSONObject("meaning").put("en", "a different sense")
        incoming.getJSONObject("data").put("trans", JSONObject().put("fa", JSONObject().put("meaning", "Different sense translation")))
        assertEquals("", Word.fromJson(DataCodec.merge(old, incoming).getJSONObject("data"), "fa").meaningTx)
    }

}
