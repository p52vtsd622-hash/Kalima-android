package app.kalima

import org.junit.Assert.*
import org.junit.Test

class FlashcardSwipeTest {
    @Test fun frontSideNeverGrades() {
        assertNull(FlashcardSwipe.grade(600f, 300f, false))
        assertNull(FlashcardSwipe.grade(-600f, 300f, false))
    }
    @Test fun shortDragsReturnWithoutChangingProgress() {
        assertNull(FlashcardSwipe.grade(83f, 300f, true))
        assertNull(FlashcardSwipe.grade(-83f, 300f, true))
        assertNull(FlashcardSwipe.grade(0f, 300f, true))
    }
    @Test fun rightAndLeftMatchVisibleGradeLabels() {
        assertEquals(true, FlashcardSwipe.grade(84f, 300f, true))
        assertEquals(false, FlashcardSwipe.grade(-84f, 300f, true))
    }
    @Test fun thresholdScalesWithCardWidth() {
        assertNull(FlashcardSwipe.grade(100f, 500f, true))
        assertEquals(true, FlashcardSwipe.grade(141f, 500f, true))
    }
    @Test fun invalidLayoutOrCoordinatesCannotRecordAReview() {
        assertNull(FlashcardSwipe.grade(100f, 0f, true))
        assertNull(FlashcardSwipe.grade(Float.NaN, 300f, true))
        assertNull(FlashcardSwipe.grade(100f, Float.POSITIVE_INFINITY, true))
    }
}
