package app.kalima
import org.junit.Test
import org.junit.Assert.*
class SentenceHistoryTest {
 @Test fun historySurvivesSerializationWithoutDroppingVowelMarks(){
  val a=SentenceHistory.add(emptyList(),"كَتَبَ الطَّالِبُ")
  val b=SentenceHistory.add(a,"كُتِبَ الدَّرْسُ")
  assertEquals(b,SentenceHistory.decode(SentenceHistory.encode(b)))
 }
 @Test fun repeatedSentenceMovesToFrontAndStaysUnique(){
  val a=SentenceHistory.add(listOf("ذهب الطالب","كتب الطالب")," كتب الطالب ")
  assertEquals(listOf("كتب الطالب","ذهب الطالب"),a)
 }
 @Test fun boundsAndInvalidEntriesAreHandled(){
  val a=(0..80).map {"كتب الطالب $it"}
  assertEquals(60,SentenceHistory.decode(SentenceHistory.encode(a)).size)
  assertEquals(emptyList<String>(),SentenceHistory.add(emptyList(),"hello"))
  assertEquals(listOf("كتب الطالب"),SentenceHistory.decode("[null,3,\"hello\",\"كتب الطالب\"]"))
 }
}
