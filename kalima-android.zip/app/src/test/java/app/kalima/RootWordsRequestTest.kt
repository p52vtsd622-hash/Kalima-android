package app.kalima

import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class RootWordsRequestTest {
    private val root = listOf("ك", "ت", "ب")
    private fun row(ar: String = "كِتَابٌ", en: String = "book", main: String = "livre", tx: String = "کتاب") =
        JSONObject().put("ar", ar).put("en", en).put("main", main).put("tx", tx).put("partOfSpeech", "noun").put("wazn", "فِعَالٌ")
    private fun reply() = JSONObject().put("words", JSONArray().put(row())).toString()
    private fun parse(text: String, lang: String = "off", app: String = "en") = RootWordsReply.parse(text, "كَتَبَ", lang, app)
    private fun invalid(block: () -> Unit) {
        try { block(); fail("Expected invalid JSON") } catch (e: ApiError) { assertEquals("invalid_json", e.code) }
    }
    @Test fun canonicalReplyIsNormalizedWithoutDuplicatedLanguageRequests() {
        val a = parse(reply()).getJSONObject(0)
        assertEquals("book", a.getString("main")); assertEquals("", a.getString("tx"))
    }
    @Test fun acceptsBareArrays() { assertEquals("كِتَابٌ", parse(JSONArray().put(row()).toString()).getJSONObject(0).getString("ar")) }
    @Test fun acceptsFencesAndNestedResultWrappers() {
        val text = "Here are the words:\n```json\n" + JSONObject().put("data", JSONObject().put("results", JSONArray().put(row()))).toString() + "\n```\nDone."
        assertEquals(1, parse(text).length())
    }
    @Test fun acceptsJsonEncodedWordLists() {
        assertEquals(1, parse(JSONObject().put("words", JSONArray().put(row()).toString()).toString()).length())
    }
    @Test fun bracesAndEscapedQuotesInsideMeaningsDoNotBreakExtraction() {
        val r = row(en = "a {book} called \"Kitab\" [noun]")
        assertEquals(r.getString("en"), parse("Result: " + JSONObject().put("words", JSONArray().put(r))).getJSONObject(0).getString("en"))
    }
    @Test fun skipsSourceWordDuplicatesAndBrokenItemsWhileKeepingGoodOnes() {
        val a = JSONArray().put(row(ar = "كَتَبَ")).put(row()).put(row(ar = "كتاب")).put(9).put(JSONObject().put("ar", "مَكْتَبٌ"))
        assertEquals(1, parse(JSONObject().put("words", a).toString()).length())
    }
    @Test fun distinctVowelPatternsWithTheSameConsonantsArePreserved() {
        val rows = JSONArray().put(row(ar = "كَتَبَ", en = "he wrote")).put(row(ar = "كُتُبٌ", en = "books")).put(row(ar = "كُتِبَ", en = "it was written"))
        val reply = JSONObject().put("words", rows).toString()
        assertEquals(3, RootWordsReply.parse(reply, "كِتَابٌ", "off", "en").length())
        val withoutSource = parse(reply)
        assertEquals(2, withoutSource.length())
        assertEquals("كُتُبٌ", withoutSource.getJSONObject(0).getString("ar"))
    }
    @Test fun decorativeTatweelDoesNotCreateDuplicateEntries() {
        val rows = JSONArray().put(row()).put(row(ar = "كِتَـابٌ"))
        assertEquals(1, parse(JSONObject().put("words", rows).toString()).length())
    }
    @Test fun primaryAndExtraTranslationsAreRequiredWithoutEnglishFallback() {
        val good = row()
        val bad = row(ar = "مَكْتَبٌ").apply { remove("main") }
        val list = JSONObject().put("words", JSONArray().put(bad).put(good)).toString()
        assertEquals("livre", parse(list, "ur", "fr").getJSONObject(0).getString("main"))
        invalid { parse(JSONObject().put("words", JSONArray().put(bad)).toString(), "ur", "fr") }
        val missingExtra = row().apply { remove("tx") }
        invalid { parse(JSONObject().put("words", JSONArray().put(missingExtra)).toString(), "ur", "fr") }
        assertEquals("book", parse(reply(), "en", "fr").getJSONObject(0).getString("tx"))
    }
    @Test fun rejectsTruncatedJsonInsteadOfRecoveringPartialRows() {
        invalid { parse("{\"words\":[" + row().toString() + ",") }
        invalid { parse("{\"words\":[{\"ar\":\"كِتَابٌ\",\"en\":\"unfinished") }
    }
    @Test fun acceptsExplicitEmptyListButRejectsAnUnusableNonemptyList() {
        assertEquals(0, parse("{\"words\":[]}").length())
        invalid { parse("{\"words\":[{\"ar\":\"كِتَابٌ\"}]}") }
    }
    @Test fun promptOnlyRequestsNecessaryTranslationFields() {
        val en = Prompts.rootWords(root, "كَتَبَ", "off", "en")
        assertFalse(en.contains("\"main\"")); assertFalse(en.contains("\"tx\""))
        val french = Prompts.rootWords(root, "كَتَبَ", "ur", "fr")
        assertTrue(french.contains("\"main\"")); assertTrue(french.contains("\"tx\""))
        assertTrue(french.length < 8000)
    }
    @Test fun successfulRequestIsNotRetried() = runBlocking {
        var calls = 0
        val result = RootWordsRequest.load(root, "كَتَبَ", "off", "en", pause = { fail("Unexpected delay") }) { calls++; reply() }
        assertEquals(1, calls); assertEquals(1, result.length())
    }
    @Test fun unreadableRepliesRecoverWithAtMostTwoAdditionalAttempts() = runBlocking {
        val prompts = mutableListOf<String>(); val pauses = mutableListOf<Long>()
        val result = RootWordsRequest.load(root, "كَتَبَ", "off", "en", pause = { pauses.add(it) }) {
            prompts.add(it)
            when (prompts.size) { 1 -> "not JSON"; 2 -> ""; else -> reply() }
        }
        assertEquals(3, prompts.size); assertEquals(listOf(350L, 700L), pauses); assertEquals(1, result.length())
        assertTrue(prompts[1].contains("previous reply"))
    }
    @Test fun consistentlyInvalidRepliesStopAfterThreeAttempts() = runBlocking {
        var calls = 0; var pauses = 0
        try {
            RootWordsRequest.load(root, "كَتَبَ", "off", "en", pause = { pauses++ }) { calls++; "broken" }
            fail("Expected failure")
        } catch (e: ApiError) { assertEquals("invalid_json", e.code) }
        assertEquals(3, calls); assertEquals(2, pauses)
    }
    @Test fun authQuotaNetworkAndModelErrorsAreNeverAutomaticallyRetried() = runBlocking {
        for (code in listOf("http_401", "http_403", "http_429", "http_503", "network", "model")) {
            var calls = 0
            try {
                RootWordsRequest.load(root, "كَتَبَ", "off", "en", pause = { fail("Unexpected delay") }) { calls++; throw ApiError(code) }
                fail("Expected error")
            } catch (e: ApiError) { assertEquals(code, e.code) }
            assertEquals(1, calls)
        }
    }
    @Test fun cancellingDuringRecoveryPreventsAnotherRequest() = runBlocking {
        var calls = 0
        val waiting = CompletableDeferred<Unit>()
        val task = launch {
            RootWordsRequest.load(root, "كَتَبَ", "off", "en", pause = { waiting.complete(Unit); awaitCancellation() }) { calls++; "broken" }
        }
        waiting.await(); task.cancelAndJoin(); assertEquals(1, calls)
    }
}
