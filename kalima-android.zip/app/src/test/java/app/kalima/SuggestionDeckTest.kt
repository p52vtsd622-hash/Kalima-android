package app.kalima

import kotlin.random.Random
import org.junit.Assert.*
import org.junit.Test

class SuggestionDeckTest {
    @Test fun poolIsVocalizedUniqueAndVaried() {
        val words = SuggestionDeck.words
        assertEquals(90, words.size)
        assertEquals(90, words.map { it.arabic }.distinct().size)
        assertEquals(setOf("masdar", "noun", "verb"), words.map { it.kind }.toSet())
        assertTrue(words.all { word -> word.arabic.any { it in '\u064B'..'\u0652' } })
    }
    @Test fun reversingEitherDirectionRestoresEarlierWords() {
        val deck = SuggestionDeck(Random(42))
        val center = deck.at(0); val right = deck.at(1); val left = deck.at(-1)
        assertNotEquals(center, right); assertNotEquals(center, left); assertNotEquals(right, left)
        assertEquals(center, deck.at(0)); assertEquals(right, deck.at(1)); assertEquals(left, deck.at(-1))
    }
    @Test fun firstPoolDoesNotRepeatWhileBrowsing() {
        val deck = SuggestionDeck(Random(13))
        assertEquals(90, (0 until 90).map { deck.at(it) }.distinct().size)
    }
    @Test fun longTimelineKeepsHistoryAcrossPoolCycles() {
        val deck = SuggestionDeck(Random(8))
        val history = (-180..180).associateWith { deck.at(it) }
        history.entries.zipWithNext().forEach { (a,b) -> assertNotEquals(a.value,b.value) }
        history.keys.shuffled(Random(7)).forEach { assertEquals(history[it], deck.at(it)) }
    }
    @Test fun refreshChangesTheVisibleWordEvenAfterNeighborPrefetch() {
        val deck = SuggestionDeck(Random(6))
        repeat(100) {
            val visible = deck.at(8)
            deck.at(9); deck.at(7) // Pager may measure adjacent pages before refresh.
            deck.refresh(8)
            assertNotEquals(visible, deck.at(0))
        }
    }
    @Test fun hiddenRefreshesDoNotForgetTheLastActuallyDisplayedWord() {
        val deck = SuggestionDeck(Random(11))
        val visible = deck.at(0)
        repeat(100) {
            deck.refresh(lastVisibleWord = visible.arabic)
            assertNotEquals(visible, deck.at(0))
        }
    }
    @Test fun coldReopenAvoidsTheLastPersistedWord() {
        val previous = SuggestionDeck(Random(2)).at(0)
        repeat(100) { seed ->
            val next = SuggestionDeck(Random(seed), previous.arabic)
            next.refresh()
            assertNotEquals(previous, next.at(0))
        }
    }
    @Test fun repeatedHomeRefreshesNeverKeepTheCurrentWord() {
        val deck = SuggestionDeck(Random(12))
        repeat(100) {
            val old = deck.at(0); deck.refresh()
            assertNotEquals(old, deck.at(0)); assertEquals(deck.at(0), deck.at(0))
        }
    }
}
