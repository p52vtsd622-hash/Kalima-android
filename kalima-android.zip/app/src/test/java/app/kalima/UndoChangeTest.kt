package app.kalima

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class UndoChangeTest {
    private fun entry(word: String, added: Long = 1) = JSONObject().put("id", word).put("addedAt", added)
        .put("box", 4).put("due", 123456L).put("data", JSONObject().put("word", word)
            .put("trans", JSONObject().put("fr", JSONObject().put("meaning", "livre"))))
    @Test fun savedUndoPreservesReviewProgressAndTranslations() {
        val original = entry("كِتَابٌ")
        val restored = UndoChange.Saved(original).restore(emptyList()).single()
        assertEquals(original.toString(), restored.toString())
        assertEquals(4, restored.getInt("box"))
        assertEquals(123456L, restored.getLong("due"))
        assertEquals("livre", restored.getJSONObject("data").getJSONObject("trans").getJSONObject("fr").getString("meaning"))
    }
    @Test fun snapshotIsIndependentOfLaterSourceMutations() {
        val original = entry("كِتَابٌ")
        val change = UndoChange.Saved(original)
        original.put("box", 0).getJSONObject("data").put("word", "changed")
        val restored = change.restore(emptyList()).single()
        assertEquals(4, restored.getInt("box"))
        assertEquals("كِتَابٌ", restored.getJSONObject("data").getString("word"))
    }
    @Test fun undoDoesNotOverwriteAWordSavedAgainWithNewerProgress() {
        val change = UndoChange.Saved(entry("كِتَابٌ"))
        val newer = entry("كِتَابٌ", 9).put("box", 6)
        val restored = change.restore(listOf(newer))
        assertEquals(1, restored.size)
        assertEquals(6, restored.single().getInt("box"))
        assertEquals(9, restored.single().getLong("addedAt"))
    }
    @Test fun restoringMultipleWordsKeepsChronologyAndNewlySavedWords() {
        val a = UndoChange.Saved(entry("a", 20)); val b = UndoChange.Saved(entry("b", 30))
        val restored = a.restore(b.restore(listOf(entry("new", 40), entry("old", 10))))
        assertEquals(listOf("new", "b", "a", "old"), restored.map { it.str("id") })
    }
    @Test fun restoredObjectCannotMutateTheUndoSnapshot() {
        val change = UndoChange.Saved(entry("a"))
        change.restore(emptyList()).single().put("box", 0)
        assertEquals(4, change.restore(emptyList()).single().getInt("box"))
    }
    @Test fun historyUndoPreservesSearchesMadeSinceClearingAndRemovesDuplicates() {
        val restored = UndoChange.History(listOf("old1", "shared", "old2")).restore(listOf("new", "shared"))
        assertEquals(listOf("new", "shared", "old1", "old2"), restored)
    }
    @Test fun historyUndoKeepsTheExistingEightWordLimit() {
        val restored = UndoChange.History((1..8).map { "old$it" }).restore(listOf("new"))
        assertEquals(8, restored.size)
        assertEquals("new", restored.first())
        assertEquals("old7", restored.last())
    }
    @Test fun historySnapshotSurvivesSourceListClearingAndRetainsOriginalOrder() {
        val words = mutableListOf("a", "b", "c")
        val change = UndoChange.History(words)
        words.clear()
        assertEquals(listOf("a", "b", "c"), change.restore(emptyList()))
    }
}
