package app.kalima

import org.junit.Assert.*
import org.junit.Test

class SearchTest {
    @Test fun handlesUthmaniPrayerSpelling() {
        assertTrue(KalimaSearch.quranVariants("ٱلصَّلَوٰةَ").contains(KalimaSearch.baseNorm("الصلاة")))
    }
    @Test fun handlesAttachedPronounsAndPrefixes() {
        val index = KalimaSearch.buildIndex(listOf("وَبِكِتَابِهِ", "شَجَرَةٌ")) { KalimaSearch.standardVariants(it) }
        val matches = KalimaSearch.findMatches(index, listOf("كِتَاب"), listOf("كِتَاب"), emptyList(), false)
        assertEquals(1, matches.size); assertEquals(0, matches.single().u)
    }
    @Test fun verbsDoNotMatchNounsWithDefiniteArticle() {
        val index = KalimaSearch.buildIndex(listOf("الكتب", "كتب")) { KalimaSearch.standardVariants(it) }
        val matches = KalimaSearch.findMatches(index, emptyList(), listOf("كتب"), listOf("كتب"), true)
        assertEquals(1, matches.size); assertEquals(1, matches.single().u)
    }
    @Test fun exactMatchRanksBeforeRelatedForm() {
        val index = KalimaSearch.buildIndex(listOf("مكتوب", "كتاب")) { KalimaSearch.standardVariants(it) }
        val matches = KalimaSearch.rank(KalimaSearch.findMatches(index, listOf("مكتوب", "كتاب"), listOf("كتاب"), emptyList(), false), index)
        assertEquals(1, matches.first().u)
    }
}
