package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.File

class LocalizationTest {
    private lateinit var catalog: JSONObject
    @Before fun load() {
        val file = listOf(File("src/main/assets/ui-translations.json"), File("app/src/main/assets/ui-translations.json")).first { it.exists() }
        val text = file.readText(); catalog = JSONObject(text); Localization.loadCatalog(text)
    }
    private fun word() = JSONObject("""{"word":"كَتَبَ","partOfSpeech":"verb","grammarNote":"English grammar","rootGloss":"writing","wazn":{"note":"English pattern"},"note":"English note","meaning":{"en":"to write","ar":"خَطَّ"},"examples":[{"ar":"كَتَبَ","en":"He wrote"}],"synonyms":[],"antonyms":[],"trans":{"fr":{"meaning":"écrire","root":"écriture","partOfSpeech":"verbe","grammarNote":"grammaire française","waznNote":"schème français","note":"note française","inputPerson":"il","examples":["Il a écrit"],"synonyms":[],"antonyms":[]},"ur":{"meaning":"لکھنا","root":"لکھائی","examples":["اس نے لکھا"],"synonyms":[],"antonyms":[]}}}""")
    @Test fun everyInterfaceLanguageHasTheCompleteCatalog() {
        val keys = catalog.getJSONObject("en").keys().asSequence().toSet()
        assertTrue(keys.size >= 260)
        Localization.appLanguages.forEach { language ->
            val translated = catalog.getJSONObject(language)
            assertEquals(keys, translated.keys().asSequence().toSet())
            keys.forEach { key ->
                assertTrue("$language: $key", translated.getString(key).isNotBlank())
                assertEquals(Regex("\\{[0-9]+}").findAll(key).map { it.value }.toSet(), Regex("\\{[0-9]+}").findAll(translated.getString(key)).map { it.value }.toSet())
            }
        }
    }
    @Test fun settingsAndErrorMessagesTranslateOffline() {
        assertEquals("Réglages", Localization.text("Settings", "fr"))
        assertEquals("زبان برنامه", Localization.text("App language", "fa"))
        for (lang in Localization.appLanguages.filter { it != "en" }) assertNotEquals("The reply couldn't be read. Try again.", Localization.text("The reply couldn't be read. Try again.", lang))
    }
    @Test fun translatedTemplatesKeepValuesAndTranslateSectionNames() {
        assertEquals("Carte 2 sur 8", Localization.text("Card 2 of 8", "fr"))
        assertEquals("Développer : Synonymes", Localization.text("Expand Synonyms", "fr"))
    }
    @Test fun optionalTranslationExcludesArabicAndTheInterfaceLanguage() {
        for (lang in Localization.appLanguages) {
            assertFalse(Localization.extraLanguages(lang).contains("ar"))
            assertFalse(Localization.extraLanguages(lang).contains(lang))
        }
        assertTrue(Localization.extraLanguages("fr").contains("en"))
        assertTrue(Localization.extraLanguages("en").contains("fr"))
    }
    @Test fun frenchInterfaceWithUrduExtraProjectsTheRightContent() {
        val w = Word.fromJson(word(), "ur", "fr")
        assertEquals("écrire", w.meaningEn); assertEquals("لکھنا", w.meaningTx)
        assertEquals("Il a écrit", w.examples[0].en); assertEquals("اس نے لکھا", w.examples[0].tx)
        assertEquals("grammaire française", w.grammar); assertEquals("note française", w.note)
    }
    @Test fun englishCanBeTheExtraLanguageWithoutOverwritingFrench() {
        val w = Word.fromJson(word(), "en", "fr")
        assertEquals("écrire", w.meaningEn); assertEquals("to write", w.meaningTx)
        assertEquals("He wrote", w.examples[0].tx)
    }
    @Test fun arabicInterfaceDoesNotLeakCanonicalEnglish() {
        val w = Word.fromJson(word(), "off", "ar")
        assertEquals("خَطَّ", w.meaningEn); assertEquals("", w.examples[0].en)
        assertEquals("", w.grammar); assertEquals("", w.note); assertEquals("", w.rootGloss)
    }
    @Test fun missingLanguageNeverFallsBackToEnglishContent() {
        val w = Word.fromJson(word(), "off", "ru")
        assertEquals("Перевод ещё не загружен", w.meaningEn)
        assertEquals("", w.examples[0].en); assertEquals("", w.waznNote)
    }
    @Test fun projectionAndAddingLanguagesDoNotMutateCanonicalData() {
        val source = word(); val before = source.toString()
        Word.fromJson(source, "en", "fr"); Word.fromJson(source, "ur", "ar")
        assertEquals(before, source.toString())
        val e = JSONObject().put("id", "كَتَبَ").put("box", 4).put("due", 1234).put("addedAt", 77).put("data", source)
        val decoded = DataCodec.decodeBackup(DataCodec.export(listOf(e))).single()
        assertEquals(4, decoded.getInt("box")); assertEquals(1234, decoded.getInt("due"))
        assertEquals("écrire", decoded.getJSONObject("data").getJSONObject("trans").getJSONObject("fr").getString("meaning"))
    }
    @Test fun promptsRequestBothLanguagesAndRemainWithinServerLimit() {
        for (ui in Localization.appLanguages) for (extra in listOf("off") + Localization.extraLanguages(ui)) {
            val prompt = Prompts.lookup("كَتَبَ", extra, "deep", ui)
            assertTrue(prompt.length < 8000)
            if (ui !in listOf("en")) assertTrue(prompt.contains("\"$ui\":"))
            if (extra !in listOf("en", "off")) assertTrue(prompt.contains("\"$extra\":"))
        }
    }
    @Test fun rightToLeftIsIndependentFromOptionalTranslation() {
        assertTrue(Localization.isRtl("ar")); assertTrue(Localization.isRtl("ur")); assertTrue(Localization.isRtl("fa"))
        assertFalse(Localization.isRtl("fr")); assertFalse(Localization.isRtl("ru"))
    }
}
