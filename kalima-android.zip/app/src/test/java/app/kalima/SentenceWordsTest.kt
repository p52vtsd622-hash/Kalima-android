package app.kalima
import org.junit.Test
import org.junit.Assert.*
import org.json.JSONObject
import org.json.JSONArray
import kotlinx.coroutines.*

class SentenceWordsTest {
    private val sentence="ذهب الطالب"
    private fun reply(lang:String="en", parts:List<String> = listOf("ذَهَبَ","الطَّالِبُ"), meaning:String="went")=JSONObject().put("status","ok").put("language",lang)
        .put("items",JSONArray(parts.map {JSONObject().put("ar",it).put("transliteration","dhahaba").put("meaning",meaning)})).toString()
    private suspend fun waitFor(s:SentenceWordsSession){withTimeout(4000){while(s.loading)delay(10)}}
    private fun rejected(raw:String,lang:String="en") {try{SentenceWords.parse(raw,sentence,lang);fail()}catch(_:ApiError){}}
    @Test fun liveEnglishAndArabicFixturesCoverTheSameSentence(){
        for(lang in listOf("en","ar")){
            val raw=javaClass.getResource("/words-live-$lang.json")!!.readText()
            assertEquals(4,SentenceWords.parse(raw,"ذَهَبَ الطَّالِبُ إِلَى الْمَدْرَسَةِ.",lang).items.size)
        }
    }
    @Test fun editingTheSharedSentenceClearsWordResults()=runBlocking {
        val g=GrammarSession(this,{reply()},{"error"})
        g.edit(sentence);g.words.request(sentence,"en");waitFor(g.words)
        assertNotNull(g.words.result)
        g.edit("كتب الطالب");assertNull(g.words.result);assertNull(g.submitted)
    }
    @Test fun acceptsAddedVowelsAndContextualPhrases(){
        assertEquals(2,SentenceWords.parse(reply(),sentence,"en").items.size)
        assertEquals(1,SentenceWords.parse(reply(parts=listOf(sentence)),sentence,"en").items.size)
    }
    @Test fun rejectsMissingDuplicatedReorderedAndChangedWords(){
        rejected(reply(parts=listOf("ذهب")));rejected(reply(parts=listOf("الطالب","ذهب")))
        rejected(reply(parts=listOf("ذهب","الطالب","الطالب")));rejected(reply(parts=listOf("ذهب","الطبيب")))
    }
    @Test fun validatesLanguageAndScriptAndTransliteration(){
        rejected(reply("fr"));rejected(reply("ar",meaning="went"),"ar")
        assertEquals("ar",SentenceWords.parse(reply("ar",meaning="انتقل إلى مكان آخر"),sentence,"ar").language)
        assertEquals("ru",SentenceWords.parse(reply("ru",meaning="пошёл"),sentence,"ru").language)
        rejected(reply("ru",meaning="went"),"ru")
        val vowel=JSONObject(reply(parts=listOf("إِي"),meaning="yes"));vowel.getJSONArray("items").getJSONObject(0).put("transliteration","ī")
        assertEquals(1,SentenceWords.parse(vowel.toString(),"إي","en").items.size)
        val o=JSONObject(reply());o.getJSONArray("items").getJSONObject(0).put("transliteration","");rejected(o.toString())
    }
    @Test fun numeralsAndPunctuationKeepOriginalCoverage(){
        val o=JSONObject(reply(parts=listOf("ذهب","الطالب","٣")))
        o.getJSONArray("items").getJSONObject(2).put("transliteration","3").put("meaning","3")
        o.getJSONArray("items").put(JSONObject().put("ar",".").put("meaning","punctuation").put("transliteration","."))
        assertEquals(3,SentenceWords.parse(o.toString(),"ذهب الطالب ٣.","en").items.size)
        try {SentenceWords.parse(o.toString(),"ذهب الطالب ٤.","en");fail()}catch(_:ApiError){}
    }
    @Test fun promptsCoverAllLanguagesWithinBudget(){
        for(l in Localization.appLanguages){val p=SentenceWords.prompt("ذهب الطالب ".repeat(35).take(600),l);assertTrue(p.length<8000);assertTrue(p.contains("\"language\":\"$l\""))}
        assertTrue(SentenceWords.prompt(sentence,"ar").contains("simple Arabic explanations"))
    }
    @Test fun cachesEachLanguageAndSwitchingDoesNotRepeatRequests()=runBlocking {
        var count=0
        val s=SentenceWordsSession(this,{p->count++;if(p.contains("\"language\":\"fr\""))reply("fr",meaning="alla")else reply()},{"error"})
        s.request(sentence,"en");waitFor(s);assertEquals(1,count)
        s.request(sentence,"fr");waitFor(s);assertEquals(2,count);assertEquals("fr",s.result?.language)
        s.request(sentence,"en");assertEquals(2,count);assertEquals("en",s.result?.language)
        s.request(sentence,"en",true);waitFor(s);assertEquals(3,count)
    }
    @Test fun clearRejectsLateRepliesAndPreservesNoOldLanguage()=runBlocking {
        val start=CompletableDeferred<Unit>();val finish=CompletableDeferred<Unit>();val scope=CoroutineScope(SupervisorJob()+Dispatchers.Unconfined)
        try{
            val s=SentenceWordsSession(scope,{start.complete(Unit);withContext(NonCancellable){finish.await()};reply()},{"error"})
            s.request(sentence,"en");start.await();s.clear();finish.complete(Unit);delay(80)
            assertNull(s.result);assertNull(s.error);assertFalse(s.loading)
        }finally{scope.cancel()}
    }
    @Test fun lateEnglishReplyCannotReplaceFrench()=runBlocking {
        val start=CompletableDeferred<Unit>();val finish=CompletableDeferred<Unit>();val scope=CoroutineScope(SupervisorJob()+Dispatchers.Unconfined)
        try {
            val s=SentenceWordsSession(scope,{p ->
                if(p.contains("\"language\":\"en\"")){start.complete(Unit);withContext(NonCancellable){finish.await()};reply()}
                else reply("fr",meaning="alla")
            },{"error"})
            s.request(sentence,"en");start.await();s.request(sentence,"fr");waitFor(s)
            assertEquals("fr",s.result?.language);finish.complete(Unit);delay(80)
            assertEquals("fr",s.result?.language)
        } finally {scope.cancel()}
    }
    @Test fun retriesMalformedOnceButNotQuota()=runBlocking {
        var n=0;val s=SentenceWordsSession(this,{n++;"{}"},{"quota"})
        s.request(sentence,"en");waitFor(s);assertEquals(2,n);assertNull(s.result)
        n=0;val q=SentenceWordsSession(this,{n++;throw ApiError("http_429")},{"quota"})
        q.request(sentence,"en");waitFor(q);assertEquals(1,n);assertEquals("quota",q.error)
    }
}
