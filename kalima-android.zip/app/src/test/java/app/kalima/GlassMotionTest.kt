package app.kalima

import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

/** Runs the real Compose motion coroutine while the destination changes every frame. */
class GlassMotionTest {
    @Test fun dragKeepsFractionalPositionsAndReversesImmediately() {
        val motion = GlassMotion(0f)
        motion.beginDrag(100L)
        for ((index, slot) in listOf(0.12f, 0.49f, 0.51f, 1.25f, 2.73f, 1.42f, 0.33f).withIndex()) {
            motion.dragTo(slot, 116L + index * 16L)
            assertEquals("Finger tracking must not round or wait for a frame", slot, motion.position, 0.00001f)
        }
        assertEquals(0.5f, GlassSpring.iconCoverage(1, 0.5f), 0.00001f)
        motion.endDrag()
        assertFalse(motion.dragging)
        assertEquals("Release must not jump to a tab centre", 0.33f, motion.position, 0.00001f)
    }
    private class EmptyApplier : AbstractApplier<Unit>(Unit) {
        override fun insertTopDown(index: Int, instance: Unit) {}
        override fun insertBottomUp(index: Int, instance: Unit) {}
        override fun remove(index: Int, count: Int) {}
        override fun move(from: Int, to: Int, count: Int) {}
        override fun onClear() {}
    }

    @Test fun reducedMotionStillTracksTouchAndSettlesWithoutAnimation() = runBlocking {
        val clock = BroadcastFrameClock()
        withContext(clock) {
            val recomposer = Recomposer(coroutineContext)
            val loop = launch { recomposer.runRecomposeAndApplyChanges() }
            val composition = Composition(EmptyApplier(), recomposer)
            var goal by mutableFloatStateOf(0f)
            var motion: GlassMotion? = null
            try {
                composition.setContent { motion = rememberGlassMotion(goal, true) }
                repeat(3) { yield() }
                motion!!.beginDrag(100L)
                motion!!.dragTo(1.37f, 116L)
                SnapshotNotify.send()
                repeat(3) { yield() }
                assertEquals("Reduced motion must preserve direct manipulation", 1.37f, motion!!.position, 0.00001f)
                goal = 1f
                motion!!.endDrag()
                SnapshotNotify.send()
                repeat(3) { yield() }
                // One frame is required to recompose the newly selected tab;
                // no subsequent spring-animation frames should be needed.
                clock.sendFrame(16_666_667L)
                repeat(10) { yield() }
                assertEquals("Release must settle as soon as the selected tab recomposes", 1f, motion!!.position, 0.00001f)
                assertEquals(0f, motion!!.velocity, 0.00001f)
            } finally {
                composition.dispose(); recomposer.cancel(); loop.cancelAndJoin()
            }
        }
    }

    @Test fun changingDestinationEachFrameDoesNotFreezeLens() = runBlocking {
        val clock = BroadcastFrameClock()
        withContext(clock) {
            val recomposer = Recomposer(coroutineContext)
            val loop = launch { recomposer.runRecomposeAndApplyChanges() }
            val composition = Composition(EmptyApplier(), recomposer)
            var goal by mutableFloatStateOf(0f)
            var motion: GlassMotion? = null
            try {
                composition.setContent { motion = rememberGlassMotion(goal, false) }
                yield()
                repeat(30) { index ->
                    goal = (index + 1) / 10f
                    SnapshotNotify.send()
                    repeat(3) { yield() }
                    clock.sendFrame((index + 1) * 16_666_667L)
                    repeat(3) { yield() }
                }
                assertTrue("Lens must move before finger release", motion!!.position > 0.5f)
                repeat(100) { index ->
                    clock.sendFrame((index + 31) * 16_666_667L)
                    repeat(3) { yield() }
                }
                assertEquals(3f, motion!!.position, 0.02f)
                // Grab a moving lens, not one that has already come to rest.
                goal = 0f
                SnapshotNotify.send()
                repeat(6) { index ->
                    repeat(3) { yield() }
                    clock.sendFrame((index + 131) * 16_666_667L)
                    repeat(3) { yield() }
                }
                assertTrue("The spring must be moving before we grab it", motion!!.velocity < -0.1f)
                // The real frame loop must never overwrite direct touch positioning.
                motion!!.beginDrag(1000L)
                val heldPosition = motion!!.position
                SnapshotNotify.send()
                repeat(8) { index ->
                    repeat(3) { yield() }
                    clock.sendFrame((index + 137) * 16_666_667L)
                    repeat(3) { yield() }
                    assertEquals("Contact must stop the spring even before a swipe starts", heldPosition, motion!!.position, 0.00001f)
                }
                repeat(20) { index ->
                    val slot = 2.85f - index * 0.11f
                    motion!!.dragTo(slot, 1016L + index * 16L)
                    SnapshotNotify.send()
                    repeat(3) { yield() }
                    clock.sendFrame((index + 145) * 16_666_667L)
                    repeat(3) { yield() }
                    assertEquals(slot, motion!!.position, 0.00001f)
                }
                goal = 1f
                motion!!.endDrag()
                SnapshotNotify.send()
                repeat(3) { yield() }
                repeat(100) { index ->
                    clock.sendFrame((index + 165) * 16_666_667L)
                    repeat(3) { yield() }
                }
                assertEquals("Release should settle from the fractional position", 1f, motion!!.position, 0.02f)
                // A very short gesture ending on the same tab must still wake the spring.
                motion!!.beginDrag(2000L)
                motion!!.dragTo(1.22f, 2016L)
                motion!!.endDrag()
                SnapshotNotify.send()
                repeat(3) { yield() }
                repeat(100) { index ->
                    clock.sendFrame((index + 265) * 16_666_667L)
                    repeat(3) { yield() }
                }
                assertEquals(1f, motion!!.position, 0.02f)
            } finally {
                composition.dispose(); recomposer.cancel(); loop.cancelAndJoin()
            }
        }
    }
}

private object SnapshotNotify {
    fun send() = androidx.compose.runtime.snapshots.Snapshot.sendApplyNotifications()
}
