package app.kalima

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.*
import androidx.compose.runtime.BroadcastFrameClock

class SentenceGrammarTest {
    private val sentence = "كَتَبَ الطَّالِبُ الدَّرْسَ."
    private fun reply(parts: List<String> = listOf("كَتَبَ", "الطَّالِبُ", "الدَّرْسَ")): JSONObject = JSONObject()
        .put("status", "ok").put("overview", "جملة فعلية")
        .put("rows", JSONArray(parts.map { JSONObject().put("text", it).put("analysis", "إعراب الكلمة في الجملة") }))
        .put("clauses", JSONArray()).put("alternatives", JSONArray())
    private fun rejects(o: JSONObject, text: String = sentence) {
        try { SentenceGrammar.parse(o.toString(), text); fail("Must reject") } catch (_: ApiError) { }
    }
    @Test fun validatesArabicAndBoundsWithoutBanningOneWordImperatives() {
        assertNull(SentenceGrammar.inputError(sentence)); assertNull(SentenceGrammar.inputError("قُمْ")); assertNull(SentenceGrammar.inputError("قِ"))
        assertNotNull(SentenceGrammar.inputError("   ")); assertNotNull(SentenceGrammar.inputError("write a sentence"))
        assertNotNull(SentenceGrammar.inputError("كتب the student"))
        assertNotNull(SentenceGrammar.inputError("ك".repeat(601)))
        assertNotNull(SentenceGrammar.inputError(List(41) { "كتب" }.joinToString(" ")))
    }
    @Test fun acceptsLiveServiceFixtureWithoutDuplicatingTheSubject() {
        val raw=javaClass.getResource("/grammar-example.json")!!.readText()
        val r=SentenceGrammar.parse(raw,sentence)
        assertEquals(3,r.rows.size)
        assertTrue(r.rows[1].analysis.contains("فاعل"))
        assertFalse(r.rows[0].analysis.contains("مستتر"))
    }
    @Test fun preservesOriginalAndAcceptsCompleteOrderedRows() {
        val r = SentenceGrammar.parse("```json\n${reply()}\n```", sentence)
        assertEquals(sentence, r.original); assertEquals(3, r.rows.size)
    }
    @Test fun acceptsAddedVowelsAndAttachedParticleSplits() {
        assertEquals(3, SentenceGrammar.parse(reply(listOf("كَتَبَ", "الطَّالِبُ", "الدَّرْسَ")).toString(), "كتب الطالب الدرس").rows.size)
        assertEquals(3, SentenceGrammar.parse(reply(listOf("أَ", "لَمْ", "تَرَ")).toString(), "ألم تر").rows.size)
    }
    @Test fun rejectsOmissionsReorderingDuplicatesAndRewrittenLetters() {
        rejects(reply(listOf("كَتَبَ الطَّالِبُ الدَّرْسَ")))
        rejects(reply(listOf("كتب", "الطالب")))
        rejects(reply(listOf("الطالب", "كتب", "الدرس")))
        rejects(reply(listOf("كتب", "الطالب", "الدرس", "الدرس")))
        rejects(reply(listOf("كتب", "الطالب", "الدارس")))
    }
    @Test fun harmlessPunctuationRowsAreIgnoredButNumbersArePreserved() {
        val o=reply()
        o.getJSONArray("rows").put(JSONObject().put("text", ".").put("analysis", "علامة وقف"))
        assertEquals(3,SentenceGrammar.parse(o.toString(),sentence).rows.size)
        val numeric=reply(listOf("عندي","٣","كتب"))
        assertEquals(3,SentenceGrammar.parse(numeric.toString(),"عندي ٣ كتب").rows.size)
        rejects(numeric,"عندي ٤ كتب")
        assertNotNull(SentenceGrammar.inputError("123"))
    }
    @Test fun rejectsNonArabicAnalysisAndUnrelatedClauses() {
        rejects(reply().put("overview", "This is a verb sentence"))
        val o = reply();o.getJSONArray("rows").getJSONObject(0).put("analysis", "past tense verb");rejects(o)
        rejects(reply().put("clauses", JSONArray().put(JSONObject().put("text", "في البيت").put("analysis", "جار ومجرور"))))
    }
    @Test fun rejectsHiddenSubjectImmediatelyFollowedByExplicitSubject() {
        val o=reply()
        o.getJSONArray("rows").getJSONObject(0).put("analysis", "فعل ماض والفاعل ضمير مستتر تقديره هو")
        o.getJSONArray("rows").getJSONObject(1).put("analysis", "فاعل مرفوع بالضمة")
        rejects(o)
    }
    @Test fun malformedReplyRetriesOnlyOnceAndQuotaDoesNotRetry() = runBlocking {
        var count=0
        val state=GrammarSession(this, { count++; "{}" }, {"network"})
        state.edit(sentence);state.analyse()
        withTimeout(3000) { while(state.loading) delay(10) }
        assertEquals(2,count);assertNull(state.result);assertNotNull(state.error)
        count=0
        val quota=GrammarSession(this, {count++;throw ApiError("http_429")}, {"quota"})
        quota.edit(sentence);quota.analyse()
        withTimeout(3000) { while(quota.loading) delay(10) }
        assertEquals(1,count);assertEquals("quota",quota.error)
    }
    @Test fun completeReplyCommitsToTheSameSentence() = runBlocking {
        val state=GrammarSession(this, {reply().toString()}, {"error"})
        state.edit(sentence);state.analyse()
        withTimeout(3000) { while(state.loading) delay(10) }
        assertEquals(sentence,state.result?.original);assertNull(state.error)
    }
    @Test fun rejectsMissingArraysAndTruncatedJson() {
        val o=reply();o.remove("alternatives");rejects(o)
        try { SentenceGrammar.parse(reply().toString().dropLast(8), sentence);fail() } catch (_: ApiError) { }
    }
    @Test fun rejectsUnsupportedStatusAndRecognizesContextErrors() {
        rejects(reply().put("status", "partial"))
        try { SentenceGrammar.parse("{\"status\":\"needs_context\"}", "كتاب");fail() }
        catch(e: ApiError) { assertEquals("sentence_context",e.code) }
    }
    @Test fun promptFitsProxyBudgetAndQuotesInputAsData() {
        val text="كتب الطالب الدرس. ".repeat(30).take(600)
        val p=SentenceGrammar.prompt(text)
        assertTrue(p.length<8000); assertTrue(p.contains("INPUT_JSON="))
        assertTrue(p.contains("All explanation CONTENT must be in Arabic"))
    }
    @Test fun clearingCancelsRequestAndSuppressesLateResults() = runBlocking {
        val started=CompletableDeferred<Unit>();val finish=CompletableDeferred<Unit>()
        val scope=CoroutineScope(SupervisorJob()+Dispatchers.Unconfined)
        try {
            val session=GrammarSession(scope, {started.complete(Unit);withContext(NonCancellable){finish.await()};reply().toString()}, {"error"})
            session.edit(sentence);session.analyse();started.await();session.clear();finish.complete(Unit)
            delay(80);assertNull(session.result);assertNull(session.error);assertFalse(session.loading);assertEquals("",session.query)
        } finally { scope.cancel() }
    }
    @Test fun invalidInputDoesNotSendRequest() = runBlocking {
        var requests=0
        val state=GrammarSession(this,{requests++;reply().toString()},{"error"})
        state.edit("hello");state.analyse();assertEquals(0,requests);assertNotNull(state.error)
    }
}
