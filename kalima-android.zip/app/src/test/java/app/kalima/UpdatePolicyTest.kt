package app.kalima

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.concurrent.CancellationException

class UpdatePolicyTest {
    private val repo = "owner/kalima"
    private val bytes = "signed APK stand-in".toByteArray()
    private fun manifest() = JSONObject().put("schema", 1).put("packageName", "app.kalima")
        .put("versionCode", 9).put("versionName", "0.9").put("minSdk", 24).put("size", bytes.size)
        .put("sha256", MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) })
        .put("apkUrl", "https://github.com/$repo/releases/download/latest/Kalima-0.9-9.apk").put("notes", "New release")
    private fun parse(j: JSONObject = manifest(), installed: Long = 8, sdk: Int = 34) = UpdatePolicy.parse(j.toString(), repo, installed, sdk)
    private fun rejected(block: () -> Unit) { try { block(); fail("Should reject untrusted update") } catch (_: IllegalArgumentException) {} }
    @Test fun newerCompatibleMainReleaseIsAccepted() { assertEquals(9L, parse()!!.versionCode) }
    @Test fun sameVersionIsNotOfferedAgain() { assertNull(parse(installed = 9)) }
    @Test fun olderReleaseIsNotOffered() { assertNull(parse(installed = 10)) }
    @Test fun incompatibleAndroidVersionIsNotOffered() { assertNull(parse(manifest().put("minSdk", 35))) }
    @Test fun testPackageCannotBeOfferedToMain() { rejected { parse(manifest().put("packageName", "app.kalima.test")) } }
    @Test fun unknownSchemaIsRejected() { rejected { parse(manifest().put("schema", 2)) } }
    @Test fun insecureOrOtherHostUrlsAreRejected() {
        listOf("http://github.com/$repo/releases/download/latest/Kalima-9.apk", "https://evil.example/Kalima-9.apk", "https://github.com.evil.example/$repo/releases/download/latest/Kalima-9.apk").forEach { rejected { parse(manifest().put("apkUrl", it)) } }
    }
    @Test fun anotherRepositoryCannotSupplyUpdates() { rejected { parse(manifest().put("apkUrl", "https://github.com/other/repo/releases/download/latest/Kalima-9.apk")) } }
    @Test fun credentialsQueriesAndTraversalAreRejected() {
        val prefix = "https://github.com/$repo/releases/download/latest/"
        listOf(prefix+"../Kalima-9.apk", prefix+"%2e%2e%2fKalima-9.apk", prefix+"Kalima-9.apk?x=1", prefix+"Kalima-9.apk#x", "https://user@github.com/$repo/releases/download/latest/Kalima-9.apk").forEach { rejected { parse(manifest().put("apkUrl", it)) } }
    }
    @Test fun malformedHashSizeAndVersionAreRejected() {
        listOf("sha256" to "bad", "size" to 0, "size" to UpdatePolicy.MAX_APK_BYTES + 1, "versionCode" to 0, "versionName" to "../oops").forEach { (key,value) -> rejected { parse(manifest().put(key,value)) } }
    }
    @Test fun oversizedNotesAndMetadataAreRejected() {
        rejected { parse(manifest().put("notes", "a".repeat(4001))) }
        rejected { UpdatePolicy.parse(" ".repeat(65537), repo, 8, 34) }
    }
    @Test fun onlyKnownHttpsGitHubTransportIsAccepted() {
        assertTrue(UpdatePolicy.trustedTransport("https://release-assets.githubusercontent.com/path?token=example"))
        assertFalse(UpdatePolicy.trustedTransport("http://release-assets.githubusercontent.com/path"))
        assertFalse(UpdatePolicy.trustedTransport("https://evil.githubusercontent.com/path"))
    }
    @Test fun verifiedDownloadCopiesExactBytesAndReportsProgress() {
        val out = ByteArrayOutputStream();var progress = 0
        UpdatePolicy.copyVerified(ByteArrayInputStream(bytes), out, parse()!!, progress = { progress = it })
        assertArrayEquals(bytes, out.toByteArray());assertEquals(100, progress)
    }
    @Test fun truncatedDownloadIsRejected() { rejected { UpdatePolicy.copyVerified(ByteArrayInputStream(bytes.dropLast(1).toByteArray()), ByteArrayOutputStream(), parse()!!) } }
    @Test fun oversizedDownloadIsRejected() { rejected { UpdatePolicy.copyVerified(ByteArrayInputStream(bytes + byteArrayOf(1)), ByteArrayOutputStream(), parse()!!) } }
    @Test fun tamperedDownloadIsRejected() { rejected { UpdatePolicy.copyVerified(ByteArrayInputStream(ByteArray(bytes.size)), ByteArrayOutputStream(), parse()!!) } }
    @Test fun cancellationStopsCopying() {
        val out = ByteArrayOutputStream()
        try { UpdatePolicy.copyVerified(ByteArrayInputStream(bytes), out, parse()!!, checkCancelled = { throw CancellationException() }); fail() }
        catch (_: CancellationException) { assertEquals(0, out.size()) }
    }
    @Test fun repositoryMustBeAnOwnerRepoPair() {
        assertTrue(UpdatePolicy.repositoryValid(repo))
        listOf("", "../repo", "owner/../repo", "https://github.com/owner/repo", "owner/repo?token=x").forEach { assertFalse(UpdatePolicy.repositoryValid(it)) }
    }
}
