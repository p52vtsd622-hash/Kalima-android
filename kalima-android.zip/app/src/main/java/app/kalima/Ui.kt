package app.kalima

import app.kalima.LocalizedIcon as Icon

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import android.app.Activity
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- Global Theme Variables & State Trigger ---
var globalThemeTrigger by mutableStateOf(0)

val isDark: Boolean
    @Composable get() = when (appPrefs?.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }.also { globalThemeTrigger }

// --- Exact Web V2 Emerald & Cream Palette ---
val colorPaper @Composable get() = if (isDark) Color(0xFF161718) else Color(0xFFF8F6F0)
val colorSurface @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFFFFFFF)
val colorField @Composable get() = if (isDark) Color(0xFF252726) else Color(0xFFFFFFFF)
val colorInk @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorMuted @Composable get() = if (isDark) Color(0xFF828683) else Color(0xFF6A7A71)
val colorLine @Composable get() = if (isDark) Color(0xFF2D302E) else Color(0xFFDEDAD1)
val colorSoftLine @Composable get() = if (isDark) Color(0xFF222423) else Color(0xFFEBE7DF)

val colorPrimary = Color(0xFF4A835C)
val colorPrimaryFg = Color(0xFFFFFFFF)
val colorPrimaryLight @Composable get() = if (isDark) Color(0xFF1F3226) else Color(0xFFDCE5DE)
val colorPrimaryLightFg @Composable get() = if (isDark) Color(0xFF8AB89B) else Color(0xFF335C41)

val colorAccent @Composable get() = if (isDark) Color(0xFFC77733) else Color(0xFFD78A42)
val colorAccentFg = Color(0xFFFFFFFF)

val colorNavBg @Composable get() = if (isDark) Color(0xFF272A28) else Color(0xFFEAE5DB)
val colorNavFg @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorNavActivePill @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFDDD7CB)

val colorInputBg @Composable get() = if (isDark) Color(0xFF2A2D2B) else Color(0xFFF8F6F0)
val colorSendBg @Composable get() = if (isDark) Color(0xFF636765) else Color(0xFF898E8B)

val colorSuggestBg @Composable get() = if (isDark) Color(0xFF0D1C12) else Color(0xFFE3EDE5)
val colorSuggestInk @Composable get() = if (isDark) Color(0xFF65AF80) else Color(0xFF225134)

val colorOk @Composable get() = if (isDark) Color(0xFF6FCF97) else Color(0xFF1F7A4D)
val colorError @Composable get() = if (isDark) Color(0xFFF08A80) else Color(0xFFA8382F)


var appPrefs: Prefs? = null

// --- Custom Web SVG Vectors Translated to Android ImageVectors ---

val Icons_SendArrow: ImageVector
    get() = ImageVector.Builder("Send", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(2.01f, 21f); lineTo(23f, 12f); lineTo(2.01f, 3f); lineTo(2f, 10f); lineTo(15f, 12f); lineTo(2f, 14f); close()
    }.build()

val Icons_History: ImageVector
    get() = ImageVector.Builder("History", 24.dp, 24.dp, 24f, 24f).path(
        fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 2f,
        strokeLineCap = androidx.compose.ui.graphics.StrokeCap.Round,
        strokeLineJoin = androidx.compose.ui.graphics.StrokeJoin.Round
    ) {
        moveTo(3f, 12f)
        curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
        curveTo(16.97f, 21f, 21f, 16.97f, 21f, 12f)
        curveTo(21f, 7.03f, 16.97f, 3f, 12f, 3f)
        curveTo(8.9f, 3f, 6.17f, 4.57f, 4.55f, 6.96f)
        lineTo(3f, 9f)
        moveTo(3f, 4f); lineTo(3f, 9f); lineTo(8f, 9f)
        moveTo(12f, 7f); lineTo(12f, 12f); lineTo(16f, 14f)
    }.build()

val Icons_DadBubble: ImageVector
    get() = ImageVector.Builder("Dad", 32.dp, 32.dp, 32f, 32f).path(fill = SolidColor(Color.White)) {
        moveTo(6f, 6f); lineToRelative(20f, 0f); curveToRelative(1.66f, 0f, 3f, 1.34f, 3f, 3f); lineToRelative(0f, 12f); curveToRelative(0f, 1.66f, -1.34f, 3f, -3f, 3f); lineToRelative(-8f, 0f); lineToRelative(-5f, 4f); lineToRelative(0f, -4f); lineTo(6f, 24f); curveToRelative(-1.66f, 0f, -3f, -1.34f, -3f, -3f); lineTo(3f, 9f); curveToRelative(0f, -1.66f, 1.34f, -3f, 3f, -3f); close()
    }.build()

val Icons_BrainProfile: ImageVector
    get() = ImageVector.Builder("Saved", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19f, 21f); lineToRelative(-7f, -5f); lineToRelative(-7f, 5f); lineTo(5f, 5f); curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f); lineToRelative(10f, 0f); curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f); close()
    }.build()

val Icons_GradCap: ImageVector
    get() = ImageVector.Builder("Practice", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(9f, 2f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineTo(3f, 4f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineToRelative(0f, 14f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f); lineToRelative(14f, 0f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f); lineTo(19f, 6f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineToRelative(-2f, 0f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineTo(9f, 2f); close(); moveTo(9f, 4f); lineToRelative(6f, 0f); lineToRelative(0f, 2f); lineTo(9f, 6f); lineTo(9f, 4f); close(); moveTo(15f, 11f); lineToRelative(-5.5f, 5.5f); lineTo(7f, 14f); lineToRelative(1.41f, -1.41f); lineTo(10f, 14.17f); lineToRelative(4.09f, -4.09f); lineTo(15f, 11f); close()
    }.build()

val Icons_SettingsGear: ImageVector
    get() = ImageVector.Builder("Settings", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19.14f, 12.94f); curveToRelative(0.04f, -0.3f, 0.06f, -0.61f, 0.06f, -0.94f); curveToRelative(0f, -0.32f, -0.02f, -0.64f, -0.07f, -0.94f); lineToRelative(2.03f, -1.58f); curveToRelative(0.18f, -0.14f, 0.23f, -0.41f, 0.12f, -0.61f); lineToRelative(-1.92f, -3.32f); curveToRelative(-0.12f, -0.22f, -0.37f, -0.29f, -0.59f, -0.22f); lineToRelative(-2.39f, 0.96f); curveToRelative(-0.5f, -0.38f, -1.03f, -0.7f, -1.62f, -0.94f); lineToRelative(-0.36f, -2.54f); curveToRelative(-0.04f, -0.24f, -0.24f, -0.42f, -0.5f, -0.42f); lineToRelative(-3.82f, 0f); curveToRelative(-0.25f, 0f, -0.46f, 0.18f, -0.5f, 0.42f); lineToRelative(-0.36f, 2.54f); curveToRelative(-0.59f, 0.24f, -1.13f, 0.57f, -1.62f, 0.94f); lineToRelative(-2.39f, -0.96f); curveToRelative(-0.23f, -0.09f, -0.49f, 0f, -0.59f, 0.22f); lineTo(2.71f, 8.87f); curveToRelative(-0.12f, 0.21f, -0.08f, 0.47f, 0.12f, 0.61f); lineToRelative(2.03f, 1.58f); curveToRelative(-0.05f, 0.3f, -0.07f, 0.63f, -0.07f, 0.94f); curveToRelative(0f, 0.31f, 0.02f, 0.64f, 0.07f, 0.94f); lineToRelative(-2.03f, 1.58f); curveToRelative(-0.18f, 0.14f, -0.23f, 0.41f, -0.12f, 0.61f); lineToRelative(1.92f, 3.32f); curveToRelative(0.12f, 0.22f, 0.37f, 0.29f, 0.59f, 0.22f); lineToRelative(2.39f, -0.96f); curveToRelative(0.5f, 0.38f, 1.03f, 0.7f, 1.62f, 0.94f); lineToRelative(0.36f, 2.54f); curveToRelative(0.05f, 0.24f, 0.25f, 0.42f, 0.5f, 0.42f); lineToRelative(3.82f, 0f); curveToRelative(0.25f, 0f, 0.46f, -0.18f, 0.5f, -0.42f); lineToRelative(0.36f, -2.54f); curveToRelative(0.59f, -0.24f, 1.13f, -0.56f, 1.62f, -0.94f); lineToRelative(2.39f, 0.96f); curveToRelative(0.22f, 0.08f, 0.47f, 0f, 0.59f, -0.22f); lineToRelative(1.92f, -3.32f); curveToRelative(0.12f, -0.22f, 0.07f, -0.47f, -0.12f, -0.61f); lineToRelative(-2.01f, -1.58f); close(); moveTo(12f, 15.6f); curveToRelative(-1.99f, 0f, -3.6f, -1.61f, -3.6f, -3.6f); curveToRelative(0f, -1.99f, 1.61f, -3.6f, 3.6f, -3.6f); curveToRelative(1.99f, 0f, 3.6f, 1.61f, 3.6f, 3.6f); curveToRelative(0f, 1.99f, -1.61f, 3.6f, -3.6f, 3.6f); close()
    }.build()

@Composable
fun KalimaRoot(vm: MainViewModel) {
    val tabState = rememberSaveableStateHolder()
    val lookupScroll = rememberScrollState()
    val headerScope = rememberCoroutineScope()
    val reducedMotion = rememberReducedMotion()
    val headerDensity = LocalDensity.current
    val compactThreshold = with(headerDensity) { 128.dp.toPx() * fontScale }
    val compactWordVisible by remember(lookupScroll, compactThreshold, vm) { derivedStateOf {
        vm.currentTab == "lookup" && !vm.searchFocused && !vm.loading && vm.errorMsg == null &&
            vm.result != null && lookupScroll.value > compactThreshold
    } }
    LaunchedEffect(vm.result?.word) { lookupScroll.scrollTo(0) }
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    LaunchedEffect(vm.currentTab) {
        keyboard?.hide()
        focus.clearFocus()
    }
    HomeFocusLifecycle(vm)
    appPrefs = vm.prefs
    val dark = isDark
    val activity = LocalContext.current as? Activity
    val background = colorPaper
    SideEffect {
        activity?.window?.let { window ->
            window.statusBarColor = background.toArgb()
            window.navigationBarColor = background.toArgb()
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalLayoutDirection provides if (Langs.isRtl(vm.prefs.appLanguage)) LayoutDirection.Rtl else LayoutDirection.Ltr) {
    KalimaTheme(dark) {
        UpdateDialogs(vm.updates)
        WordMotionHost(vm) {
        Box(Modifier.fillMaxSize().background(colorPaper).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Column(Modifier.widthIn(max = 760.dp).fillMaxSize().align(Alignment.TopCenter)) {
                ContextualHomeHeader(vm, if (compactWordVisible) vm.result?.word else null) {
                    headerScope.launch {
                        if (reducedMotion) lookupScroll.scrollTo(0) else lookupScroll.animateScrollTo(0)
                    }
                }
                vm.notice?.let { message ->
                    Row(Modifier.fillMaxWidth().background(colorPrimaryLight).padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(message, color = colorPrimaryLightFg, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { vm.notice = null }) { Text("Dismiss") }
                    }
                }
                UndoFeedback(vm)
                val contentTarget = vm.currentTab + if (vm.currentTab == "lookup") when {
                    vm.searchFocused -> ":search"
                    vm.loading -> ":loading"
                    vm.errorMsg != null -> ":error"
                    vm.result != null -> ":word:" + vm.result!!.word
                    !vm.translationOptions.isNullOrEmpty() -> ":options"
                    else -> ":empty"
                } else ""
                GentleContent(contentTarget, Modifier.weight(1f)) {
                    when (vm.currentTab) {
                        "saved" -> tabState.SaveableStateProvider("saved") { SavedScreen(vm) }
                        "practice" -> PracticeScreen(vm)
                        "settings" -> SettingsScreen(vm)
                        "history" -> tabState.SaveableStateProvider("history") { HistoryScreen(vm) }
                        else -> LookupScreen(vm, lookupScroll, compactWordVisible)
                    }
                }
                BottomDock(vm)
            }
        }
        }
    }
}

}

// --- Dynamic Empty State ---
@Composable
fun EmptyState(vm: MainViewModel) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SuggestedWordCard(vm)
        HomeContinuation(vm)
        Spacer(Modifier.height(16.dp))
    }
}

// --- Fully Styled Floating Dock ---
@Composable
fun BottomDock(vm: MainViewModel, modifier: Modifier = Modifier) {
    val haptic = rememberInteractionHaptic(vm.prefs)
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        if (!vm.searchFocused) HomeSearchControls(vm)
        Spacer(Modifier.height(4.dp))
        LookupSearchField(vm, Modifier.padding(bottom = 8.dp))
        val keyboard = LocalSoftwareKeyboardController.current
        val focus = LocalFocusManager.current
        LiquidGlassNavigation(vm.currentTab, onSelect = {
            keyboard?.hide()
            focus.clearFocus()
            if (it != vm.currentTab) haptic(InteractionHaptic.Selection)
            vm.currentTab = it
        })

    }
}

@Composable
fun DockPill(text: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).clickable(onClick = onClick).padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxWidth().heightIn(min = 36.dp).background(if (isActive) colorPrimary else colorPrimaryLight, RoundedCornerShape(50))
            .padding(vertical = 5.dp, horizontal = 4.dp), contentAlignment = Alignment.Center) {
            Text(text = text, color = if (isActive) colorPrimaryFg else colorPrimaryLightFg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// --- Lookup Screen Wrapper ---
@Composable
fun LookupScreen(vm: MainViewModel, scroll: androidx.compose.foundation.ScrollState, compact: Boolean) {
    if (vm.searchFocused) { FocusedHomeSearch(vm); return }
    Box(Modifier.fillMaxSize()) {
    CompositionLocalProvider(LocalCompactWordVisible provides compact) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = KalimaDesign.screenInset)
    ) {
        if (vm.loading) {
            Row(Modifier.semantics { liveRegion = androidx.compose.ui.semantics.LiveRegionMode.Polite }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!rememberReducedMotion()) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = colorPrimaryLightFg, strokeWidth = 2.dp)
                Text(if (vm.searchMode == "rev") "Finding Arabic matches…" else "Analysing this word…", color = colorPrimary, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.cancel() }) { Text("Stop", color = colorPrimary) }
            }
            Spacer(Modifier.height(16.dp))
            LookupLoadingPlaceholder()
            Spacer(Modifier.height(24.dp))
        }

        val err = vm.errorMsg
        if (err != null) {
            SectionRequestFeedback(false, err, "", { vm.lookup() })
            Spacer(Modifier.height(16.dp))
        }

        val opts = vm.translationOptions
        if (!opts.isNullOrEmpty()) {
            Text("Arabic for \"${vm.query}\"", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colorInk)
            Spacer(Modifier.height(6.dp))
            Text("Tap a word for the full breakdown.", color = colorMuted, fontSize = 15.sp, modifier = Modifier.padding(bottom = 14.dp))
            for (opt in opts) CandidateCard(opt, vm.prefs.lang) { vm.openWord(opt.ar) }
            Spacer(Modifier.height(24.dp))
        } else if (vm.result != null) {
            ResultView(vm.result!!, vm.prefs.lang, vm)
            Spacer(Modifier.height(24.dp))
        } else if (!vm.loading && err == null && opts.isNullOrEmpty()) {
            EmptyState(vm)
        }
    }
    }
    // A quiet reading edge above the functional dock; it does not cover its controls.
    if (scroll.canScrollForward) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(12.dp)
        .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, colorPaper)))
        .clearAndSetSemantics {})
    }
}

@Composable
fun ResultView(w: Word, lang: String, vm: MainViewModel) {
    androidx.compose.runtime.key(w.word) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(KalimaDesign.sectionGap)) {
            WordHead(w, vm)
            TranslationBanner(vm)
            ReadingSurface { MeaningSection(w, lang) }
            if (w.grammar.isNotBlank() || w.waznPattern.isNotBlank() || w.waznNote.isNotBlank()) {
                ReadingSurface {
                    SectionTitle("Grammar")
                    ReadingText(w.grammar, muted = true)
                    if (w.waznPattern.isNotBlank()) {
                        Spacer(Modifier.height(KalimaDesign.itemGap))
                        Text("Wazn", fontSize = 14.sp, color = colorMuted)
                        ArabicText(w.waznPattern, 28)
                    }
                    ReadingText(w.waznNote, muted = true)
                }
            }
            ReadingSurface {
                RootBand(w, lang)
                if (w.root.isNotEmpty()) RootWordsSection(vm)
            }
            if (w.examples.isNotEmpty()) StudySection("In a sentence", true) { ExamplesSection(w, lang, vm, false) }
            StudySection("Examples in texts") { TextSections(w) }
            w.verb?.let { verb -> StudySection("Verb details", true) { VerbSection(verb, w, vm) } }
            if (w.synonyms.isNotEmpty()) StudySection("Synonyms") { RelatedSection("Synonyms", w.synonyms, lang, vm, false) }
            if (w.antonyms.isNotEmpty()) StudySection("Antonyms") { RelatedSection("Antonyms", w.antonyms, lang, vm, false) }
            if (w.note.isNotBlank()) StudySection("Usage note") { ReadingText(w.note, muted = true) }
        }
    }
}

@Composable
fun SectionDivider() {
    Spacer(Modifier.height(KalimaDesign.sectionGap))
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colorInk,
        modifier = Modifier.padding(bottom = KalimaDesign.itemGap).semantics { heading() })
}

@Composable
fun ArabicText(text: String, size: Int, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        color = colorInk,
        fontFamily = arabicFont,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.5f).sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
    )
}

@Composable
fun TxLine(text: String, lang: String) {
    if (lang == "off" || text.isBlank()) return
    val rtl = Langs.isRtl(lang)
    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Text(Langs.names[lang] ?: "", fontFamily = translationFont(appPrefs?.appLanguage ?: "en"), fontSize = 14.sp, color = colorMuted)
        RawText(
            text = text,
            modifier = Modifier.weight(1f),
            color = colorInk,
            style = TextStyle(fontFamily = translationFont(lang), fontSize = if (lang == "ur") 19.sp else 18.sp, lineHeight = if (lang == "ur") 44.sp else if (lang == "fa") 36.sp else 27.sp, textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr, textAlign = if (rtl) TextAlign.Right else TextAlign.Left)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RootBand(w: Word, lang: String) {
    FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.widthIn(min = 100.dp, max = 260.dp)) {
            SectionTitle("Root")
            if (w.root.isEmpty()) Text("No root: this may be a particle or a loanword.", color = colorMuted, fontSize = 15.sp)
            else ReadingText(w.rootGloss, muted = true)
            TxLine(w.rootGlossTx, lang)
        }
        if (w.root.isNotEmpty()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) { w.root.forEach { RootTile(it, if (w.root.size > 3) 48.dp else 60.dp) } }
            }
        }
    }
}

@Composable
fun RootTile(letter: String, width: Dp = 60.dp) {
    val scale = LocalDensity.current.fontScale.coerceAtLeast(1f)
    Box(
        modifier = Modifier.size(width = width * scale, height = 80.dp * scale).clip(RoundedCornerShape(16.dp)).background(colorPrimary),
        contentAlignment = Alignment.Center
    ) {
        RawText(text = letter, color = colorPrimaryFg, style = TextStyle(fontSize = 46.sp, lineHeight = 69.sp, textDirection = TextDirection.Rtl, fontWeight = FontWeight.Normal, fontFamily = arabicFont))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordHead(w: Word, vm: MainViewModel) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        MovingWord(w.word, "detail:" + w.word, 58, 92,
            modifier = Modifier.semantics { heading() }, register = !LocalCompactWordVisible.current)
        if (w.translit.isNotBlank() && (appPrefs?.appLanguage ?: "en") != "ar") {
            RawText(w.translit, fontFamily = latinFont, fontSize = 18.sp, lineHeight = 28.sp, color = colorMuted, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(KalimaDesign.itemGap))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (w.pos.isNotBlank()) Surface(color = colorPrimaryLight, shape = RoundedCornerShape(50)) {
                Text(w.pos, color = colorPrimaryLightFg, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
            }
            OutlinedButton(onClick = { vm.speak(w.word) }, modifier = Modifier.heightIn(min = 48.dp),
                shape = KalimaDesign.controlShape, border = androidx.compose.foundation.BorderStroke(1.dp, colorLine)) {
                Text("Listen", color = colorPrimaryLightFg)
            }
        }
    }
}

@Composable
fun MeaningSection(w: Word, lang: String) {
    SectionTitle("Meaning")
    if ((appPrefs?.appLanguage ?: "en") != "ar") {
        Text(Langs.names[appPrefs?.appLanguage ?: "en"] ?: "English", fontSize = 14.sp, color = colorMuted)
        Spacer(Modifier.height(4.dp))
    }
    ReadingText(w.meaningEn, primary = true)
    if (w.meaningAr.isNotBlank() && (appPrefs?.appLanguage ?: "en") != "ar") {
        Spacer(Modifier.height(KalimaDesign.itemGap))
        ArabicText(w.meaningAr, 26, modifier = Modifier.fillMaxWidth())
    }
    TxLine(w.meaningTx, lang)
}

@Composable
fun ExamplesSection(w: Word, lang: String, vm: MainViewModel, showTitle: Boolean = true) {
    if (showTitle) SectionTitle("In a sentence")
    for ((i, ex) in w.examples.withIndex()) {
        if (i > 0) Spacer(Modifier.height(14.dp))
        ArabicText(ex.ar, 24, modifier = Modifier.fillMaxWidth())
        TextButton(onClick = { vm.speak(ex.ar) }) { Text("Listen to sentence", color = colorPrimary) }
        ReadingText(ex.en)
        TxLine(ex.tx, lang)
    }
}

@Composable
fun VerbSection(v: Verb, w: Word, vm: MainViewModel) {
    val formText = if (v.form.isNotBlank() && v.form.length <= 5 && v.form.all { it == 'I' || it == 'V' || it == 'X' }) "Form ${v.form}" else v.form
    if (formText.isNotBlank()) {
        Text("Verb form", fontSize = 14.sp, color = colorMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formText, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
            if (v.pattern.isNotBlank()) ArabicText(v.pattern, 24)
        }
        Spacer(Modifier.height(8.dp))
    }
    val tense = listOf(
        if (v.inputTense.isNotBlank()) tr(v.inputTense) else "",
        v.inputPerson
    ).filter { it.isNotBlank() }.joinToString(", ")
    if (tense.isNotBlank()) {
        Text("Your word is", fontSize = 14.sp, color = colorMuted)
        Text(tense, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
        Spacer(Modifier.height(8.dp))
    }
    VerbFact("Dictionary form (he, past)", v.dictionaryForm)
    VerbFact("Present (he)", v.presentForm)
    VerbFact("Masdar (verbal noun)", v.masdar)
    if (v.masdarWazn.isNotBlank()) VerbFact("Masdar wazn", v.masdarWazn)

    Spacer(Modifier.height(24.dp))
    Text("All 14 forms · tap a form to listen", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colorInk)
    Spacer(Modifier.height(10.dp))
    
    val conjugationKey = v.dictionaryForm.ifBlank { w.word }
    if (vm.loadedConjs != null) {
        ExpandableResultSection("Conjugation table", true) { ConjTable(v, vm.loadedConjs!!, vm) }
    } else {
        SectionRequestFeedback(vm.conjLoading, vm.conjugationError, "Loading the 14-form conjugation table…", { vm.loadConjugations(conjugationKey) })
        if (!vm.conjLoading && vm.conjugationError == null) OutlinedButton(
            onClick = { vm.loadConjugations(conjugationKey) }, modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)
        ) { Text("Show 14×7 conjugations", color = colorPrimary) }
    }
}

@Composable
fun VerbFact(label: String, value: String) {
    if (value.isBlank()) return
    Text(label, fontSize = 14.sp, color = colorMuted)
    ArabicText(value, 24, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
}

@Composable
fun RelatedSection(title: String, items: List<Gloss>, lang: String, vm: MainViewModel, showTitle: Boolean = true) {
    if (showTitle) SectionTitle(title)
    if (items.isEmpty()) {
        Text("None found.", color = colorMuted)
        return
    }
    for (g in items) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                ReadingText(g.en, muted = true)
                TxLine(g.tx, lang)
            }
            ArabicText(g.ar, 24, Modifier.clickable { vm.openWord(g.ar) })
        }
        HorizontalDivider(color = colorSoftLine)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (code, label) ->
            if (selected == code) Button(onClick = { onSelect(code) }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = colorPrimary, contentColor = colorPrimaryFg)) { Text(label) }
            else OutlinedButton(onClick = { onSelect(code) }, shape = RoundedCornerShape(50), border = androidx.compose.foundation.BorderStroke(1.dp, colorLine)) { Text(label, color = colorInk) }
        }
    }
}
