package app.kalima

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- Global Theme Variables & State Trigger ---
var globalThemeTrigger by mutableStateOf(0)

val isDark: Boolean
    @Composable get() = when (appPrefs?.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }.also { globalThemeTrigger }

// --- Exact Web V2 Emerald & Cream Palette ---
val colorPaper @Composable get() = if (isDark) Color(0xFF161718) else Color(0xFFF8F6F0)
val colorSurface @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFFFFFFF)
val colorField @Composable get() = if (isDark) Color(0xFF252726) else Color(0xFFFFFFFF)
val colorInk @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorMuted @Composable get() = if (isDark) Color(0xFF828683) else Color(0xFF6A7A71)
val colorLine @Composable get() = if (isDark) Color(0xFF2D302E) else Color(0xFFDEDAD1)
val colorSoftLine @Composable get() = if (isDark) Color(0xFF222423) else Color(0xFFEBE7DF)

val colorPrimary = Color(0xFF4A835C)
val colorPrimaryFg = Color(0xFFFFFFFF)
val colorPrimaryLight @Composable get() = if (isDark) Color(0xFF1F3226) else Color(0xFFDCE5DE)
val colorPrimaryLightFg @Composable get() = if (isDark) Color(0xFF8AB89B) else Color(0xFF335C41)

val colorAccent @Composable get() = if (isDark) Color(0xFFC77733) else Color(0xFFD78A42)
val colorAccentFg = Color(0xFFFFFFFF)

val colorNavBg @Composable get() = if (isDark) Color(0xFF272A28) else Color(0xFFEAE5DB)
val colorNavFg @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorNavActivePill @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFDDD7CB)

val colorInputBg @Composable get() = if (isDark) Color(0xFF2A2D2B) else Color(0xFFF8F6F0)
val colorSendBg @Composable get() = if (isDark) Color(0xFF636765) else Color(0xFF898E8B)

val colorSuggestBg @Composable get() = if (isDark) Color(0xFF0D1C12) else Color(0xFFE3EDE5)
val colorSuggestInk @Composable get() = if (isDark) Color(0xFF65AF80) else Color(0xFF225134)

val colorOk @Composable get() = if (isDark) Color(0xFF6FCF97) else Color(0xFF1F7A4D)
val colorError @Composable get() = if (isDark) Color(0xFFF08A80) else Color(0xFFA8382F)

val arabicFont = FontFamily.Serif
val latinFont = FontFamily.SansSerif

var appPrefs: Prefs? = null

// --- Custom Web SVG Vectors Translated to Android ImageVectors ---

val Icons_SendArrow: ImageVector
    get() = ImageVector.Builder("Send", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(2.01f, 21f); lineTo(23f, 12f); lineTo(2.01f, 3f); lineTo(2f, 10f); lineTo(15f, 12f); lineTo(2f, 14f); close()
    }.build()

val Icons_History: ImageVector
    get() = ImageVector.Builder("History", 24.dp, 24.dp, 24f, 24f).path(stroke = SolidColor(Color.Black), strokeLineWidth = 2f) {
        moveTo(3f, 12f); curveToRelative(0f, -4.97f, 4.03f, -9f, 9f, -9f); curveToRelative(3.73f, 0f, 7.08f, 2.26f, 8.44f, 5.74f); lineTo(21f, 8f); moveTo(3f, 3f); lineTo(3f, 8f); lineTo(8f, 8f); moveTo(12f, 7f); lineTo(12f, 12f); lineTo(16f, 14f)
    }.build()

val Icons_DadBubble: ImageVector
    get() = ImageVector.Builder("Dad", 32.dp, 32.dp, 32f, 32f).path(fill = SolidColor(Color.White)) {
        moveTo(6f, 6f); lineToRelative(20f, 0f); curveToRelative(1.66f, 0f, 3f, 1.34f, 3f, 3f); lineToRelative(0f, 12f); curveToRelative(0f, 1.66f, -1.34f, 3f, -3f, 3f); lineToRelative(-8f, 0f); lineToRelative(-5f, 4f); lineToRelative(0f, -4f); lineTo(6f, 24f); curveToRelative(-1.66f, 0f, -3f, -1.34f, -3f, -3f); lineTo(3f, 9f); curveToRelative(0f, -1.66f, 1.34f, -3f, 3f, -3f); close()
    }.build()

val Icons_BrainProfile: ImageVector
    get() = ImageVector.Builder("Saved", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19f, 21f); lineToRelative(-7f, -5f); lineToRelative(-7f, 5f); lineTo(5f, 5f); curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f); lineToRelative(10f, 0f); curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f); close()
    }.build()

val Icons_GradCap: ImageVector
    get() = ImageVector.Builder("Practice", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(9f, 2f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineTo(3f, 4f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineToRelative(0f, 14f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f); lineToRelative(14f, 0f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f); lineTo(19f, 6f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineToRelative(-2f, 0f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineTo(9f, 2f); close(); moveTo(9f, 4f); lineToRelative(6f, 0f); lineToRelative(0f, 2f); lineTo(9f, 6f); lineTo(9f, 4f); close(); moveTo(15f, 11f); lineToRelative(-5.5f, 5.5f); lineTo(7f, 14f); lineToRelative(1.41f, -1.41f); lineTo(10f, 14.17f); lineToRelative(4.09f, -4.09f); lineTo(15f, 11f); close()
    }.build()

val Icons_SettingsGear: ImageVector
    get() = ImageVector.Builder("Settings", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19.14f, 12.94f); curveToRelative(0.04f, -0.3f, 0.06f, -0.61f, 0.06f, -0.94f); curveToRelative(0f, -0.32f, -0.02f, -0.64f, -0.07f, -0.94f); lineToRelative(2.03f, -1.58f); curveToRelative(0.18f, -0.14f, 0.23f, -0.41f, 0.12f, -0.61f); lineToRelative(-1.92f, -3.32f); curveToRelative(-0.12f, -0.22f, -0.37f, -0.29f, -0.59f, -0.22f); lineToRelative(-2.39f, 0.96f); curveToRelative(-0.5f, -0.38f, -1.03f, -0.7f, -1.62f, -0.94f); lineToRelative(-0.36f, -2.54f); curveToRelative(-0.04f, -0.24f, -0.24f, -0.42f, -0.5f, -0.42f); lineToRelative(-3.82f, 0f); curveToRelative(-0.25f, 0f, -0.46f, 0.18f, -0.5f, 0.42f); lineToRelative(-0.36f, 2.54f); curveToRelative(-0.59f, 0.24f, -1.13f, 0.57f, -1.62f, 0.94f); lineToRelative(-2.39f, -0.96f); curveToRelative(-0.23f, -0.09f, -0.49f, 0f, -0.59f, 0.22f); lineTo(2.71f, 8.87f); curveToRelative(-0.12f, 0.21f, -0.08f, 0.47f, 0.12f, 0.61f); lineToRelative(2.03f, 1.58f); curveToRelative(-0.05f, 0.3f, -0.07f, 0.63f, -0.07f, 0.94f); curveToRelative(0f, 0.31f, 0.02f, 0.64f, 0.07f, 0.94f); lineToRelative(-2.03f, 1.58f); curveToRelative(-0.18f, 0.14f, -0.23f, 0.41f, -0.12f, 0.61f); lineToRelative(1.92f, 3.32f); curveToRelative(0.12f, 0.22f, 0.37f, 0.29f, 0.59f, 0.22f); lineToRelative(2.39f, -0.96f); curveToRelative(0.5f, 0.38f, 1.03f, 0.7f, 1.62f, 0.94f); lineToRelative(0.36f, 2.54f); curveToRelative(0.05f, 0.24f, 0.25f, 0.42f, 0.5f, 0.42f); lineToRelative(3.82f, 0f); curveToRelative(0.25f, 0f, 0.46f, -0.18f, 0.5f, -0.42f); lineToRelative(0.36f, -2.54f); curveToRelative(0.59f, -0.24f, 1.13f, -0.56f, 1.62f, -0.94f); lineToRelative(2.39f, 0.96f); curveToRelative(0.22f, 0.08f, 0.47f, 0f, 0.59f, -0.22f); lineToRelative(1.92f, -3.32f); curveToRelative(0.12f, -0.22f, 0.07f, -0.47f, -0.12f, -0.61f); lineToRelative(-2.01f, -1.58f); close(); moveTo(12f, 15.6f); curveToRelative(-1.99f, 0f, -3.6f, -1.61f, -3.6f, -3.6f); curveToRelative(0f, -1.99f, 1.61f, -3.6f, 3.6f, -3.6f); curveToRelative(1.99f, 0f, 3.6f, 1.61f, 3.6f, 3.6f); curveToRelative(0f, 1.99f, -1.61f, 3.6f, -3.6f, 3.6f); close()
    }.build()

@Composable
fun KalimaRoot(vm: MainViewModel) {
    appPrefs = vm.prefs
    
    Box(Modifier.fillMaxSize().background(colorPaper)) {
        Column(Modifier.fillMaxSize()) {
            
            // Top Nav Bar
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.border(1.5.dp, colorPrimaryLight, RoundedCornerShape(50)).clip(RoundedCornerShape(50))
                        .clickable { vm.query = ""; vm.result = null; vm.translationOptions = null; vm.errorMsg = null }
                        .background(colorPrimaryLight).padding(horizontal = 18.dp, vertical = 6.dp)
                ) { Text("Clear", color = colorPrimaryLightFg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                
                Text("Translations", color = colorPrimaryLightFg, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                
                Box(
                    modifier = Modifier.size(38.dp).border(1.5.dp, colorLine, CircleShape).clip(CircleShape)
                        .clickable { vm.currentTab = "saved" }.background(colorPrimaryLight),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons_History, contentDescription = "History", tint = colorPrimaryLightFg, modifier = Modifier.size(20.dp)) }
            }
            
            // Tab Content Wrapper
            Box(Modifier.weight(1f)) {
                when (vm.currentTab) {
                    "lookup" -> LookupScreen(vm)
                    "saved" -> SavedScreen(vm)
                    "practice" -> PracticeScreen(vm)
                    "settings" -> SettingsScreen(vm)
                    else -> LookupScreen(vm)
                }
            }
        }
        
        // Floating Emerald Bottom Dock
        BottomDock(vm, Modifier.align(Alignment.BottomCenter))
    }
}

// --- Dynamic Empty State ---
@Composable
fun EmptyState(vm: MainViewModel) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colorSuggestBg)
            .clickable { vm.query = "كِتَابَةٌ"; vm.searchMode = "ar"; vm.lookup() }
            .padding(vertical = 40.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("كلمة مقترحة", color = colorMuted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Text("كِتَابَةٌ", color = colorSuggestInk, fontSize = 72.sp, fontWeight = FontWeight.Bold, fontFamily = arabicFont)
            Spacer(Modifier.height(16.dp))
            Text("Tap the word to study", color = colorMuted, fontSize = 14.sp)
        }
    }
}

// --- Fully Styled Floating Dock ---
@Composable
fun BottomDock(vm: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // 4 Action Pills
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val isSaved = vm.result?.word?.let { vm.isSaved(it) } == true
            DockPill(if (isSaved) "Saved ✓" else "Save", isSaved, { vm.toggleSave() }, Modifier.weight(1f))
            
            val isRev = vm.searchMode == "rev"
            DockPill(if (isRev) "Reverse" else "Ar Word", !isRev, { vm.searchMode = if(isRev) "ar" else "rev" }, Modifier.weight(1f))
            
            var showMode by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                DockPill(if (vm.lookupMode == "fast") "Fast" else "Deep", true, { showMode = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = showMode, onDismissRequest = { showMode = false }, modifier = Modifier.background(colorSurface)) {
                    DropdownMenuItem(text = { Text("Deep", color = colorInk) }, onClick = { vm.lookupMode = "deep"; showMode = false })
                    DropdownMenuItem(text = { Text("Fast", color = colorInk) }, onClick = { vm.lookupMode = "fast"; showMode = false })
                }
            }
            
            var showLang by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                val lName = when(vm.prefs.lang) { "ur"->"Urdu"; "fa"->"Farsi"; "tr"->"Turkish"; "ru"->"Russian"; else->"Off" }
                DockPill(lName, false, { showLang = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = showLang, onDismissRequest = { showLang = false }, modifier = Modifier.background(colorSurface)) {
                    listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off").forEach { (code, name) ->
                        DropdownMenuItem(text = { Text(name, color = colorInk) }, onClick = { vm.prefs.updateLang(code); globalThemeTrigger++; showLang = false })
                    }
                }
            }
        }
        
        // Fully Rounded Search Bar
        val isRev = vm.searchMode == "rev"
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).shadow(4.dp, RoundedCornerShape(50), spotColor = Color.Black.copy(0.05f))
                .background(colorInputBg, RoundedCornerShape(50)).border(1.dp, colorLine, RoundedCornerShape(50)).padding(start = 20.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(
                    color = colorInk, fontSize = if (isRev) 17.sp else 20.sp, 
                    fontFamily = if (isRev) latinFont else arabicFont,
                    textAlign = if (isRev) TextAlign.Left else TextAlign.Right,
                    textDirection = if (isRev) TextDirection.Ltr else TextDirection.Rtl
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.lookup() }),
                decorationBox = { innerTextField ->
                    if (vm.query.isEmpty()) {
                        Text(
                            text = if(isRev) "Find Arabic for..." else "اكتب كلمة أو ابحث...",
                            color = colorMuted, fontSize = if (isRev) 17.sp else 20.sp, fontFamily = if (isRev) latinFont else arabicFont,
                            textAlign = if (isRev) TextAlign.Left else TextAlign.Right, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    innerTextField()
                }
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(colorSendBg).clickable { vm.lookup() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons_SendArrow, contentDescription = "Search", tint = Color.White, modifier = Modifier.size(20.dp)) }
        }
        
        // SVG Vector Navigation Bottom Pill
        Row(
            modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(50), spotColor = Color.Black.copy(0.05f))
                .background(colorNavBg, RoundedCornerShape(50)).border(1.dp, colorLine, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Triple("lookup", Icons_DadBubble, "Lookup"), Triple("saved", Icons_BrainProfile, "Saved Words"),
                Triple("practice", Icons_GradCap, "Practice"), Triple("settings", Icons_SettingsGear, "Settings")
            )
            tabs.forEach { (tabId, icon, desc) ->
                val isActive = vm.currentTab == tabId
                Box(
                    modifier = Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(50))
                        .clickable { vm.currentTab = tabId }
                        .background(if (isActive) colorNavActivePill else Color.Transparent),
                    contentAlignment = Alignment.Center
                ) {
                    if (tabId == "lookup") {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = desc, modifier = Modifier.size(26.dp), tint = if (isActive) colorAccent else colorNavFg)
                            Text("ض", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = arabicFont, color = if(isActive) colorAccentFg else colorPaper, modifier = Modifier.offset(y = (-1).dp))
                        }
                    } else {
                        Icon(icon, contentDescription = desc, modifier = Modifier.size(24.dp), tint = if (isActive) colorAccent else colorNavFg)
                    }
                }
            }
        }
    }
}

@Composable
fun DockPill(text: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(50)).background(if (isActive) colorPrimary else colorPrimaryLight).clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = if (isActive) colorPrimaryFg else colorPrimaryLightFg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// --- Lookup Screen Wrapper ---
@Composable
fun LookupScreen(vm: MainViewModel) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp)
    ) {
        if (vm.loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = colorPrimary, strokeWidth = 2.dp)
                Text("Working on it...", color = colorPrimary, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.cancel() }) { Text("Stop", color = colorPrimary) }
            }
            Spacer(Modifier.height(16.dp))
        }

        val err = vm.errorMsg
        if (err != null) {
            Text(err, color = colorError)
            Spacer(Modifier.height(16.dp))
        }

        val opts = vm.translationOptions
        if (!opts.isNullOrEmpty()) {
            Text("Arabic for \"${vm.query}\"", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colorInk)
            Spacer(Modifier.height(6.dp))
            Text("Tap a word for the full breakdown.", color = colorMuted, fontSize = 15.sp, modifier = Modifier.padding(bottom = 14.dp))
            for (opt in opts) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(12.dp))
                        .clickable { 
                            vm.searchMode = "ar"
                            vm.query = opt.ar
                            vm.lookup() 
                        }.border(1.dp, colorLine, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = colorSurface)
                ) {
                    Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                            Text(opt.en, fontSize = 17.sp, color = colorInk, fontWeight = FontWeight.Medium)
                            if (opt.tx.isNotBlank()) Text(opt.tx, fontSize = 16.sp, color = colorMuted)
                        }
                        ArabicText(opt.ar, 34)
                    }
                }
            }
            Spacer(Modifier.height(200.dp))
        } else if (vm.result != null) {
            ResultView(vm.result!!, vm.prefs.lang, vm)
            Spacer(Modifier.height(200.dp))
        } else if (!vm.loading && err == null && opts.isNullOrEmpty()) {
            EmptyState(vm)
        }
    }
}

@Composable
fun ResultView(w: Word, lang: String, vm: MainViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, colorLine, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = colorSurface),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            RootBand(w, lang)
            
            if (w.forms.isNotEmpty()) {
                SectionDivider()
                Text("Words from this root", fontSize = 14.sp, color = colorMuted, modifier = Modifier.padding(bottom = 8.dp))
                // TextSections(w) -> This logic exists in HTML but requires expanding root list in Android if needed. 
            }
            
            SectionDivider()
            WordHead(w, vm)
            
            Spacer(Modifier.height(24.dp))
            MeaningSection(w, lang)
            
            if (w.examples.isNotEmpty()) {
                SectionDivider()
                ExamplesSection(w, lang)
            }
            
            val v = w.verb
            if (v != null) {
                SectionDivider()
                VerbSection(v, w, vm)
            }
            
            if (w.synonyms.isNotEmpty() || w.antonyms.isNotEmpty()) {
                SectionDivider()
                if (w.synonyms.isNotEmpty()) {
                    RelatedSection("Synonyms", w.synonyms, lang)
                    Spacer(Modifier.height(16.dp))
                }
                if (w.antonyms.isNotEmpty()) RelatedSection("Antonyms", w.antonyms, lang)
            }
            
            if (w.note.isNotBlank()) {
                SectionDivider()
                Text(w.note, color = colorMuted, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun SectionDivider() {
    Spacer(Modifier.height(26.dp))
    HorizontalDivider(color = colorLine)
    Spacer(Modifier.height(26.dp))
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colorPrimary, modifier = Modifier.padding(bottom = 14.dp))
}

@Composable
fun ArabicText(text: String, size: Int, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        color = colorInk,
        fontFamily = arabicFont,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.5f).sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
    )
}

@Composable
fun TxLine(text: String, lang: String) {
    if (lang == "off" || text.isBlank()) return
    val rtl = Langs.isRtl(lang)
    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Text(Langs.nativeNames[lang] ?: "", fontSize = 14.sp, color = colorMuted)
        Text(
            text = text,
            modifier = Modifier.weight(1f),
            color = colorInk,
            style = TextStyle(fontSize = 18.sp, lineHeight = 30.sp, textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr, textAlign = if (rtl) TextAlign.Right else TextAlign.Left)
        )
    }
}

@Composable
fun RootBand(w: Word, lang: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Root", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colorPrimary)
            if (w.root.isEmpty()) {
                Text("No root", color = colorInk)
            } else {
                if (w.rootGloss.isNotBlank()) Text(w.rootGloss, color = colorMuted, fontSize = 15.sp)
                TxLine(w.rootGlossTx, lang)
            }
        }
        if (w.root.isNotEmpty()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    for (letter in w.root) RootTile(letter)
                }
            }
        }
    }
}

@Composable
fun RootTile(letter: String) {
    Box(
        modifier = Modifier.size(width = 60.dp, height = 72.dp).clip(RoundedCornerShape(16.dp)).background(colorPrimary),
        contentAlignment = Alignment.Center
    ) {
        Text(text = letter, color = colorPrimaryFg, style = TextStyle(fontSize = 46.sp, textDirection = TextDirection.Rtl, fontWeight = FontWeight.Normal, fontFamily = arabicFont))
    }
}

@Composable
fun WordHead(w: Word, vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxWidth()) {
        ArabicText(w.word, 68, modifier = Modifier.fillMaxWidth())
        if (w.translit.isNotBlank()) Text(w.translit, fontSize = 20.sp, color = colorInk)
        
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (w.pos.isNotBlank()) {
                Text(
                    text = w.pos,
                    fontSize = 14.sp,
                    color = colorPrimary,
                    modifier = Modifier.border(1.5.dp, colorPrimary, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 2.dp)
                )
            }
            if (w.grammar.isNotBlank()) Text(w.grammar, fontSize = 15.sp, color = colorMuted)
        }
        
        if (w.waznPattern.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Wazn", fontSize = 14.sp, color = colorMuted)
                ArabicText(w.waznPattern, 28, bold = true)
                if (w.waznNote.isNotBlank()) Text(w.waznNote, fontSize = 15.sp, color = colorMuted, modifier = Modifier.weight(1f))
            }
        }
        
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { vm.speak(w.word) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = colorPrimary),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)
            ) { Text("🔊 Listen", color = colorPrimary) }
        }
    }
}

@Composable
fun MeaningSection(w: Word, lang: String) {
    SectionTitle("Meaning")
    Text("English", fontSize = 14.sp, color = colorMuted)
    Text(w.meaningEn, fontSize = 17.sp, color = colorInk)
    TxLine(w.meaningTx, lang)
    if (w.meaningAr.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        ArabicText(w.meaningAr, 24, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ExamplesSection(w: Word, lang: String) {
    SectionTitle("In a sentence")
    for ((i, ex) in w.examples.withIndex()) {
        if (i > 0) Spacer(Modifier.height(14.dp))
        ArabicText(ex.ar, 24, modifier = Modifier.fillMaxWidth())
        Text(ex.en, fontSize = 17.sp, color = colorInk)
        TxLine(ex.tx, lang)
    }
}

@Composable
fun VerbSection(v: Verb, w: Word, vm: MainViewModel) {
    SectionTitle("Verb")
    val formText = if (v.form.isNotBlank() && v.form.length <= 5 && v.form.all { it == 'I' || it == 'V' || it == 'X' }) "Form " + v.form else v.form
    if (formText.isNotBlank()) {
        Text("Verb form", fontSize = 14.sp, color = colorMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formText, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
            if (v.pattern.isNotBlank()) ArabicText(v.pattern, 24)
        }
        Spacer(Modifier.height(8.dp))
    }
    val tense = listOf(
        if (v.inputTense.isNotBlank()) v.inputTense.replaceFirstChar { it.uppercase() } + " tense" else "",
        v.inputPerson
    ).filter { it.isNotBlank() }.joinToString(", ")
    if (tense.isNotBlank()) {
        Text("Your word is", fontSize = 14.sp, color = colorMuted)
        Text(tense, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
        Spacer(Modifier.height(8.dp))
    }
    VerbFact("Dictionary form (he, past)", v.dictionaryForm)
    VerbFact("Present (he)", v.presentForm)
    VerbFact("Masdar (verbal noun)", v.masdar)
    if (v.masdarWazn.isNotBlank()) VerbFact("Masdar wazn", v.masdarWazn)

    Spacer(Modifier.height(24.dp))
    Text("All 14 forms", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colorInk)
    Spacer(Modifier.height(10.dp))
    
    if (vm.loadedConjs != null) {
        ConjTable(v, vm.loadedConjs!!)
    } else if (vm.conjLoading) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
            CircularProgressIndicator(color = colorPrimary, modifier = Modifier.size(32.dp))
        }
    } else {
        OutlinedButton(
            onClick = { vm.loadConjugations(v.dictionaryForm.ifBlank { w.word }) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = colorPrimary),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)
        ) {
            Text("Show 14x7 Conjugations", color = colorPrimary)
        }
    }
}

@Composable
fun VerbFact(label: String, value: String) {
    if (value.isBlank()) return
    Text(label, fontSize = 14.sp, color = colorMuted)
    ArabicText(value, 24, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
}

@Composable
fun ConjCell(text: String, hit: Boolean, hitColor: Color, widthDp: Dp) {
    Box(
        modifier = Modifier.width(widthDp).background(if (hit) hitColor else Color.Transparent).padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterEnd
    ) { ArabicText(text, 24) }
}

@Composable
fun ConjTable(v: Verb, conjs: org.json.JSONArray) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, colorLine, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = colorSurface)
    ) {
        Column(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text("Who", modifier = Modifier.width(120.dp), fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Past", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Present", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Subj.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Juss.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Imp.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Pas. Past", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Pas. Pres.", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
            }
            for (i in 0 until 14) {
                if (i == 0 || i == 6 || i == 12) HorizontalDivider(color = colorLine, thickness = 2.dp) else HorizontalDivider(color = colorSoftLine)
                val p = PRONOUNS[i]
                
                val item = conjs.optJSONObject(i) ?: org.json.JSONObject()
                val past = item.optString("past", "—").ifBlank { "—" }
                val present = item.optString("present", "—").ifBlank { "—" }
                val subj = item.optString("subjunctive", "—").ifBlank { "—" }
                val jussive = item.optString("jussive", "—").ifBlank { "—" }
                val imp = item.optString("imperative", "—").ifBlank { "—" }
                val pPast = item.optString("passivePast", "—").ifBlank { "—" }
                val pPres = item.optString("passivePresent", "—").ifBlank { "—" }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.width(120.dp).padding(horizontal = 14.dp, vertical = 6.dp)) {
                        ArabicText(p.first, 22, modifier = Modifier.fillMaxWidth())
                        Text(p.second, fontSize = 14.sp, color = colorInk)
                    }
                    ConjCell(past, v.matchIndex == i && v.matchTense == "past", colorPrimaryLight, 90.dp)
                    ConjCell(present, v.matchIndex == i && v.matchTense == "present", colorPrimaryLight, 90.dp)
                    ConjCell(subj, v.matchIndex == i && v.matchTense == "subjunctive", colorPrimaryLight, 90.dp)
                    ConjCell(jussive, v.matchIndex == i && v.matchTense == "jussive", colorPrimaryLight, 90.dp)
                    ConjCell(imp, v.matchIndex == i && v.matchTense == "imperative", colorPrimaryLight, 90.dp)
                    ConjCell(pPast, v.matchIndex == i && v.matchTense == "passivePast", colorPrimaryLight, 100.dp)
                    ConjCell(pPres, v.matchIndex == i && v.matchTense == "passivePresent", colorPrimaryLight, 100.dp)
                }
            }
        }
    }
}

@Composable
fun RelatedSection(title: String, items: List<Gloss>, lang: String) {
    SectionTitle(title)
    if (items.isEmpty()) {
        Text("None found.", color = colorMuted)
        return
    }
    for (g in items) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(g.en, fontSize = 15.sp, color = colorMuted)
                TxLine(g.tx, lang)
            }
            ArabicText(g.ar, 24)
        }
        HorizontalDivider(color = colorSoftLine)
    }
}

@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (opt in options) {
            val value = opt.first
            val label = opt.second
            val m = Modifier.weight(1f)
            if (value == selected) {
                Box(
                    modifier = m.border(1.dp, colorLine, RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(colorPrimary)
                        .clickable { onSelect(value) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = colorPrimaryFg, fontSize = 14.sp) }
            } else {
                Box(
                    modifier = m.border(1.dp, colorLine, RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(colorSurface)
                        .clickable { onSelect(value) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = colorInk, fontSize = 14.sp) }
            }
        }
    }
}

// --- Restructured Settings Screen ---
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    val context = LocalContext.current
    var pass by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }

    fun saveFields() {
        if (pass.isNotBlank()) p.updatePasscode(pass.trim())
        if (key.isNotBlank()) p.updateApiKey(key.trim())
        p.updateModel(if (model.isBlank()) Config.DEFAULT_MODEL else model.trim())
        p.updateProxyUrl(proxy.trim())
        pass = ""
        key = ""
    }

    LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 220.dp, top = 20.dp)) {
        item { Text("Settings", color = colorPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 20.dp)) }
        
        // Translations Mode
        item {
            Text("Translation shown with Arabic and English", color = colorMuted, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Segmented(
                options = listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off"),
                selected = p.lang,
                onSelect = { p.updateLang(it); globalThemeTrigger++ }
            )
            Spacer(Modifier.height(24.dp))
        }
        
        // Appearance
        item {
            Text("Appearance", color = colorMuted, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Segmented(
                options = listOf("system" to "System", "light" to "Light", "dark" to "Dark"),
                selected = p.theme,
                onSelect = { p.updateTheme(it); globalThemeTrigger++ }
            )
            Spacer(Modifier.height(24.dp))
        }
        
        // Refined AI Access
        item { Text("AI access", color = colorMuted, fontSize = 14.sp); Spacer(Modifier.height(6.dp)) }
        
        item {
            var expandClass by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable{ expandClass = !expandClass }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Class account", color = colorInk, fontSize = 16.sp)
                Text(if (p.passcode.isNotEmpty()) "Connected ✓" else "Not connected", color = if (p.passcode.isNotEmpty()) colorOk else colorMuted, fontSize = 14.sp)
            }
            AnimatedVisibility(expandClass) {
                Column(Modifier.padding(bottom = 12.dp)) {
                    BasicTextField(
                        value = pass, onValueChange = { pass = it },
                        textStyle = TextStyle(color = colorInk, fontSize = 16.sp),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().border(1.5.dp, colorLine, RoundedCornerShape(12.dp)).background(colorSurface, RoundedCornerShape(12.dp)).padding(14.dp),
                        decorationBox = { inner -> if (pass.isEmpty()) Text("Type the passcode", color = colorMuted) else inner() }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Text("Save", color = colorPrimary, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { saveFields(); expandClass = false }.padding(8.dp))
                        Spacer(Modifier.width(16.dp))
                        Text("Remove passcode", color = colorMuted, modifier = Modifier.clickable { p.updatePasscode(""); expandClass = false }.padding(8.dp))
                    }
                }
            }
            HorizontalDivider(color = colorSoftLine)
        }
        
        item {
            var expandPersonal by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable{ expandPersonal = !expandPersonal }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Personal Gemini key", color = colorInk, fontSize = 16.sp)
                Text(if (p.apiKey.isNotEmpty()) "Connected ✓" else "Optional", color = if (p.apiKey.isNotEmpty()) colorOk else colorMuted, fontSize = 14.sp)
            }
            AnimatedVisibility(expandPersonal) {
                Column(Modifier.padding(bottom = 12.dp)) {
                    BasicTextField(
                        value = key, onValueChange = { key = it },
                        textStyle = TextStyle(color = colorInk, fontSize = 16.sp), 
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().border(1.5.dp, colorLine, RoundedCornerShape(12.dp)).background(colorSurface, RoundedCornerShape(12.dp)).padding(14.dp),
                        decorationBox = { inner -> if (key.isEmpty()) Text("Paste your key", color = colorMuted) else inner() }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Text("Save", color = colorPrimary, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { saveFields(); expandPersonal = false }.padding(8.dp))
                        Spacer(Modifier.width(16.dp))
                        Text("Remove key", color = colorMuted, modifier = Modifier.clickable { p.updateApiKey(""); expandPersonal = false }.padding(8.dp))
                    }
                }
            }
            HorizontalDivider(color = colorSoftLine)
        }
        
        // Advanced Section
        item {
            var expandAdv by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable{ expandAdv = !expandAdv }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Advanced", color = colorInk, fontSize = 16.sp)
            }
            AnimatedVisibility(expandAdv) {
                Column(Modifier.padding(bottom = 12.dp)) {
                    Text("Model/Server Configuration", color = colorMuted, fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    BasicTextField(
                        value = model, onValueChange = { model = it },
                        textStyle = TextStyle(color = colorInk, fontSize = 16.sp),
                        modifier = Modifier.fillMaxWidth().border(1.5.dp, colorLine, RoundedCornerShape(12.dp)).background(colorSurface, RoundedCornerShape(12.dp)).padding(14.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Class server address", color = colorMuted, fontSize = 14.sp)
                    BasicTextField(
                        value = proxy, onValueChange = { proxy = it },
                        textStyle = TextStyle(color = colorInk, fontSize = 16.sp),
                        modifier = Modifier.fillMaxWidth().border(1.5.dp, colorLine, RoundedCornerShape(12.dp)).background(colorSurface, RoundedCornerShape(12.dp)).padding(14.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Save configuration", color = colorPrimary, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { saveFields(); expandAdv = false }.padding(8.dp))
                }
            }
            HorizontalDivider(color = colorSoftLine)
        }
        
        item {
            Spacer(Modifier.height(32.dp))
            OutlinedButton(
                onClick = {
                    val data = vm.exportData()
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TITLE, "Kalima_Backup.json")
                        putExtra(Intent.EXTRA_TEXT, data)
                    }
                    context.startActivity(Intent.createChooser(intent, "Save or Share Backup"))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = colorPrimary),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)
            ) { Text("Export backup") }
        }
    }
}

// Scaffold stand-ins for Practice and Saved
@Composable
fun PracticeScreen(viewModel: MainViewModel) {
    Text("Practice Screen (Porting logic in progress)", Modifier.padding(20.dp), color = colorInk)
}

@Composable
fun SavedScreen(viewModel: MainViewModel) {
    Text("Saved Words Screen (Porting logic in progress)", Modifier.padding(20.dp), color = colorInk)
}
