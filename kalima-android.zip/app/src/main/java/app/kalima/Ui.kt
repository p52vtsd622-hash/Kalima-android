package app.kalima

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Define the precise color schemes
val LightColors = lightColorScheme(
    background = Color(0xFFF3F5F8),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE7EBF2),
    primary = Color(0xFF274690), // Original Blue
    onPrimary = Color.White,
    outline = Color(0xFFD8DEE8),
    onSurfaceVariant = Color(0xFF5A6479)
)

val DarkColors = darkColorScheme(
    background = Color(0xFF000000), // Pure Black
    surface = Color(0xFF121212),
    surfaceVariant = Color(0xFF1A1A1A),
    primary = Color(0xFFFFC107), // Crisp Amber/Gold
    onPrimary = Color.Black,
    outline = Color(0xFF333333),
    onSurfaceVariant = Color(0xFFA0A0A0)
)

@Composable
fun KalimaRoot(vm: MainViewModel) {
    val dark = when (vm.prefs.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        Scaffold(
            bottomBar = { BottomPanel(vm) },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                when (vm.currentTab) {
                    "lookup" -> LookupScreen(vm)
                    "saved" -> SavedScreen(vm)
                    "practice" -> PracticeScreen(vm)
                    "settings" -> SettingsScreen(vm)
                    else -> LookupScreen(vm)
                }
            }
        }
    }
}

@Composable
fun BottomPanel(vm: MainViewModel) {
    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ActionTogglesRow(vm)
            Spacer(Modifier.height(12.dp))
            SearchBarRow(vm)
            Spacer(Modifier.height(16.dp))
            BottomNavRow(vm)
        }
    }
}

@Composable
fun ActionTogglesRow(vm: MainViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Save Button
        val saved = vm.result?.let { vm.isSaved(it.word) } ?: false
        PillButton(
            text = if (saved) "Saved" else "Save",
            onClick = { vm.toggleSave() },
            enabled = vm.result != null,
            isActive = saved
        )

        // Analysis Mode Dropdown
        Box {
            var expanded by remember { mutableStateOf(false) }
            val label = if (vm.lookupMode == "fast") "Fast" else "Deep"
            PillButton(text = label, onClick = { expanded = true }, isActive = true)
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            ) {
                DropdownMenuItem(text = { Text("Fast", color = MaterialTheme.colorScheme.onSurface) }, onClick = { vm.lookupMode = "fast"; expanded = false })
                DropdownMenuItem(text = { Text("Deep", color = MaterialTheme.colorScheme.onSurface) }, onClick = { vm.lookupMode = "deep"; expanded = false })
            }
        }

        // Language Dropdown
        Box {
            var expanded by remember { mutableStateOf(false) }
            val currentLang = if (vm.prefs.lang == "off") "Off" else Langs.names[vm.prefs.lang] ?: "Off"
            PillButton(text = currentLang, onClick = { expanded = true }, isActive = vm.prefs.lang != "off")
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            ) {
                val langs = listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off")
                langs.forEach { (code, name) ->
                    DropdownMenuItem(text = { Text(name, color = MaterialTheme.colorScheme.onSurface) }, onClick = { vm.prefs.updateLang(code); expanded = false })
                }
            }
        }
    }
}

@Composable
fun PillButton(text: String, onClick: () -> Unit, enabled: Boolean = true, isActive: Boolean = false) {
    val bgColor = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = bgColor,
            contentColor = textColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(50),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
        modifier = Modifier.height(40.dp)
    ) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun SearchBarRow(vm: MainViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            textStyle = TextStyle(
                color = MaterialTheme.colorScheme.onSurface, 
                fontSize = 20.sp, 
                textAlign = TextAlign.Right, 
                textDirection = TextDirection.ContentOrRtl
            ),
            singleLine = true,
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardActions = KeyboardActions(onSearch = { vm.lookup() }),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            decorationBox = { innerTextField ->
                if (vm.query.isEmpty()) {
                    Text(
                        "اكتب كلمة", 
                        color = MaterialTheme.colorScheme.onSurfaceVariant, 
                        fontSize = 20.sp, 
                        textAlign = TextAlign.Right, 
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                innerTextField()
            }
        )

        IconButton(
            onClick = { vm.lookup() },
            modifier = Modifier
                .padding(end = 4.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape)
                .size(44.dp)
        ) {
            Icon(Icons.Default.ArrowForward, contentDescription = "Search", tint = MaterialTheme.colorScheme.onPrimary)
        }
    }
}

@Composable
fun BottomNavRow(vm: MainViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavIconBox(text = "ك", selected = vm.currentTab == "lookup") { vm.currentTab = "lookup" }
        NavIconBox(text = "💾", selected = vm.currentTab == "saved") { vm.currentTab = "saved" }
        NavIconBox(text = "🧠", selected = vm.currentTab == "practice") { vm.currentTab = "practice" }
        NavIconBox(text = "⚙️", selected = vm.currentTab == "settings") { vm.currentTab = "settings" }
    }
}

@Composable
fun NavIconBox(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LookupScreen(vm: MainViewModel) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp)
    ) {
        if (vm.loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
                Text("Working on it...", color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.cancel() }) { Text("Stop", color = MaterialTheme.colorScheme.primary) }
            }
            Spacer(Modifier.height(16.dp))
        }

        val err = vm.errorMsg
        if (err != null) {
            Text(err, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(16.dp))
        }

        val opts = vm.translationOptions
        if (!opts.isNullOrEmpty()) {
            Text("Translations for \"${vm.query}\"", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(12.dp))
            for (opt in opts) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(12.dp))
                        .clickable { vm.query = opt.ar; vm.lookup() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                            Text(opt.en, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                            if (opt.tx.isNotBlank()) Text(opt.tx, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        ArabicText(opt.ar, 28)
                    }
                }
            }
        }

        val w = vm.result
        if (w != null) {
            ResultView(w, vm.prefs.lang, vm)
        } else if (!vm.loading && err == null && opts.isNullOrEmpty()) {
            // Placard: Suggested Word
            val examples = listOf("كِتَابَةٌ", "مَدْرَسَة", "سَعِيد", "يَسْتَخْدِمُونَ")
            val suggested = remember { examples.random() }
            
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.query = suggested; vm.lookup() },
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Suggested Word", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))
                    ArabicText(suggested, 56)
                    Spacer(Modifier.height(16.dp))
                    Text("Tap to look up", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

/* ---------------- result ---------------- */

@Composable
fun ResultView(w: Word, lang: String, vm: MainViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
            RootBand(w, lang)
            
            if (w.forms.isNotEmpty()) {
                SectionDivider()
                Text("Words from this root", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                TextSections(w)
            }
            
            SectionDivider()
            WordHead(w, vm)
            
            Spacer(Modifier.height(24.dp))
            MeaningSection(w, lang)
            
            if (w.examples.isNotEmpty()) {
                SectionDivider()
                ExamplesSection(w, lang)
            }
            
            val v = w.verb
            if (v != null) {
                SectionDivider()
                VerbSection(v)
            }
            
            if (w.synonyms.isNotEmpty() || w.antonyms.isNotEmpty()) {
                SectionDivider()
                if (w.synonyms.isNotEmpty()) {
                    RelatedSection("Synonyms", w.synonyms, lang)
                    Spacer(Modifier.height(16.dp))
                }
                if (w.antonyms.isNotEmpty()) RelatedSection("Antonyms", w.antonyms, lang)
            }
            
            if (w.note.isNotBlank()) {
                SectionDivider()
                Text(w.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun SectionDivider() {
    Spacer(Modifier.height(16.dp))
    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
    Spacer(Modifier.height(16.dp))
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
fun ArabicText(text: String, size: Int, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        color = MaterialTheme.colorScheme.onSurface,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.7f).sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
    )
}

@Composable
fun TxLine(text: String, lang: String) {
    if (lang == "off" || text.isBlank()) return
    val rtl = Langs.isRtl(lang)
    Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Text(Langs.nativeNames[lang] ?: "", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = text,
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.onSurface,
            style = TextStyle(fontSize = 18.sp, lineHeight = 30.sp, textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr, textAlign = if (rtl) TextAlign.Right else TextAlign.Left)
        )
    }
}

@Composable
fun RootBand(w: Word, lang: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Root", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (w.root.isEmpty()) {
                Text("No root", color = MaterialTheme.colorScheme.onSurface)
            } else {
                if (w.rootGloss.isNotBlank()) Text(w.rootGloss, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp)
                TxLine(w.rootGlossTx, lang)
            }
        }
        if (w.root.isNotEmpty()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (letter in w.root) RootTile(letter)
                }
            }
        }
    }
}

@Composable
fun RootTile(letter: String) {
    Box(
        modifier = Modifier.size(width = 46.dp, height = 52.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(text = letter, color = MaterialTheme.colorScheme.onPrimary, style = TextStyle(fontSize = 28.sp, textDirection = TextDirection.Rtl, fontWeight = FontWeight.Bold))
    }
}

@Composable
fun WordHead(w: Word, vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxWidth()) {
        ArabicText(w.word, 56, modifier = Modifier.fillMaxWidth())
        if (w.translit.isNotBlank()) Text(w.translit, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
        
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (w.pos.isNotBlank()) {
                Text(
                    text = w.pos,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
            if (w.grammar.isNotBlank()) Text(w.grammar, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        
        if (w.waznPattern.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Wazn", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ArabicText(w.waznPattern, 22, bold = true)
                if (w.waznNote.isNotBlank()) Text(w.waznNote, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            }
        }
        
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val saved = vm.isSaved(w.word)
            OutlinedButton(
                onClick = { vm.toggleSave() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
            ) { Text(if (saved) "Saved ✓" else "Save word") }
            
            OutlinedButton(
                onClick = { vm.speak(w.word) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
            ) { Text("🔊 Listen") }
        }
    }
}

@Composable
fun MeaningSection(w: Word, lang: String) {
    SectionTitle("Meaning")
    Text("English", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(w.meaningEn, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
    TxLine(w.meaningTx, lang)
    if (w.meaningAr.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        ArabicText(w.meaningAr, 24, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ExamplesSection(w: Word, lang: String) {
    SectionTitle("In a sentence")
    for ((i, ex) in w.examples.withIndex()) {
        if (i > 0) Spacer(Modifier.height(14.dp))
        ArabicText(ex.ar, 24, modifier = Modifier.fillMaxWidth())
        Text(ex.en, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
        TxLine(ex.tx, lang)
    }
}

@Composable
fun VerbSection(v: Verb) {
    SectionTitle("Verb")
    val formText = if (v.form.isNotBlank() && v.form.length <= 5 && v.form.all { it == 'I' || it == 'V' || it == 'X' }) "Form " + v.form else v.form
    if (formText.isNotBlank()) {
        Text("Verb form", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formText, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            if (v.pattern.isNotBlank()) ArabicText(v.pattern, 22)
        }
        Spacer(Modifier.height(8.dp))
    }
    val tense = listOf(
        if (v.inputTense.isNotBlank()) v.inputTense.replaceFirstChar { it.uppercase() } + " tense" else "",
        v.inputPerson
    ).filter { it.isNotBlank() }.joinToString(", ")
    if (tense.isNotBlank()) {
        Text("Your word is", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(tense, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
    }
    VerbFact("Dictionary form (he, past)", v.dictionaryForm)
    VerbFact("Present (he)", v.presentForm)
    VerbFact("Masdar (verbal noun)", v.masdar)
    if (v.masdarWazn.isNotBlank()) VerbFact("Masdar wazn", v.masdarWazn)

    Spacer(Modifier.height(12.dp))
    Text("All 14 forms", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    ConjTable(v)
}

@Composable
fun VerbFact(label: String, value: String) {
    if (value.isBlank()) return
    Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    ArabicText(value, 24, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(4.dp))
}

@Composable
fun ConjCell(text: String, hit: Boolean, hitColor: Color, widthDp: Dp) {
    Box(
        modifier = Modifier.width(widthDp).background(if (hit) hitColor else Color.Transparent).padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterEnd
    ) { ArabicText(text, 20) }
}

@Composable
fun ConjTable(v: Verb) {
    // Determine highlight color based on background luminance
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val hitColor = if (isDark) Color(0xFF3A2D0C) else Color(0xFFFFEDB8) 
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)) {
                Text("Who", modifier = Modifier.width(120.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Past", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Present", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Subj.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Juss.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Imp.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Pas. Past", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Pas. Pres.", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            for (i in 0 until 14) {
                if (i == 0 || i == 6 || i == 12) HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                val p = PRONOUNS[i]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.width(120.dp).padding(horizontal = 6.dp, vertical = 4.dp)) {
                        ArabicText(p.first, 20, modifier = Modifier.fillMaxWidth())
                        Text(p.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ConjCell(v.past[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "past", hitColor, 90.dp)
                    ConjCell(v.present[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "present", hitColor, 90.dp)
                    ConjCell(v.subjunctive[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "subjunctive", hitColor, 90.dp)
                    ConjCell(v.jussive[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "jussive", hitColor, 90.dp)
                    ConjCell(v.imperative[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "imperative", hitColor, 90.dp)
                    ConjCell(v.passivePast[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "passivePast", hitColor, 100.dp)
                    ConjCell(v.passivePresent[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "passivePresent", hitColor, 100.dp)
                }
            }
        }
    }
}

@Composable
fun RelatedSection(title: String, items: List<Gloss>, lang: String) {
    SectionTitle(title)
    if (items.isEmpty()) {
        Text("None found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    for (g in items) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(g.en, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                TxLine(g.tx, lang)
            }
            ArabicText(g.ar, 24)
        }
    }
}

/* ---------------- settings ---------------- */

@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (opt in options) {
            val value = opt.first
            val label = opt.second
            val m = Modifier.weight(1f)
            if (value == selected) {
                Button(
                    onClick = { onSelect(value) },
                    modifier = m,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) { Text(label, fontSize = 12.sp, maxLines = 1) }
            } else {
                OutlinedButton(
                    onClick = { onSelect(value) },
                    modifier = m,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) { Text(label, fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    val context = LocalContext.current
    var pass by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }

    fun saveFields() {
        if (pass.isNotBlank()) p.updatePasscode(pass.trim())
        if (key.isNotBlank()) p.updateApiKey(key.trim())
        p.updateModel(if (model.isBlank()) Config.DEFAULT_MODEL else model.trim())
        p.updateProxyUrl(proxy.trim())
        pass = ""
        key = ""
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(24.dp))
        
        Text("Translation shown with Arabic and English", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Segmented(
            options = listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off"),
            selected = p.lang,
            onSelect = { p.updateLang(it) }
        )
        Spacer(Modifier.height(24.dp))

        Text("Appearance", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Segmented(
            options = listOf("system" to "System", "light" to "Light", "dark" to "Dark"),
            selected = p.theme,
            onSelect = { p.updateTheme(it) }
        )
        Spacer(Modifier.height(24.dp))

        if (proxy.isNotBlank()) {
            Text("How to reach Gemini", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Segmented(
                options = listOf("shared" to "Class passcode", "own" to "My own key"),
                selected = if (p.useShared()) "shared" else "own",
                onSelect = { p.updateAccess(it) }
            )
            Spacer(Modifier.height(12.dp))
        }

        if (p.useShared()) {
            OutlinedTextField(
                value = pass, onValueChange = { pass = it },
                label = { Text("Class passcode") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            Text(if (p.passcode.isNotBlank()) "Passcode saved on this phone." else "No passcode yet.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            OutlinedTextField(
                value = key, onValueChange = { key = it },
                label = { Text("Gemini API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            Text(if (p.apiKey.isNotBlank()) "Key saved on this phone." else "No key yet.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = model, onValueChange = { model = it },
                label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = proxy, onValueChange = { proxy = it },
            label = { Text("Class server address") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Text("Leave empty to always use your own key.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        
        Spacer(Modifier.height(32.dp))
        Text("Data & Backup", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        OutlinedButton(
            onClick = {
                val data = vm.exportData()
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "Kalima_Backup.json")
                    putExtra(Intent.EXTRA_TEXT, data)
                }
                context.startActivity(Intent.createChooser(intent, "Save or Share Backup"))
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) { Text("Export Saved Words") }
        
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = { saveFields(); vm.currentTab = "lookup" },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
        ) { Text("Save Settings") }
        Spacer(Modifier.height(64.dp)) // padding for bottom nav
    }
}
