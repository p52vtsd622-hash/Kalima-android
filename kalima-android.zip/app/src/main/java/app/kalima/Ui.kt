package app.kalima

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import android.app.Activity
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- Global Theme Variables & State Trigger ---
var globalThemeTrigger by mutableStateOf(0)

val isDark: Boolean
    @Composable get() = when (appPrefs?.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }.also { globalThemeTrigger }

// --- Exact Web V2 Emerald & Cream Palette ---
val colorPaper @Composable get() = if (isDark) Color(0xFF161718) else Color(0xFFF8F6F0)
val colorSurface @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFFFFFFF)
val colorField @Composable get() = if (isDark) Color(0xFF252726) else Color(0xFFFFFFFF)
val colorInk @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorMuted @Composable get() = if (isDark) Color(0xFF828683) else Color(0xFF6A7A71)
val colorLine @Composable get() = if (isDark) Color(0xFF2D302E) else Color(0xFFDEDAD1)
val colorSoftLine @Composable get() = if (isDark) Color(0xFF222423) else Color(0xFFEBE7DF)

val colorPrimary = Color(0xFF4A835C)
val colorPrimaryFg = Color(0xFFFFFFFF)
val colorPrimaryLight @Composable get() = if (isDark) Color(0xFF1F3226) else Color(0xFFDCE5DE)
val colorPrimaryLightFg @Composable get() = if (isDark) Color(0xFF8AB89B) else Color(0xFF335C41)

val colorAccent @Composable get() = if (isDark) Color(0xFFC77733) else Color(0xFFD78A42)
val colorAccentFg = Color(0xFFFFFFFF)

val colorNavBg @Composable get() = if (isDark) Color(0xFF272A28) else Color(0xFFEAE5DB)
val colorNavFg @Composable get() = if (isDark) Color(0xFFE0E2E0) else Color(0xFF1D231F)
val colorNavActivePill @Composable get() = if (isDark) Color(0xFF1B1D1C) else Color(0xFFDDD7CB)

val colorInputBg @Composable get() = if (isDark) Color(0xFF2A2D2B) else Color(0xFFF8F6F0)
val colorSendBg @Composable get() = if (isDark) Color(0xFF636765) else Color(0xFF898E8B)

val colorSuggestBg @Composable get() = if (isDark) Color(0xFF0D1C12) else Color(0xFFE3EDE5)
val colorSuggestInk @Composable get() = if (isDark) Color(0xFF65AF80) else Color(0xFF225134)

val colorOk @Composable get() = if (isDark) Color(0xFF6FCF97) else Color(0xFF1F7A4D)
val colorError @Composable get() = if (isDark) Color(0xFFF08A80) else Color(0xFFA8382F)


var appPrefs: Prefs? = null

// --- Custom Web SVG Vectors Translated to Android ImageVectors ---

val Icons_SendArrow: ImageVector
    get() = ImageVector.Builder("Send", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(2.01f, 21f); lineTo(23f, 12f); lineTo(2.01f, 3f); lineTo(2f, 10f); lineTo(15f, 12f); lineTo(2f, 14f); close()
    }.build()

val Icons_History: ImageVector
    get() = ImageVector.Builder("History", 24.dp, 24.dp, 24f, 24f).path(stroke = SolidColor(Color.Black), strokeLineWidth = 2f) {
        moveTo(3f, 12f); curveToRelative(0f, -4.97f, 4.03f, -9f, 9f, -9f); curveToRelative(3.73f, 0f, 7.08f, 2.26f, 8.44f, 5.74f); lineTo(21f, 8f); moveTo(3f, 3f); lineTo(3f, 8f); lineTo(8f, 8f); moveTo(12f, 7f); lineTo(12f, 12f); lineTo(16f, 14f)
    }.build()

val Icons_DadBubble: ImageVector
    get() = ImageVector.Builder("Dad", 32.dp, 32.dp, 32f, 32f).path(fill = SolidColor(Color.White)) {
        moveTo(6f, 6f); lineToRelative(20f, 0f); curveToRelative(1.66f, 0f, 3f, 1.34f, 3f, 3f); lineToRelative(0f, 12f); curveToRelative(0f, 1.66f, -1.34f, 3f, -3f, 3f); lineToRelative(-8f, 0f); lineToRelative(-5f, 4f); lineToRelative(0f, -4f); lineTo(6f, 24f); curveToRelative(-1.66f, 0f, -3f, -1.34f, -3f, -3f); lineTo(3f, 9f); curveToRelative(0f, -1.66f, 1.34f, -3f, 3f, -3f); close()
    }.build()

val Icons_BrainProfile: ImageVector
    get() = ImageVector.Builder("Saved", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19f, 21f); lineToRelative(-7f, -5f); lineToRelative(-7f, 5f); lineTo(5f, 5f); curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f); lineToRelative(10f, 0f); curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f); close()
    }.build()

val Icons_GradCap: ImageVector
    get() = ImageVector.Builder("Practice", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(9f, 2f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineTo(3f, 4f); curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f); lineToRelative(0f, 14f); curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f); lineToRelative(14f, 0f); curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f); lineTo(19f, 6f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineToRelative(-2f, 0f); curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f); lineTo(9f, 2f); close(); moveTo(9f, 4f); lineToRelative(6f, 0f); lineToRelative(0f, 2f); lineTo(9f, 6f); lineTo(9f, 4f); close(); moveTo(15f, 11f); lineToRelative(-5.5f, 5.5f); lineTo(7f, 14f); lineToRelative(1.41f, -1.41f); lineTo(10f, 14.17f); lineToRelative(4.09f, -4.09f); lineTo(15f, 11f); close()
    }.build()

val Icons_SettingsGear: ImageVector
    get() = ImageVector.Builder("Settings", 24.dp, 24.dp, 24f, 24f).path(fill = SolidColor(Color.White)) {
        moveTo(19.14f, 12.94f); curveToRelative(0.04f, -0.3f, 0.06f, -0.61f, 0.06f, -0.94f); curveToRelative(0f, -0.32f, -0.02f, -0.64f, -0.07f, -0.94f); lineToRelative(2.03f, -1.58f); curveToRelative(0.18f, -0.14f, 0.23f, -0.41f, 0.12f, -0.61f); lineToRelative(-1.92f, -3.32f); curveToRelative(-0.12f, -0.22f, -0.37f, -0.29f, -0.59f, -0.22f); lineToRelative(-2.39f, 0.96f); curveToRelative(-0.5f, -0.38f, -1.03f, -0.7f, -1.62f, -0.94f); lineToRelative(-0.36f, -2.54f); curveToRelative(-0.04f, -0.24f, -0.24f, -0.42f, -0.5f, -0.42f); lineToRelative(-3.82f, 0f); curveToRelative(-0.25f, 0f, -0.46f, 0.18f, -0.5f, 0.42f); lineToRelative(-0.36f, 2.54f); curveToRelative(-0.59f, 0.24f, -1.13f, 0.57f, -1.62f, 0.94f); lineToRelative(-2.39f, -0.96f); curveToRelative(-0.23f, -0.09f, -0.49f, 0f, -0.59f, 0.22f); lineTo(2.71f, 8.87f); curveToRelative(-0.12f, 0.21f, -0.08f, 0.47f, 0.12f, 0.61f); lineToRelative(2.03f, 1.58f); curveToRelative(-0.05f, 0.3f, -0.07f, 0.63f, -0.07f, 0.94f); curveToRelative(0f, 0.31f, 0.02f, 0.64f, 0.07f, 0.94f); lineToRelative(-2.03f, 1.58f); curveToRelative(-0.18f, 0.14f, -0.23f, 0.41f, -0.12f, 0.61f); lineToRelative(1.92f, 3.32f); curveToRelative(0.12f, 0.22f, 0.37f, 0.29f, 0.59f, 0.22f); lineToRelative(2.39f, -0.96f); curveToRelative(0.5f, 0.38f, 1.03f, 0.7f, 1.62f, 0.94f); lineToRelative(0.36f, 2.54f); curveToRelative(0.05f, 0.24f, 0.25f, 0.42f, 0.5f, 0.42f); lineToRelative(3.82f, 0f); curveToRelative(0.25f, 0f, 0.46f, -0.18f, 0.5f, -0.42f); lineToRelative(0.36f, -2.54f); curveToRelative(0.59f, -0.24f, 1.13f, -0.56f, 1.62f, -0.94f); lineToRelative(2.39f, 0.96f); curveToRelative(0.22f, 0.08f, 0.47f, 0f, 0.59f, -0.22f); lineToRelative(1.92f, -3.32f); curveToRelative(0.12f, -0.22f, 0.07f, -0.47f, -0.12f, -0.61f); lineToRelative(-2.01f, -1.58f); close(); moveTo(12f, 15.6f); curveToRelative(-1.99f, 0f, -3.6f, -1.61f, -3.6f, -3.6f); curveToRelative(0f, -1.99f, 1.61f, -3.6f, 3.6f, -3.6f); curveToRelative(1.99f, 0f, 3.6f, 1.61f, 3.6f, 3.6f); curveToRelative(0f, 1.99f, -1.61f, 3.6f, -3.6f, 3.6f); close()
    }.build()

@Composable
fun KalimaRoot(vm: MainViewModel) {
    appPrefs = vm.prefs
    val dark = isDark
    val activity = LocalContext.current as? Activity
    val background = colorPaper
    SideEffect {
        activity?.window?.let { window ->
            window.statusBarColor = background.toArgb()
            window.navigationBarColor = background.toArgb()
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    KalimaTheme(dark) {
        Box(Modifier.fillMaxSize().background(colorPaper).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Column(Modifier.widthIn(max = 760.dp).fillMaxSize().align(Alignment.TopCenter)) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.border(1.5.dp, colorPrimary, RoundedCornerShape(50)).clip(RoundedCornerShape(50))
                        .clickable { vm.clear() }.background(colorSurface).padding(horizontal = 18.dp, vertical = 6.dp)) {
                        Text("Clear", color = colorPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(when (vm.currentTab) { "saved" -> "Saved words"; "practice" -> "Practice"; "settings" -> "Settings"; "history" -> "Recent searches"; else -> "Translations" },
                        color = colorPrimary, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Box(Modifier.size(38.dp).border(1.5.dp, colorPrimary, CircleShape).clip(CircleShape)
                        .clickable { vm.currentTab = "history" }.background(colorSurface), contentAlignment = Alignment.Center) {
                        Icon(Icons_History, contentDescription = "Recent searches", tint = colorPrimary, modifier = Modifier.size(20.dp))
                    }
                }
                vm.notice?.let { message ->
                    Row(Modifier.fillMaxWidth().background(colorPrimaryLight).padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(message, color = colorPrimaryLightFg, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { vm.notice = null }) { Text("Dismiss") }
                    }
                }
                Box(Modifier.weight(1f)) {
                    when (vm.currentTab) {
                        "saved" -> SavedScreen(vm)
                        "practice" -> PracticeScreen(vm)
                        "settings" -> SettingsScreen(vm)
                        "history" -> HistoryScreen(vm)
                        else -> LookupScreen(vm)
                    }
                }
                BottomDock(vm)
            }
        }
    }
}

// --- Dynamic Empty State ---
@Composable
fun EmptyState(vm: MainViewModel) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colorSuggestBg)
            .clickable { vm.query = "كِتَابَةٌ"; vm.searchMode = "ar"; vm.lookup() }
            .padding(vertical = 40.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("كلمة مقترحة", color = colorMuted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Text("كِتَابَةٌ", color = colorSuggestInk, fontSize = 72.sp, fontWeight = FontWeight.Bold, fontFamily = arabicFont)
            Spacer(Modifier.height(16.dp))
            Text("Tap the word to study", color = colorMuted, fontSize = 14.sp)
        }
    }
}

// --- Fully Styled Floating Dock ---
@Composable
fun BottomDock(vm: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // 4 Action Pills
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val isSaved = vm.result?.word?.let { vm.isSaved(it) } == true
            DockPill(if (isSaved) "Saved ✓" else "Save", isSaved, { vm.toggleSave() }, Modifier.weight(1f))
            
            val isRev = vm.searchMode == "rev"
            DockPill(if (isRev) "Reverse" else "Ar Word", !isRev, { vm.searchMode = if(isRev) "ar" else "rev" }, Modifier.weight(1f))
            
            var showMode by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                DockPill(if (vm.lookupMode == "fast") "Fast" else "Deep", true, { showMode = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = showMode, onDismissRequest = { showMode = false }, modifier = Modifier.background(colorSurface)) {
                    DropdownMenuItem(text = { Text("Deep", color = colorInk) }, onClick = { vm.lookupMode = "deep"; showMode = false })
                    DropdownMenuItem(text = { Text("Fast", color = colorInk) }, onClick = { vm.lookupMode = "fast"; showMode = false })
                }
            }
            
            var showLang by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                val lName = Langs.nativeNames[vm.prefs.lang] ?: "Off"
                DockPill(lName, false, { showLang = true }, Modifier.fillMaxWidth())
                DropdownMenu(expanded = showLang, onDismissRequest = { showLang = false }, modifier = Modifier.background(colorSurface)) {
                    listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off").forEach { (code, name) ->
                        DropdownMenuItem(text = { Text(name, color = colorInk) }, onClick = { vm.changeLanguage(code); showLang = false })
                    }
                }
            }
        }
        
        // Fully Rounded Search Bar
        val isRev = vm.searchMode == "rev"
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).shadow(4.dp, RoundedCornerShape(50), spotColor = Color.Black.copy(0.05f))
                .background(colorInputBg, RoundedCornerShape(50)).border(1.dp, colorLine, RoundedCornerShape(50)).padding(start = 20.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(
                    color = colorInk, fontSize = if (isRev) 17.sp else 20.sp, 
                    fontFamily = if (isRev) latinFont else arabicFont,
                    textAlign = if (isRev) TextAlign.Start else TextAlign.Right,
                    textDirection = if (isRev) TextDirection.Content else TextDirection.Rtl
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.lookup() }),
                decorationBox = { innerTextField ->
                    if (vm.query.isEmpty()) {
                        Text(
                            text = if(isRev) "Find Arabic for..." else "اكتب كلمة أو ابحث...",
                            color = colorMuted, fontSize = if (isRev) 17.sp else 20.sp, fontFamily = if (isRev) latinFont else arabicFont,
                            textAlign = if (isRev) TextAlign.Start else TextAlign.Right, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    innerTextField()
                }
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(colorSendBg).clickable { vm.lookup() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons_SendArrow, contentDescription = "Search", tint = Color.White, modifier = Modifier.size(20.dp)) }
        }
        
        // SVG Vector Navigation Bottom Pill
        Row(
            modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(50), spotColor = Color.Black.copy(0.05f))
                .background(colorNavBg, RoundedCornerShape(50)).border(1.dp, colorLine, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Triple("lookup", Icons_DadBubble, "Lookup"), Triple("saved", Icons_BrainProfile, "Saved Words"),
                Triple("practice", Icons_GradCap, "Practice"), Triple("settings", Icons_SettingsGear, "Settings")
            )
            tabs.forEach { (tabId, icon, desc) ->
                val isActive = vm.currentTab == tabId
                Box(
                    modifier = Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(50))
                        .clickable { vm.currentTab = tabId }
                        .background(if (isActive) colorAccent else Color.Transparent),
                    contentAlignment = Alignment.Center
                ) {
                    if (tabId == "lookup") {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = desc, modifier = Modifier.size(26.dp), tint = if (isActive) colorAccentFg else colorNavFg)
                            Text("ض", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = arabicFont, color = if(isActive) colorAccentFg else colorPaper, modifier = Modifier.offset(y = (-1).dp))
                        }
                    } else {
                        Icon(icon, contentDescription = desc, modifier = Modifier.size(24.dp), tint = if (isActive) colorAccentFg else colorNavFg)
                    }
                }
            }
        }
    }
}

@Composable
fun DockPill(text: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(50)).background(if (isActive) colorPrimary else colorPrimaryLight).clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = if (isActive) colorPrimaryFg else colorPrimaryLightFg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// --- Lookup Screen Wrapper ---
@Composable
fun LookupScreen(vm: MainViewModel) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = 20.dp)
    ) {
        if (vm.loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = colorPrimary, strokeWidth = 2.dp)
                Text("Working on it...", color = colorPrimary, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.cancel() }) { Text("Stop", color = colorPrimary) }
            }
            Spacer(Modifier.height(16.dp))
        }

        val err = vm.errorMsg
        if (err != null) {
            Text(err, color = colorError)
            Spacer(Modifier.height(16.dp))
        }

        val opts = vm.translationOptions
        if (!opts.isNullOrEmpty()) {
            Text("Arabic for \"${vm.query}\"", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colorInk)
            Spacer(Modifier.height(6.dp))
            Text("Tap a word for the full breakdown.", color = colorMuted, fontSize = 15.sp, modifier = Modifier.padding(bottom = 14.dp))
            for (opt in opts) CandidateCard(opt, vm.prefs.lang) { vm.openWord(opt.ar) }
            Spacer(Modifier.height(24.dp))
        } else if (vm.result != null) {
            ResultView(vm.result!!, vm.prefs.lang, vm)
            Spacer(Modifier.height(24.dp))
        } else if (!vm.loading && err == null && opts.isNullOrEmpty()) {
            EmptyState(vm)
        }
    }
}

@Composable
fun ResultView(w: Word, lang: String, vm: MainViewModel) {
    Column(Modifier.fillMaxWidth()) {
        Card(modifier = Modifier.fillMaxWidth().border(1.dp, colorLine, RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = colorSurface), shape = RoundedCornerShape(20.dp)) {
            RootBand(w, lang)
        }
        if (w.root.isNotEmpty()) RootWordsSection(vm)
        SectionDivider()
        WordHead(w, vm)
        Spacer(Modifier.height(20.dp))
        TranslationBanner(vm)
        SectionDivider()
        MeaningSection(w, lang)
        if (w.examples.isNotEmpty()) { SectionDivider(); ExamplesSection(w, lang, vm) }
        SectionDivider()
        TextSections(w)
        w.verb?.let { SectionDivider(); VerbSection(it, w, vm) }
        if (w.synonyms.isNotEmpty() || w.antonyms.isNotEmpty()) {
            SectionDivider()
            if (w.synonyms.isNotEmpty()) RelatedSection("Synonyms", w.synonyms, lang, vm)
            if (w.antonyms.isNotEmpty()) { Spacer(Modifier.height(24.dp)); RelatedSection("Antonyms", w.antonyms, lang, vm) }
        }
        vm.extraError?.let { Text(it, color = colorError, modifier = Modifier.padding(vertical = 12.dp)) }
        if (w.note.isNotBlank()) { SectionDivider(); Text(w.note, color = colorMuted, fontSize = 15.sp) }
    }
}

@Composable
fun SectionDivider() {
    Spacer(Modifier.height(26.dp))
    HorizontalDivider(color = colorLine)
    Spacer(Modifier.height(26.dp))
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colorPrimary, modifier = Modifier.padding(bottom = 14.dp))
}

@Composable
fun ArabicText(text: String, size: Int, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        color = colorInk,
        fontFamily = arabicFont,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.5f).sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
    )
}

@Composable
fun TxLine(text: String, lang: String) {
    if (lang == "off" || text.isBlank()) return
    val rtl = Langs.isRtl(lang)
    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Text(Langs.nativeNames[lang] ?: "", fontFamily = translationFont(lang), fontSize = 14.sp, color = colorMuted)
        Text(
            text = text,
            modifier = Modifier.weight(1f),
            color = colorInk,
            style = TextStyle(fontFamily = translationFont(lang), fontSize = if (lang == "ur") 19.sp else 18.sp, lineHeight = if (lang == "ur") 44.sp else if (lang == "fa") 36.sp else 27.sp, textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr, textAlign = if (rtl) TextAlign.Right else TextAlign.Left)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RootBand(w: Word, lang: String) {
    FlowRow(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.widthIn(min = 100.dp, max = 260.dp)) {
            SectionTitle("Root")
            Text(if (w.root.isEmpty()) "No root: this may be a particle or a loanword." else w.rootGloss, color = colorMuted, fontSize = 15.sp)
            TxLine(w.rootGlossTx, lang)
        }
        if (w.root.isNotEmpty()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { w.root.forEach { RootTile(it, if (w.root.size > 3) 48.dp else 60.dp) } }
            }
        }
    }
}

@Composable
fun RootTile(letter: String, width: Dp = 60.dp) {
    Box(
        modifier = Modifier.size(width = width, height = 72.dp).clip(RoundedCornerShape(16.dp)).background(colorPrimary),
        contentAlignment = Alignment.Center
    ) {
        Text(text = letter, color = colorPrimaryFg, style = TextStyle(fontSize = 46.sp, textDirection = TextDirection.Rtl, fontWeight = FontWeight.Normal, fontFamily = arabicFont))
    }
}

@Composable
fun WordHead(w: Word, vm: MainViewModel) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) {
                if (w.translit.isNotBlank()) Text(w.translit, fontSize = 20.sp, color = colorInk)
                if (w.pos.isNotBlank()) Text(w.pos, fontSize = 14.sp, color = colorPrimary, modifier = Modifier.padding(top = 6.dp))
                if (w.grammar.isNotBlank()) Text(w.grammar, fontSize = 15.sp, color = colorMuted)
                if (w.waznPattern.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Wazn", fontSize = 14.sp, color = colorMuted)
                    ArabicText(w.waznPattern, 26)
                    if (w.waznNote.isNotBlank()) Text(w.waznNote, fontSize = 15.sp, color = colorMuted)
                }
            }
            ArabicText(w.word, 58, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { vm.speak(w.word) }, shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)) { Text("Listen", color = colorPrimary) }
    }
}

@Composable
fun MeaningSection(w: Word, lang: String) {
    SectionTitle("Meaning")
    Text("English", fontSize = 14.sp, color = colorMuted)
    Text(w.meaningEn, fontSize = 17.sp, color = colorInk)
    TxLine(w.meaningTx, lang)
    if (w.meaningAr.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        ArabicText(w.meaningAr, 24, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ExamplesSection(w: Word, lang: String, vm: MainViewModel) {
    SectionTitle("In a sentence")
    for ((i, ex) in w.examples.withIndex()) {
        if (i > 0) Spacer(Modifier.height(14.dp))
        ArabicText(ex.ar, 24, modifier = Modifier.fillMaxWidth())
        TextButton(onClick = { vm.speak(ex.ar) }) { Text("Listen to sentence", color = colorPrimary) }
        Text(ex.en, fontSize = 17.sp, color = colorInk)
        TxLine(ex.tx, lang)
    }
}

@Composable
fun VerbSection(v: Verb, w: Word, vm: MainViewModel) {
    SectionTitle("Verb")
    val formText = if (v.form.isNotBlank() && v.form.length <= 5 && v.form.all { it == 'I' || it == 'V' || it == 'X' }) "Form " + v.form else v.form
    if (formText.isNotBlank()) {
        Text("Verb form", fontSize = 14.sp, color = colorMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formText, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
            if (v.pattern.isNotBlank()) ArabicText(v.pattern, 24)
        }
        Spacer(Modifier.height(8.dp))
    }
    val tense = listOf(
        if (v.inputTense.isNotBlank()) v.inputTense.replaceFirstChar { it.uppercase() } + " tense" else "",
        v.inputPerson
    ).filter { it.isNotBlank() }.joinToString(", ")
    if (tense.isNotBlank()) {
        Text("Your word is", fontSize = 14.sp, color = colorMuted)
        Text(tense, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = colorInk)
        Spacer(Modifier.height(8.dp))
    }
    VerbFact("Dictionary form (he, past)", v.dictionaryForm)
    VerbFact("Present (he)", v.presentForm)
    VerbFact("Masdar (verbal noun)", v.masdar)
    if (v.masdarWazn.isNotBlank()) VerbFact("Masdar wazn", v.masdarWazn)

    Spacer(Modifier.height(24.dp))
    Text("All 14 forms · tap a form to listen", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colorInk)
    Spacer(Modifier.height(10.dp))
    
    if (vm.loadedConjs != null) {
        ConjTable(v, vm.loadedConjs!!, vm)
    } else if (vm.conjLoading) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
            CircularProgressIndicator(color = colorPrimary, modifier = Modifier.size(32.dp))
        }
    } else {
        OutlinedButton(
            onClick = { vm.loadConjugations(v.dictionaryForm.ifBlank { w.word }) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = colorPrimary),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, colorLine)
        ) {
            Text("Show 14x7 Conjugations", color = colorPrimary)
        }
    }
}

@Composable
fun VerbFact(label: String, value: String) {
    if (value.isBlank()) return
    Text(label, fontSize = 14.sp, color = colorMuted)
    ArabicText(value, 24, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
}

@Composable
fun ConjCell(text: String, hit: Boolean, hitColor: Color, widthDp: Dp, vm: MainViewModel) {
    Box(
        modifier = Modifier.width(widthDp).clickable(enabled = text != "—") { vm.speak(text) }.background(if (hit) hitColor else Color.Transparent).padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterEnd
    ) { ArabicText(text, 24) }
}

@Composable
fun ConjTable(v: Verb, conjs: org.json.JSONArray, vm: MainViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, colorLine, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = colorSurface)
    ) {
        Column(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text("Who", modifier = Modifier.width(120.dp), fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Past", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Present", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Subj.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Juss.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Imp.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Pas. Past", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
                Text("Pas. Pres.", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 14.sp, color = colorMuted, fontWeight = FontWeight.Medium)
            }
            for (i in 0 until 14) {
                if (i == 0 || i == 6 || i == 12) HorizontalDivider(color = colorLine, thickness = 2.dp) else HorizontalDivider(color = colorSoftLine)
                val p = PRONOUNS[i]
                
                val item = conjs.optJSONObject(i) ?: org.json.JSONObject()
                val past = item.optString("past", "—").ifBlank { "—" }
                val present = item.optString("present", "—").ifBlank { "—" }
                val subj = item.optString("subjunctive", "—").ifBlank { "—" }
                val jussive = item.optString("jussive", "—").ifBlank { "—" }
                val imp = item.optString("imperative", "—").ifBlank { "—" }
                val pPast = item.optString("passivePast", "—").ifBlank { "—" }
                val pPres = item.optString("passivePresent", "—").ifBlank { "—" }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.width(120.dp).padding(horizontal = 14.dp, vertical = 6.dp)) {
                        ArabicText(p.first, 22, modifier = Modifier.fillMaxWidth())
                        Text(p.second, fontSize = 14.sp, color = colorInk)
                    }
                    ConjCell(past, v.matchIndex == i && v.matchTense == "past", colorPrimaryLight, 90.dp, vm)
                    ConjCell(present, v.matchIndex == i && v.matchTense == "present", colorPrimaryLight, 90.dp, vm)
                    ConjCell(subj, v.matchIndex == i && v.matchTense == "subjunctive", colorPrimaryLight, 90.dp, vm)
                    ConjCell(jussive, v.matchIndex == i && v.matchTense == "jussive", colorPrimaryLight, 90.dp, vm)
                    ConjCell(imp, v.matchIndex == i && v.matchTense == "imperative", colorPrimaryLight, 90.dp, vm)
                    ConjCell(pPast, v.matchIndex == i && v.matchTense == "passivePast", colorPrimaryLight, 100.dp, vm)
                    ConjCell(pPres, v.matchIndex == i && v.matchTense == "passivePresent", colorPrimaryLight, 100.dp, vm)
                }
            }
        }
    }
}

@Composable
fun RelatedSection(title: String, items: List<Gloss>, lang: String, vm: MainViewModel) {
    SectionTitle(title)
    if (items.isEmpty()) {
        Text("None found.", color = colorMuted)
        return
    }
    for (g in items) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(g.en, fontSize = 15.sp, color = colorMuted)
                TxLine(g.tx, lang)
            }
            ArabicText(g.ar, 24, Modifier.clickable { vm.openWord(g.ar) })
        }
        HorizontalDivider(color = colorSoftLine)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (code, label) ->
            if (selected == code) Button(onClick = { onSelect(code) }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = colorPrimary, contentColor = colorPrimaryFg)) { Text(label) }
            else OutlinedButton(onClick = { onSelect(code) }, shape = RoundedCornerShape(50), border = androidx.compose.foundation.BorderStroke(1.dp, colorLine)) { Text(label, color = colorInk) }
        }
    }
}
