package app.kalima

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KalimaRoot(vm: MainViewModel) {
    val dark = when (vm.prefs.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    KalimaTheme(dark = dark) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            MainScreen(vm)
            if (vm.showSettings) SettingsDialog(vm)
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "كَلِمَة",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                style = TextStyle(fontSize = 34.sp, textDirection = TextDirection.Rtl)
            )
            TextButton(onClick = { vm.showSettings = true }) { Text("Settings") }
        }
        Spacer(Modifier.height(4.dp))
        TabsRow(vm)
        Spacer(Modifier.height(4.dp))
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (vm.currentTab) {
                "saved" -> SavedScreen(vm)
                "practice" -> PracticeScreen(vm)
                else -> LookupScreen(vm)
            }
        }
    }
}

@Composable
fun TabsRow(vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TabButton("Lookup", vm.currentTab == "lookup") { vm.currentTab = "lookup" }
            TabButton("Saved" + if (vm.savedEntries.isNotEmpty()) " (" + vm.savedEntries.size + ")" else "", vm.currentTab == "saved") { vm.currentTab = "saved" }
            TabButton("Practice", vm.currentTab == "practice") { vm.currentTab = "practice" }
        }
        Spacer(Modifier.height(4.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
    }
}

@Composable
fun RowScope.TabButton(label: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.weight(1f)) {
        Text(
            label,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
fun LookupScreen(vm: MainViewModel) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(fontSize = 22.sp, textDirection = TextDirection.Content, textAlign = TextAlign.Start),
                placeholder = { Text("Search Arabic or translate", style = TextStyle(fontSize = 18.sp, textDirection = TextDirection.Content)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.lookup() })
            )
            Button(onClick = { vm.lookup() }, enabled = !vm.loading) { Text("Look up") }
        }

        if (vm.loading) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                Text(
                    "Working on it. This can take up to a minute.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { vm.cancel() }) { Text("Stop") }
            }
        }

        val err = vm.errorMsg
        if (err != null) {
            Spacer(Modifier.height(16.dp))
            Text(err, color = MaterialTheme.colorScheme.error)
        }

        val w = vm.result
        if (w != null) {
            Spacer(Modifier.height(16.dp))
            ResultView(w, vm.prefs.lang, vm)
        } else if (!vm.loading && err == null) {
            Spacer(Modifier.height(28.dp))
            Text(
                "Type any Arabic noun, verb or adjective, or type a word in English, Urdu, Farsi, Turkish, or Russian to translate it. In other apps, select a word and choose \"Look up in Kalima\".",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(48.dp))
    }
}

/* ---------------- result ---------------- */

@Composable
fun ResultView(w: Word, lang: String, vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxWidth()) {
        RootBand(w, lang)
        WordHead(w)
        SaveRow(w, vm)
        SectionDivider()
        MeaningSection(w, lang)
        if (w.examples.isNotEmpty()) {
            SectionDivider()
            ExamplesSection(w, lang)
        }
        SectionDivider()
        TextSections(w)
        val v = w.verb
        if (v != null) {
            SectionDivider()
            VerbSection(v)
        }
        if (w.synonyms.isNotEmpty() || w.antonyms.isNotEmpty()) {
            SectionDivider()
            RelatedSection("Synonyms", w.synonyms, lang)
            Spacer(Modifier.height(16.dp))
            RelatedSection("Antonyms", w.antonyms, lang)
        }
        if (w.note.isNotBlank()) {
            SectionDivider()
            Text(w.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SectionDivider() {
    Spacer(Modifier.height(16.dp))
    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
    Spacer(Modifier.height(16.dp))
}

@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 20.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 10.dp)
    )
}

@Composable
fun ArabicText(text: String, size: Int, modifier: Modifier = Modifier, bold: Boolean = false) {
    Text(
        text = text,
        modifier = modifier,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        style = TextStyle(
            fontSize = size.sp,
            lineHeight = (size * 1.7f).sp,
            textDirection = TextDirection.Rtl,
            textAlign = TextAlign.Right
        )
    )
}

/** A translation line in the chosen language, with the language name beside it. */
@Composable
fun TxLine(text: String, lang: String) {
    if (lang == "off" || text.isBlank()) return
    val rtl = Langs.isRtl(lang)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = Langs.nativeNames[lang] ?: "",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = text,
            modifier = Modifier.weight(1f),
            style = TextStyle(
                fontSize = 18.sp,
                lineHeight = 30.sp,
                textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr,
                textAlign = if (rtl) TextAlign.Right else TextAlign.Left
            )
        )
    }
}

@Composable
fun RootBand(w: Word, lang: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Root", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                if (w.root.isEmpty()) {
                    Text("No root: a particle or a loanword.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    if (w.rootGloss.isNotBlank()) {
                        Text(w.rootGloss, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TxLine(w.rootGlossTx, lang)
                }
            }
            if (w.root.isNotEmpty()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (letter in w.root) RootTile(letter)
                    }
                }
            }
        }
    }
}

@Composable
fun RootTile(letter: String) {
    Box(
        modifier = Modifier
            .size(width = 50.dp, height = 62.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(text = letter, color = Color.White, style = TextStyle(fontSize = 38.sp, textDirection = TextDirection.Rtl))
    }
}

@Composable
fun WordHead(w: Word) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
        ArabicText(w.word, 56, modifier = Modifier.fillMaxWidth())
        if (w.translit.isNotBlank()) {
            Text(w.translit, fontSize = 20.sp, fontStyle = FontStyle.Italic)
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (w.pos.isNotBlank()) {
                Text(
                    text = w.pos,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                )
            }
            if (w.grammar.isNotBlank()) {
                Text(w.grammar, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (w.waznPattern.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Wazn", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ArabicText(w.waznPattern, 26, bold = true)
                if (w.waznNote.isNotBlank()) {
                    Text(w.waznNote, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun SaveRow(w: Word, vm: MainViewModel) {
    val saved = vm.isSaved(w.word)
    Row(modifier = Modifier.padding(top = 12.dp)) {
        OutlinedButton(onClick = { vm.toggleSave() }) {
            Text(if (saved) "Saved ✓" else "Save word")
        }
    }
}

@Composable
fun MeaningSection(w: Word, lang: String) {
    SectionTitle("Meaning")
    Text("English", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(w.meaningEn, fontSize = 17.sp)
    TxLine(w.meaningTx, lang)
    if (w.meaningAr.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        ArabicText(w.meaningAr, 24, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ExamplesSection(w: Word, lang: String) {
    SectionTitle("In a sentence")
    for ((i, ex) in w.examples.withIndex()) {
        if (i > 0) Spacer(Modifier.height(14.dp))
        ArabicText(ex.ar, 24, modifier = Modifier.fillMaxWidth())
        Text(ex.en, fontSize = 16.sp)
        TxLine(ex.tx, lang)
    }
}

@Composable
fun VerbSection(v: Verb) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    SectionTitle("Verb")

    val formText = if (v.form.isNotBlank() && v.form.length <= 5 && v.form.all { it == 'I' || it == 'V' || it == 'X' }) "Form " + v.form else v.form
    if (formText.isNotBlank()) {
        Text("Verb form", fontSize = 13.sp, color = muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formText, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (v.pattern.isNotBlank()) ArabicText(v.pattern, 22)
        }
        Spacer(Modifier.height(8.dp))
    }
    val tense = listOf(
        if (v.inputTense.isNotBlank()) v.inputTense.replaceFirstChar { it.uppercase() } + " tense" else "",
        v.inputPerson
    ).filter { it.isNotBlank() }.joinToString(", ")
    if (tense.isNotBlank()) {
        Text("Your word is", fontSize = 13.sp, color = muted)
        Text(tense, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
    }
    VerbFact("Dictionary form (he, past)", v.dictionaryForm)
    VerbFact("Present (he)", v.presentForm)
    VerbFact("Masdar (verbal noun)", v.masdar)
    if (v.masdarWazn.isNotBlank()) VerbFact("Masdar wazn", v.masdarWazn)

    Spacer(Modifier.height(12.dp))
    Text("All 14 forms", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    ConjTable(v)
}

@Composable
fun VerbFact(label: String, value: String) {
    if (value.isBlank()) return
    Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    ArabicText(value, 24, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(4.dp))
}

@Composable
fun ConjCell(text: String, hit: Boolean, hitColor: Color, widthDp: Dp) {
    Box(
        modifier = Modifier
            .width(widthDp)
            .background(if (hit) hitColor else Color.Transparent)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterEnd
    ) {
        ArabicText(text, 20)
    }
}

@Composable
fun ConjTable(v: Verb) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val hitColor = if (isDark) Color(0xFF4A3C10) else Color(0xFFFFEDB8)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
        ) {
            Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)) {
                Text("Who", modifier = Modifier.width(120.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Past", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Present", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Subj.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Juss.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Imp.", modifier = Modifier.width(90.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Pas. Past", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Pas. Pres.", modifier = Modifier.width(100.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            for (i in 0 until 14) {
                if (i == 0 || i == 6 || i == 12) HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                val p = PRONOUNS[i]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.width(120.dp).padding(horizontal = 6.dp, vertical = 4.dp)) {
                        ArabicText(p.first, 20, modifier = Modifier.fillMaxWidth())
                        Text(p.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ConjCell(v.past[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "past", hitColor, 90.dp)
                    ConjCell(v.present[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "present", hitColor, 90.dp)
                    ConjCell(v.subjunctive[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "subjunctive", hitColor, 90.dp)
                    ConjCell(v.jussive[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "jussive", hitColor, 90.dp)
                    ConjCell(v.imperative[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "imperative", hitColor, 90.dp)
                    ConjCell(v.passivePast[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "passivePast", hitColor, 100.dp)
                    ConjCell(v.passivePresent[i].ifBlank { "—" }, v.matchIndex == i && v.matchTense == "passivePresent", hitColor, 100.dp)
                }
            }
        }
    }
}

@Composable
fun RelatedSection(title: String, items: List<Gloss>, lang: String) {
    SectionTitle(title)
    if (items.isEmpty()) {
        Text("None found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    for (g in items) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(g.en, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TxLine(g.tx, lang)
            }
            ArabicText(g.ar, 24)
        }
    }
}

/* ---------------- settings ---------------- */

@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (opt in options) {
            val value = opt.first
            val label = opt.second
            val m = Modifier.weight(1f)
            if (value == selected) {
                Button(
                    onClick = { onSelect(value) },
                    modifier = m,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) { Text(label, fontSize = 12.sp, maxLines = 1) }
            } else {
                OutlinedButton(
                    onClick = { onSelect(value) },
                    modifier = m,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) { Text(label, fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}

@Composable
fun SettingsDialog(vm: MainViewModel) {
    val p = vm.prefs
    var pass by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    fun saveFields() {
        if (pass.isNotBlank()) p.updatePasscode(pass.trim())
        if (key.isNotBlank()) p.updateApiKey(key.trim())
        p.updateModel(if (model.isBlank()) Config.DEFAULT_MODEL else model.trim())
        p.updateProxyUrl(proxy.trim())
        pass = ""
        key = ""
    }

    AlertDialog(
        onDismissRequest = { saveFields(); vm.showSettings = false },
        title = { Text("Settings") },
        confirmButton = { TextButton(onClick = { saveFields(); vm.showSettings = false }) { Text("Done") } },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text("Translation shown with Arabic and English", fontSize = 13.sp, color = muted)
                Spacer(Modifier.height(6.dp))
                Segmented(
                    options = listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off"),
                    selected = p.lang,
                    onSelect = { p.updateLang(it) }
                )
                Spacer(Modifier.height(16.dp))

                Text("Appearance", fontSize = 13.sp, color = muted)
                Spacer(Modifier.height(6.dp))
                Segmented(
                    options = listOf("system" to "System", "light" to "Light", "dark" to "Dark"),
                    selected = p.theme,
                    onSelect = { p.updateTheme(it) }
                )
                Spacer(Modifier.height(16.dp))

                if (proxy.isNotBlank()) {
                    Text("How to reach Gemini", fontSize = 13.sp, color = muted)
                    Spacer(Modifier.height(6.dp))
                    Segmented(
                        options = listOf("shared" to "Class passcode", "own" to "My own key"),
                        selected = if (p.useShared()) "shared" else "own",
                        onSelect = { p.updateAccess(it) }
                    )
                    Spacer(Modifier.height(12.dp))
                }

                if (p.useShared()) {
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        label = { Text("Class passcode") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        if (p.passcode.isNotBlank()) "Passcode saved on this phone." else "No passcode yet.",
                        fontSize = 13.sp,
                        color = muted
                    )
                } else {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("Gemini API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        if (p.apiKey.isNotBlank()) "Key saved on this phone." else "No key yet.",
                        fontSize = 13.sp,
                        color = muted
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = proxy,
                    onValueChange = { proxy = it },
                    label = { Text("Class server address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Leave empty to always use your own key.", fontSize = 12.sp, color = muted)
            }
        }
    )
}
