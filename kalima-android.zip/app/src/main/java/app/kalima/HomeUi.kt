package app.kalima

import app.kalima.LocalizedText as Text
import app.kalima.LocalizedIcon as Icon
import androidx.compose.material3.Text as RawText
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val HomeListenIcon = ImageVector.Builder("Listen", 24.dp, 24.dp, 24f, 24f).apply {
    path(fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 1.8f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
        moveTo(4f, 9f); lineTo(8f, 9f); lineTo(13f, 5f); lineTo(13f, 19f); lineTo(8f, 15f); lineTo(4f, 15f); close()
        moveTo(16f, 8f); curveTo(19f, 10f, 19f, 14f, 16f, 16f)
        moveTo(19f, 5f); curveTo(24f, 9f, 24f, 15f, 19f, 19f)
    }
}.build()
internal val HomePreviousIcon = ImageVector.Builder("Previous suggestion", 24.dp, 24.dp, 24f, 24f).apply {
    path(fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
        moveTo(14f, 6f); lineTo(8f, 12f); lineTo(14f, 18f)
    }
}.build()
@Composable
internal fun HomeFocusLifecycle(vm: MainViewModel) {
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val density = LocalDensity.current
    val ime = WindowInsets.ime
    val visible by remember(ime, density) { derivedStateOf { ime.getBottom(density) > 0 } }
    var hadKeyboard by remember { mutableStateOf(false) }
    LaunchedEffect(visible, vm.searchFocused) {
        if (!vm.searchFocused) hadKeyboard = false
        else if (visible) hadKeyboard = true
        else if (hadKeyboard) { focus.clearFocus(); vm.searchFocused = false; hadKeyboard = false }
    }
    BackHandler(vm.searchFocused) { keyboard?.hide(); focus.clearFocus(); vm.searchFocused = false }
}

@Composable
internal fun ContextualHomeHeader(vm: MainViewModel, compactWord: String? = null, onWordClick: () -> Unit = {}) {
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val home = vm.currentTab == "lookup"
    val hasSearch = vm.query.isNotBlank() || vm.result != null || vm.loading || vm.errorMsg != null || !vm.translationOptions.isNullOrEmpty()
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        val title = when (vm.currentTab) { "saved" -> "Saved words"; "practice" -> "Practice"; "settings" -> "Settings"; "history" -> "Recent searches"; else -> if (vm.result != null) "Translations" else "Kalima" }
        if (home && compactWord != null) {
            Box(Modifier.weight(1f).heightIn(min = 48.dp).clickable(role = Role.Button,
                onClickLabel = tr("Back to top"), onClick = onWordClick).semantics { heading() }, contentAlignment = Alignment.Center) {
                MovingWord(compactWord, "detail:$compactWord", 26, 40)
            }
        } else Text(title, Modifier.weight(1f).semantics { heading() }, color = colorPrimaryLightFg, fontSize = if (title == "Kalima") 25.sp else 20.sp, fontWeight = FontWeight.SemiBold)
        if (home && hasSearch) TextButton(onClick = { keyboard?.hide(); focus.clearFocus(); vm.clear() },
            colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Clear") }
        IconButton(onClick = { keyboard?.hide(); focus.clearFocus(); vm.currentTab = "history" }) {
            Icon(Icons_History, "Recent searches", tint = colorPrimaryLightFg, modifier = Modifier.size(22.dp))
        }
    }
}

/** Restore the four equal-width pills, keeping the focused-search body independent. */
@Composable
internal fun HomeSearchControls(vm: MainViewModel) {
    var activeSheet by remember { mutableStateOf<String?>(null) }
    val haptic = rememberInteractionHaptic(vm.prefs)
    val word = vm.result?.word
    val saved = word?.let(vm::isSaved) == true
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AnimatedSavePill(word, saved, {
            val before = word?.let(vm::isSaved) == true
            vm.toggleSave()
            val confirmed = !before && word?.let(vm::isSaved) == true
            if (confirmed) haptic(InteractionHaptic.Confirmation)
            confirmed
        }, Modifier.weight(1f))
        val reverse = vm.searchMode == "rev"
        DockPill(if (reverse) "Reverse" else "Ar Word", !reverse,
            { if (activeSheet == null) activeSheet = "search" }, Modifier.weight(1f))
        DockPill(if (vm.lookupMode == "fast") "Fast" else "Deep", true,
            { if (activeSheet == null) activeSheet = "depth" }, Modifier.weight(1f))
        DockPill(Langs.nativeNames[vm.prefs.lang] ?: "Off", false,
            { if (activeSheet == null) activeSheet = "extra" }, Modifier.weight(1f))
    }
    when (activeSheet) {
        "search" -> HomeChoiceSheet("Search", vm.searchMode,
            listOf("ar" to "Arabic word", "rev" to "Reverse search"),
            { vm.searchMode = it }, { activeSheet = null })
        "depth" -> HomeChoiceSheet("Search depth", vm.lookupMode,
            listOf("fast" to "Fast", "deep" to "Deep"),
            { vm.lookupMode = it }, { activeSheet = null })
        "extra" -> ExtraTranslationSelectionSheet(vm.prefs.lang, { vm.changeLanguage(it) }, { activeSheet = null })
    }
}

/** Same native slide-in/slide-out and radio feedback as the translation sheet. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeChoiceSheet(title: String, selected: String, choices: List<Pair<String, String>>,
    onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) }
    fun close(choice: String? = null) {
        if (closing) return
        closing = true
        if (choice != null) { pending = choice; onSelect(choice) }
        scope.launch { try { sheet.hide() } finally { onDismiss() } }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet,
        containerColor = colorSurface, contentColor = colorInk,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { BottomSheetDefaults.DragHandle(color = colorMuted) }) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), color = colorPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { close() }, enabled = !closing) { Text("Close", color = colorInk) }
            }
            Spacer(Modifier.height(16.dp))
            choices.forEach { (value, label) ->
                val chosen = value == (pending ?: selected)
                Surface(Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    color = if (chosen) colorPrimaryLight else colorSurface,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (chosen) colorPrimary else colorLine)) {
                    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp)
                        .selectable(chosen, enabled = !closing, role = Role.RadioButton) { close(value) }
                        .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(label, Modifier.weight(1f), color = colorInk, fontSize = 17.sp,
                            fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Normal)
                        SpringChoiceIndicator(chosen)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun HomeContinuation(vm: MainViewModel) {
    val due = vm.savedEntries.count { isDue(it, System.currentTimeMillis()) }
    if (due > 0) Surface(onClick = { vm.startDueReview() }, modifier = Modifier.fillMaxWidth(),
        color = colorSurface, shape = KalimaDesign.cardShape, border = BorderStroke(1.dp, colorLine)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Continue learning", color = colorInk, fontSize = 14.sp)
            Text(if (due == 1) "Review $due word" else "Review $due words", color = colorPrimaryLightFg, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
    } else if (vm.recentWords.isNotEmpty()) ReadingSurface {
        Text("Recent searches", color = colorPrimaryLightFg, fontSize = 14.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.recentWords.take(3).forEach { word ->
                OutlinedButton(onClick = { vm.openWord(word) }) {
                    RawText(word, fontFamily = arabicFont, color = colorInk, fontSize = 20.sp, lineHeight = 34.sp, style = TextStyle(textDirection = TextDirection.Rtl))
                }
            }
        }
    }
}

@Composable
internal fun FocusedHomeSearch(vm: MainViewModel) {
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val entries = vm.savedEntries.toList()
    val index = remember(entries) { HomeSearchIndex.build(entries) }
    val matches = remember(index, vm.query) { HomeSearchIndex.search(index, vm.query) }
    fun finish() { keyboard?.hide(); focus.clearFocus(); vm.searchFocused = false }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (vm.query.isBlank()) "Recent searches" else "Saved matches", Modifier.weight(1f).semantics { heading() }, color = colorPrimaryLightFg, fontSize = 18.sp)
            TextButton(onClick = { finish() }) { Text("Close", color = colorPrimaryLightFg) }
        }
        Text(if (vm.prefs.appLanguage == "ar") "Arabic" else "Arabic + ${Langs.names[vm.prefs.appLanguage] ?: "English"}", color = colorInk, fontSize = 14.sp)
        Text("Extra: ${Langs.names[vm.prefs.lang] ?: "Off"}", color = colorInk, fontSize = 14.sp)
        if (vm.query.isBlank()) {
            if (vm.recentWords.isEmpty()) Text("Your recent searches will appear here.", color = colorInk)
            vm.recentWords.take(5).forEach { word ->
                LocalSearchWord(word, null) { finish(); vm.openWord(word) }
            }
            if (vm.recentWords.isNotEmpty()) TextButton(onClick = { vm.clearHistory() }) { Text("Clear recent searches", color = colorPrimaryLightFg) }
        } else {
            if (matches.isEmpty()) Text("No saved matches. Use Search to look up this word.", color = colorInk, fontSize = 15.sp)
            matches.forEach { candidate ->
                val entry = entries.firstOrNull { it.str("id") == candidate.id }
                val word = entry?.optJSONObject("data")?.let { Word.fromJson(it, vm.prefs.lang, vm.prefs.appLanguage) }
                LocalSearchWord(candidate.arabic, word?.let(::shortMeaning)) {
                    if (entry != null) { finish(); vm.openSaved(entry) }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun LocalSearchWord(word: String, meaning: String?, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = Modifier.fillMaxWidth(), color = colorSurface, shape = KalimaDesign.controlShape, border = BorderStroke(1.dp, colorLine)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            RawText(word, Modifier.fillMaxWidth(), color = colorInk, fontFamily = arabicFont, fontSize = 28.sp, lineHeight = 46.sp,
                style = TextStyle(textDirection = TextDirection.Rtl, textAlign = TextAlign.Right))
            if (!meaning.isNullOrBlank()) ReadingText(meaning)
        }
    }
}
