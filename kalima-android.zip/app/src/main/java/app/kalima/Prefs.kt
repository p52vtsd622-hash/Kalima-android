package app.kalima

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Settings saved on the phone. Values are Compose state, so the screen updates when they change. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("kalima_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "ur") ?: "ur")
        private set
    var theme by mutableStateOf(sp.getString("theme", "system") ?: "system")
        private set
    var access by mutableStateOf(sp.getString("access", "shared") ?: "shared")
        private set
    var apiKey by mutableStateOf(sp.getString("apiKey", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", Config.DEFAULT_MODEL) ?: Config.DEFAULT_MODEL)
        private set
    var proxyUrl by mutableStateOf(sp.getString("proxyUrl", Config.DEFAULT_PROXY) ?: Config.DEFAULT_PROXY)
        private set

    init {
        // Older installs may have selected personal access without saving a key.
        if (access == "own" && apiKey.isBlank()) updateAccess("shared")
        sp.edit().remove("passcode").apply()
    }

    private fun put(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun updateLang(v: String) { lang = v; put("lang", v) }
    fun updateTheme(v: String) { theme = v; put("theme", v) }
    fun updateAccess(v: String) { access = v; put("access", v) }
    fun updateApiKey(v: String) {
        apiKey = v.trim(); put("apiKey", apiKey)
        updateAccess(if (apiKey.isBlank()) "shared" else "own")
    }
    fun updateModel(v: String) { model = v; put("model", v) }
    fun updateProxyUrl(v: String) { proxyUrl = v; put("proxyUrl", v) }

    fun useShared(): Boolean = AccessPolicy.useShared(access, apiKey)

    fun hasAccess(): Boolean = AccessPolicy.hasAccess(access, apiKey, proxyUrl)
}
