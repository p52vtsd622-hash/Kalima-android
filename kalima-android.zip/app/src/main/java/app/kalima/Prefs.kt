package app.kalima

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Settings saved on the phone. Values are Compose state, so the screen updates when they change. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("kalima_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "ur") ?: "ur")
        private set
    var theme by mutableStateOf(sp.getString("theme", "system") ?: "system")
        private set
    var access by mutableStateOf(sp.getString("access", "shared") ?: "shared")
        private set
    var passcode by mutableStateOf(sp.getString("passcode", "") ?: "")
        private set
    var apiKey by mutableStateOf(sp.getString("apiKey", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", Config.DEFAULT_MODEL) ?: Config.DEFAULT_MODEL)
        private set
    var proxyUrl by mutableStateOf(sp.getString("proxyUrl", Config.DEFAULT_PROXY) ?: Config.DEFAULT_PROXY)
        private set

    private fun put(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun updateLang(v: String) { lang = v; put("lang", v) }
    fun updateTheme(v: String) { theme = v; put("theme", v) }
    fun updateAccess(v: String) { access = v; put("access", v) }
    fun updatePasscode(v: String) { passcode = v; put("passcode", v) }
    fun updateApiKey(v: String) { apiKey = v; put("apiKey", v) }
    fun updateModel(v: String) { model = v; put("model", v) }
    fun updateProxyUrl(v: String) { proxyUrl = v; put("proxyUrl", v) }

    fun useShared(): Boolean = proxyUrl.isNotBlank() && access != "own"

    fun hasAccess(): Boolean = if (useShared()) passcode.isNotBlank() else apiKey.isNotBlank()
}
