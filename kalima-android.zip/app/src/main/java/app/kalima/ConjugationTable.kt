package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

@Composable
fun ConjTable(v: Verb, conjs: JSONArray, vm: MainViewModel) {
    val rows = remember(conjs, v.matchIndex, v.matchTense) {
        ConjugationPresentation.rows(conjs, v.matchIndex, v.matchTense)
    }
    val scale = LocalDensity.current.fontScale.coerceAtLeast(1f)
    val pronounWidth = 184.dp * scale
    val tenseWidth = 160.dp * scale
    Text("Swipe horizontally to see all forms", fontSize = 14.sp, color = colorMuted)
    Spacer(Modifier.height(8.dp))
    Surface(Modifier.fillMaxWidth(), shape = KalimaDesign.controlShape,
        border = BorderStroke(1.dp, colorLine), color = colorSurface) {
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            Row(Modifier.background(colorPrimaryLight).height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
                Text("Who", Modifier.width(pronounWidth).padding(12.dp).semantics { heading() },
                    color = colorPrimaryLightFg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                ConjugationPresentation.columns.forEach { column ->
                    Text(column.title, Modifier.width(tenseWidth).padding(12.dp).semantics { heading() },
                        textAlign = TextAlign.Center, color = colorPrimaryLightFg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            rows.forEachIndexed { index, forms ->
                HorizontalDivider(color = if (index in listOf(0, 6, 12)) colorLine else colorSoftLine,
                    thickness = if (index in listOf(0, 6, 12)) 2.dp else 1.dp)
                Row(Modifier.height(IntrinsicSize.Min)
                    .background(if (index % 2 == 0) colorSurface else colorPaper), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.width(pronounWidth).padding(12.dp)) {
                        RawText(PRONOUNS[index].first, Modifier.fillMaxWidth(), color = colorInk,
                            fontFamily = arabicFont, fontSize = 24.sp, lineHeight = 42.sp,
                            style = TextStyle(textDirection = TextDirection.Rtl, textAlign = TextAlign.Right))
                        Text(PRONOUNS[index].second, color = colorMuted, fontSize = 14.sp)
                    }
                    forms.forEachIndexed { col, form ->
                        val description = tr(ConjugationPresentation.columns[col].title) + " · " + PRONOUNS[index].first + " · " + form.text
                        Box(Modifier.width(tenseWidth).fillMaxHeight().heightIn(min = 72.dp)
                            .background(if (form.matched) colorPrimaryLight else Color.Transparent)
                            .then(if (form.matched) Modifier.border(2.dp, colorPrimaryLightFg) else Modifier)
                            .clickable(enabled = form.canListen, role = Role.Button, onClickLabel = tr("Listen")) { vm.speak(form.text) }
                            .semantics(mergeDescendants = true) {
                                contentDescription = description
                                if (form.matched) { selected = true; stateDescription = tr("Your word is") }
                            }.padding(12.dp), contentAlignment = Alignment.Center) {
                            RawText(form.text, fontFamily = arabicFont, fontSize = 24.sp, lineHeight = 42.sp,
                                color = if (form.matched) colorPrimaryLightFg else colorInk,
                                style = TextStyle(textDirection = TextDirection.Rtl, textAlign = TextAlign.Center))
                        }
                    }
                }
            }
        }
    }
}
