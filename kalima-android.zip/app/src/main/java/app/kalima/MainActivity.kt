package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private var firstStart = true

    override fun attachBaseContext(newBase: android.content.Context) {
        val language = newBase.getSharedPreferences("kalima_prefs", 0).getString("appLanguage", "en") ?: "en"
        val configuration = android.content.res.Configuration(newBase.resources.configuration)
        val locale = java.util.Locale.forLanguageTag(language)
        configuration.setLocale(locale); configuration.setLayoutDirection(locale)
        super.attachBaseContext(newBase.createConfigurationContext(configuration))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Localization.initialize(this)
        if (savedInstanceState == null) handleIntent(intent)
        setContent { KalimaRoot(vm) }
    }

    override fun onStart() {
        super.onStart()
        // Includes returning from the background; keep a searched result intact.
        vm.refreshSuggestion()
        // Recreating for an in-app language change is still the same foreground session.
        if (!firstStart || lastNonConfigurationInstance == null) vm.updates.onForeground()
        firstStart = false
    }

    override fun onResume() {
        super.onResume()
        vm.updates.onResume(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Text selected in another app arrives here through "Look up in Kalima". */
    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
        if (!text.isNullOrBlank()) vm.receiveSelectedText(text)
    }
}
