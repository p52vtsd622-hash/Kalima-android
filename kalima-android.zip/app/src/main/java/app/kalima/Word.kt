package app.kalima

import org.json.JSONObject

data class Example(val ar: String, val en: String, val tx: String)

data class Gloss(val ar: String, val en: String, val tx: String, val transliteration: String = "", val partOfSpeech: String = "", val wazn: String = "")

data class Verb(
    val form: String,
    val pattern: String,
    val dictionaryForm: String,
    val presentForm: String,
    val masdar: String,
    val masdarWazn: String,
    val inputTense: String,
    val inputPerson: String,
    val matchIndex: Int,
    val matchTense: String,
    val past: List<String>,
    val present: List<String>,
    val subjunctive: List<String>,
    val jussive: List<String>,
    val imperative: List<String>,
    val passivePast: List<String>,
    val passivePresent: List<String>
)

data class Word(
    val word: String,
    val forms: List<String>,
    val translit: String,
    val pos: String,
    val grammar: String,
    val root: List<String>,
    val rootGloss: String,
    val rootGlossTx: String,
    val waznPattern: String,
    val waznNote: String,
    val meaningEn: String,
    val meaningAr: String,
    val meaningTx: String,
    val examples: List<Example>,
    val synonyms: List<Gloss>,
    val antonyms: List<Gloss>,
    val verb: Verb?,
    val note: String
) {
    companion object {
        fun fromJson(o: JSONObject, lang: String = "off"): Word {
            val translation = o.optJSONObject("trans")?.optJSONObject(lang)
            fun txAt(key: String, index: Int) = translation?.optJSONArray(key)?.optString(index, "") ?: ""
            val meaning = o.optJSONObject("meaning")
            val wazn = o.optJSONObject("wazn")

            val examples = ArrayList<Example>()
            val exArr = o.optJSONArray("examples")
            if (exArr != null) {
                for ((i, x) in exArr.objects().withIndex()) examples.add(Example(x.str("ar"), x.str("en"), txAt("examples", i)))
            }
            val synonyms = ArrayList<Gloss>()
            val synArr = o.optJSONArray("synonyms")
            if (synArr != null) {
                for ((i, x) in synArr.objects().withIndex()) synonyms.add(Gloss(x.str("ar"), x.str("en"), txAt("synonyms", i)))
            }
            val antonyms = ArrayList<Gloss>()
            val antArr = o.optJSONArray("antonyms")
            if (antArr != null) {
                for ((i, x) in antArr.objects().withIndex()) antonyms.add(Gloss(x.str("ar"), x.str("en"), txAt("antonyms", i)))
            }

            val rootList = ArrayList<String>()
            val rootArr = o.optJSONArray("root")
            if (rootArr != null) {
                for (s in rootArr.strings()) if (s.isNotBlank()) rootList.add(s)
            }

            var verb: Verb? = null
            val v = o.optJSONObject("verb")
            if (v != null) {
                val past = ArrayList<String>()
                val present = ArrayList<String>()
                val subjunctive = ArrayList<String>()
                val jussive = ArrayList<String>()
                val imperative = ArrayList<String>()
                val passivePast = ArrayList<String>()
                val passivePresent = ArrayList<String>()
                
                val conj = v.optJSONArray("conjugation")
                for (i in 0 until 14) {
                    val c = conj?.optJSONObject(i)
                    past.add(c?.str("past") ?: "")
                    present.add(c?.str("present") ?: "")
                    subjunctive.add(c?.str("subjunctive") ?: "")
                    jussive.add(c?.str("jussive") ?: "")
                    imperative.add(c?.str("imperative") ?: "")
                    passivePast.add(c?.str("passivePast") ?: "")
                    passivePresent.add(c?.str("passivePresent") ?: "")
                }
                val match = v.optJSONObject("inputMatch")
                val matchIndex = if (match != null && !match.isNull("index")) match.optInt("index", -1) else -1
                val matchTense = match?.str("tense") ?: ""
                verb = Verb(
                    form = v.str("form"),
                    pattern = v.str("pattern"),
                    dictionaryForm = v.str("dictionaryForm"),
                    presentForm = v.str("presentForm"),
                    masdar = v.str("masdar"),
                    masdarWazn = v.str("masdarWazn"),
                    inputTense = v.str("inputTense"),
                    inputPerson = v.str("inputPerson"),
                    matchIndex = matchIndex,
                    matchTense = matchTense,
                    past = past,
                    present = present,
                    subjunctive = subjunctive,
                    jussive = jussive,
                    imperative = imperative,
                    passivePast = passivePast,
                    passivePresent = passivePresent
                )
            }

            val formsList = ArrayList<String>()
            val formsArr = o.optJSONArray("forms")
            if (formsArr != null) {
                for (fstr in formsArr.strings()) if (fstr.isNotBlank()) formsList.add(fstr)
            }

            return Word(
                word = o.str("word"),
                forms = formsList,
                translit = o.str("transliteration"),
                pos = o.str("partOfSpeech"),
                grammar = o.str("grammarNote"),
                root = rootList,
                rootGloss = o.str("rootGloss"),
                rootGlossTx = translation?.str("root") ?: "",
                waznPattern = wazn?.str("pattern") ?: "",
                waznNote = wazn?.str("note") ?: "",
                meaningEn = meaning?.str("en") ?: "",
                meaningAr = meaning?.str("ar") ?: "",
                meaningTx = translation?.str("meaning") ?: "",
                examples = examples,
                synonyms = synonyms,
                antonyms = antonyms,
                verb = verb,
                note = o.str("note")
            )
        }
    }
}

/** The 14 pronouns in the order used everywhere: 3rd, 2nd, 1st person. Pair = Arabic, English label. */
val PRONOUNS: List<Pair<String, String>> = listOf(
    Pair("هُوَ", "he · 3rd masc. singular"),
    Pair("هُمَا", "they two · 3rd masc. dual"),
    Pair("هُمْ", "they · 3rd masc. plural"),
    Pair("هِيَ", "she · 3rd fem. singular"),
    Pair("هُمَا", "they two · 3rd fem. dual"),
    Pair("هُنَّ", "they · 3rd fem. plural"),
    Pair("أَنْتَ", "you · 2nd masc. singular"),
    Pair("أَنْتُمَا", "you two · 2nd masc. dual"),
    Pair("أَنْتُمْ", "you · 2nd masc. plural"),
    Pair("أَنْتِ", "you · 2nd fem. singular"),
    Pair("أَنْتُمَا", "you two · 2nd fem. dual"),
    Pair("أَنْتُنَّ", "you · 2nd fem. plural"),
    Pair("أَنَا", "I · 1st singular"),
    Pair("نَحْنُ", "we · 1st plural")
)

/** A one-line summary of a word's meaning, for lists where the full definition would not fit. */
fun shortMeaning(w: Word): String {
    val first = w.meaningEn.split(Regex("[;\\n]|\\.\\s")).firstOrNull()?.trim() ?: ""
    val cleaned = first.replace(Regex("\\s*\\([^)]*\\)\\s*"), " ").trim()
    return if (cleaned.length > 70) cleaned.take(67) + "…" else cleaned
}
