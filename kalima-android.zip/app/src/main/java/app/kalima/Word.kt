package app.kalima

import org.json.JSONObject

data class Example(val ar: String, val en: String, val tx: String)

data class Gloss(val ar: String, val en: String, val tx: String)

data class Verb(
    val form: String,
    val pattern: String,
    val dictionaryForm: String,
    val presentForm: String,
    val masdar: String,
    val masdarWazn: String,
    val inputTense: String,
    val inputPerson: String,
    val matchIndex: Int,
    val matchTense: String,
    val past: List<String>,
    val present: List<String>
)

data class Word(
    val word: String,
    val translit: String,
    val pos: String,
    val grammar: String,
    val root: List<String>,
    val rootGloss: String,
    val rootGlossTx: String,
    val waznPattern: String,
    val waznNote: String,
    val meaningEn: String,
    val meaningAr: String,
    val meaningTx: String,
    val examples: List<Example>,
    val synonyms: List<Gloss>,
    val antonyms: List<Gloss>,
    val verb: Verb?,
    val note: String
) {
    companion object {
        fun fromJson(o: JSONObject): Word {
            val meaning = o.optJSONObject("meaning")
            val wazn = o.optJSONObject("wazn")

            val examples = ArrayList<Example>()
            val exArr = o.optJSONArray("examples")
            if (exArr != null) {
                for (x in exArr.objects()) examples.add(Example(x.str("ar"), x.str("en"), x.str("tx")))
            }
            val synonyms = ArrayList<Gloss>()
            val synArr = o.optJSONArray("synonyms")
            if (synArr != null) {
                for (x in synArr.objects()) synonyms.add(Gloss(x.str("ar"), x.str("en"), x.str("tx")))
            }
            val antonyms = ArrayList<Gloss>()
            val antArr = o.optJSONArray("antonyms")
            if (antArr != null) {
                for (x in antArr.objects()) antonyms.add(Gloss(x.str("ar"), x.str("en"), x.str("tx")))
            }

            val rootList = ArrayList<String>()
            val rootArr = o.optJSONArray("root")
            if (rootArr != null) {
                for (s in rootArr.strings()) if (s.isNotBlank()) rootList.add(s)
            }

            var verb: Verb? = null
            val v = o.optJSONObject("verb")
            if (v != null) {
                val past = ArrayList<String>()
                val present = ArrayList<String>()
                val conj = v.optJSONArray("conjugation")
                for (i in 0 until 14) {
                    val c = conj?.optJSONObject(i)
                    past.add(c?.str("past") ?: "")
                    present.add(c?.str("present") ?: "")
                }
                val match = v.optJSONObject("inputMatch")
                val matchIndex = if (match != null && !match.isNull("index")) match.optInt("index", -1) else -1
                val matchTense = match?.str("tense") ?: ""
                verb = Verb(
                    form = v.str("form"),
                    pattern = v.str("pattern"),
                    dictionaryForm = v.str("dictionaryForm"),
                    presentForm = v.str("presentForm"),
                    masdar = v.str("masdar"),
                    masdarWazn = v.str("masdarWazn"),
                    inputTense = v.str("inputTense"),
                    inputPerson = v.str("inputPerson"),
                    matchIndex = matchIndex,
                    matchTense = matchTense,
                    past = past,
                    present = present
                )
            }

            return Word(
                word = o.str("word"),
                translit = o.str("transliteration"),
                pos = o.str("partOfSpeech"),
                grammar = o.str("grammarNote"),
                root = rootList,
                rootGloss = o.str("rootGloss"),
                rootGlossTx = o.str("rootGlossTx"),
                waznPattern = wazn?.str("pattern") ?: "",
                waznNote = wazn?.str("note") ?: "",
                meaningEn = meaning?.str("en") ?: "",
                meaningAr = meaning?.str("ar") ?: "",
                meaningTx = meaning?.str("tx") ?: "",
                examples = examples,
                synonyms = synonyms,
                antonyms = antonyms,
                verb = verb,
                note = o.str("note")
            )
        }
    }
}

/** The 14 pronouns in the order used everywhere: 3rd, 2nd, 1st person. Pair = Arabic, English label. */
val PRONOUNS: List<Pair<String, String>> = listOf(
    Pair("هُوَ", "he · 3rd masc. singular"),
    Pair("هُمَا", "they two · 3rd masc. dual"),
    Pair("هُمْ", "they · 3rd masc. plural"),
    Pair("هِيَ", "she · 3rd fem. singular"),
    Pair("هُمَا", "they two · 3rd fem. dual"),
    Pair("هُنَّ", "they · 3rd fem. plural"),
    Pair("أَنْتَ", "you · 2nd masc. singular"),
    Pair("أَنْتُمَا", "you two · 2nd masc. dual"),
    Pair("أَنْتُمْ", "you · 2nd masc. plural"),
    Pair("أَنْتِ", "you · 2nd fem. singular"),
    Pair("أَنْتُمَا", "you two · 2nd fem. dual"),
    Pair("أَنْتُنَّ", "you · 2nd fem. plural"),
    Pair("أَنَا", "I · 1st singular"),
    Pair("نَحْنُ", "we · 1st plural")
)
