package app.kalima
import org.json.JSONArray

/** Sentence readings with different vowel marks remain distinct. Never mix with word history. */
internal object SentenceHistory {
    const val LIMIT=60
    fun decode(raw:String):List<String> {
        val a=JSONArray(raw)
        return (0 until a.length()).mapNotNull { i ->
            val s=a.opt(i) as? String ?: return@mapNotNull null
            s.trim().takeIf { SentenceGrammar.inputError(it)==null }
        }.distinct().take(LIMIT)
    }
    fun add(old:List<String>,sentence:String):List<String> {
        val s=sentence.trim()
        if(SentenceGrammar.inputError(s)!=null)return old
        return (listOf(s)+old.filter {it!=s}).take(LIMIT)
    }
    fun encode(items:List<String>):String=JSONArray(items).toString()
}
