package app.kalima

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupActions(vm: MainViewModel) {
    val resolver = LocalContext.current.contentResolver
    val scope = rememberCoroutineScope()
    var pendingText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val writer: (android.net.Uri?) -> Unit = { uri ->
        if (uri != null) {
            val text = pendingText
            busy = true
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { resolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: error("The file couldn't be opened.") }
                    vm.notice = "File saved."
                } catch (_: Exception) { vm.notice = "Couldn't save that file. Choose another location and try again." }
                finally { busy = false; pendingText = "" }
            }
        } else pendingText = ""
    }
    val jsonExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json"), writer)
    val csvExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv"), writer)
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) {
                        resolver.openInputStream(uri)?.use { input ->
                            val out = ByteArrayOutputStream(); val buffer = ByteArray(8192)
                            while (true) {
                                val count = input.read(buffer); if (count < 0) break
                                require(out.size() + count <= 20 * 1024 * 1024) { "This backup is too large (maximum 20 MB)." }
                                out.write(buffer, 0, count)
                            }
                            out.toString("UTF-8")
                        } ?: error("The backup couldn't be opened.")
                    }
                    vm.importData(text)
                } catch (e: Exception) { vm.notice = e.message ?: "Couldn't open that backup." }
                finally { busy = false }
            }
        }
    }
    fun date() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { pendingText = vm.exportData(); jsonExport.launch("kalima-backup-${date()}.json") }, enabled = !busy && vm.savedEntries.isNotEmpty(), shape = RoundedCornerShape(12.dp)) { Text("Export backup") }
        OutlinedButton(onClick = { pendingText = vm.exportCsv(); csvExport.launch("kalima-words-${date()}.csv") }, enabled = !busy && vm.savedEntries.isNotEmpty(), shape = RoundedCornerShape(12.dp)) { Text("Export CSV") }
        OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, enabled = !busy, shape = RoundedCornerShape(12.dp)) { Text("Import backup") }
    }
    Text("Backups include saved words, translations, downloaded conjugations and review progress. Imports keep your existing words and progress. Account details are not included.", color = colorMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
}
