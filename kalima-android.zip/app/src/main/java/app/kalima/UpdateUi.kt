package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.activity.ComponentActivity
import androidx.lifecycle.withResumed
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
internal fun UpdateDialogs(updates: AppUpdates) {
    val activity = LocalContext.current as? ComponentActivity
    val event = updates.installEvent
    LaunchedEffect(event) {
        if (event > 0 && activity != null) activity.lifecycle.withResumed {
            updates.handleInstallEvent(activity, event)
        }
    }
    updates.message?.let { message ->
        AlertDialog(onDismissRequest = updates::dismissMessage,
            title = { Text("App updates") }, text = { Text(message) },
            confirmButton = { TextButton(onClick = updates::dismissMessage) { Text("Close") } })
    }
    val release = updates.release ?: return
    AlertDialog(onDismissRequest = updates::later,
        title = { Text("A Kalima update is available") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Version ${release.versionName}")
                if (release.notes.isNotBlank()) {
                    Text("What's new")
                    RawText(release.notes, color = colorInk)
                }
                Text("Android will ask you to confirm installation. You may need to allow updates from Kalima.")
                if (updates.downloading) {
                    LinearProgressIndicator(progress = { updates.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("Downloading update: ${updates.progress}%")
                }
                updates.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = updates::download, enabled = !updates.downloading) { Text(if (updates.error != null) "Retry" else "Update") }
        },
        dismissButton = { TextButton(onClick = updates::later) { Text("Later") } })
}
