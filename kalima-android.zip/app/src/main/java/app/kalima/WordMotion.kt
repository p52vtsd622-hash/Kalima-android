package app.kalima

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

internal data class WordAnchor(val bounds: Rect, val size: Float, val leading: Float, val owner: Any, val singleLine: Boolean)
internal data class WordFlight(val word: String, val from: WordAnchor, val to: WordAnchor, val target: String)
internal data class WordOrigin(val tab: String, val word: String)
private data class PendingWord(val word: String, val from: WordAnchor, val target: String)

internal class WordMotionState(initialOrigin: WordOrigin? = null) {
    private val anchors = mutableMapOf<String, WordAnchor>()
    private var pending by mutableStateOf<PendingWord?>(null)
    var active by mutableStateOf<WordFlight?>(null)
        private set
    var origin by mutableStateOf(initialOrigin)
        private set
    var enabled = true
    private var lastDetail: WordAnchor? = null
    private var lastDetailKey: String? = null
    fun register(key: String, anchor: WordAnchor) {
        anchors[key] = anchor
        if (key.startsWith("detail:")) { lastDetail = anchor; lastDetailKey = key }
        pending?.takeIf { it.target == key }?.let {
            if (enabled && it.from.singleLine && anchor.singleLine) active = WordFlight(it.word, it.from, anchor, key)
            pending = null
        }
    }
    fun unregister(key: String, owner: Any) { if (anchors[key]?.owner === owner) anchors.remove(key) }
    fun open(tab: String, word: String, animate: Boolean = true, action: () -> Unit) {
        cancel()
        origin = WordOrigin(tab, word)
        if (enabled && animate) anchors["$tab:$word"]?.let { pending = PendingWord(word, it, "detail:$word") }
        action()
    }
    fun returnTo(tab: String, word: String?) {
        val source = origin ?: return
        if (source.tab != tab || source.word != word) { cancel(); origin = null; return }
        val from = lastDetail.takeIf { lastDetailKey == "detail:${source.word}" }
        cancel()
        if (enabled && from != null) {
            val key = "$tab:${source.word}"
            pending = PendingWord(source.word, from, key)
            anchors[key]?.let { register(key, it) }
        }
        origin = null
    }
    fun complete(flight: WordFlight) { if (active === flight) active = null }
    fun cancel() { active = null; pending = null }
    fun forgetOrigin() { cancel(); origin = null }
}

private val WordMotionSaver = listSaver<WordMotionState, String>(
    save = { listOf(it.origin?.tab.orEmpty(), it.origin?.word.orEmpty()) },
    restore = { WordMotionState(if (it.size == 2 && it[0] in listOf("saved", "history") && it[1].isNotBlank()) WordOrigin(it[0], it[1]) else null) })

internal val LocalWordMotion = staticCompositionLocalOf<WordMotionState?> { null }
internal val LocalCompactWordVisible = staticCompositionLocalOf { false }

/** Only the decorative word is overlaid; screens and interactive controls have one instance. */
@Composable
internal fun WordMotionHost(vm: MainViewModel, content: @Composable () -> Unit) {
    val state = rememberSaveable(saver = WordMotionSaver) { WordMotionState() }
    LaunchedEffect(vm.searchFocused) { if (vm.searchFocused) state.cancel() }
    val reduced = rememberReducedMotion()
    SideEffect { state.enabled = !reduced }
    var previousTab by remember { mutableStateOf(vm.currentTab) }
    LaunchedEffect(vm.currentTab, reduced) {
        if (reduced) state.cancel()
        if (previousTab == "lookup" && vm.currentTab != "lookup") state.returnTo(vm.currentTab, vm.result?.word)
        previousTab = vm.currentTab
    }
    BackHandler(enabled = !vm.searchFocused && vm.currentTab == "lookup" && state.origin?.word == vm.result?.word && state.origin != null) {
        state.origin?.let { vm.currentTab = it.tab }
    }
    val flight = state.active
    val progress = remember(flight) { Animatable(0f) }
    LaunchedEffect(flight, reduced) {
        if (flight != null) {
            if (!reduced) progress.animateTo(1f, spring(dampingRatio = 1f, stiffness = 420f))
            state.complete(flight)
        }
    }
    // A destination that never appears must not retain a hidden or stale transition.
    LaunchedEffect(vm.currentTab, vm.result?.word) {
        if (vm.currentTab == "lookup" && state.origin?.word != vm.result?.word) state.forgetOrigin()
        if (vm.currentTab !in listOf("lookup", "saved", "history")) state.forgetOrigin()
        delay(600)
        if (state.active == null) state.cancel()
    }
    var hostPosition by remember { mutableStateOf(Offset.Zero) }
    val measurer = rememberTextMeasurer()
    val ink = colorInk
    CompositionLocalProvider(LocalWordMotion provides state) {
        Box(Modifier.fillMaxSize().onGloballyPositioned { hostPosition = it.positionInRoot() }) {
            content()
            if (flight != null && !reduced) Canvas(Modifier.matchParentSize().clearAndSetSemantics {}) {
                val t = progress.value.coerceIn(0f, 1f)
                val center = flight.from.bounds.center + (flight.to.bounds.center - flight.from.bounds.center) * t - hostPosition
                if (center.y in 0f..size.height) {
                    val font = flight.from.size + (flight.to.size - flight.from.size) * t
                    val leading = flight.from.leading + (flight.to.leading - flight.from.leading) * t
                    // Remeasure the script at its real font size, never distort a glyph bitmap.
                    val layout = measurer.measure(flight.word,
                        style = TextStyle(color = ink, fontFamily = arabicFont, fontSize = font.sp,
                            lineHeight = leading.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Center),
                        constraints = Constraints(maxWidth = (size.width - 40 * density).toInt().coerceAtLeast(1)))
                    drawText(layout, topLeft = center - Offset(layout.size.width / 2f, layout.size.height / 2f))
                }
            }
        }
    }
}

@Composable
internal fun MovingWord(word: String, key: String, size: Int, leading: Int, modifier: Modifier = Modifier,
    align: TextAlign = TextAlign.Center, register: Boolean = true) {
    val state = LocalWordMotion.current
    val owner = remember { Any() }
    var singleLine by remember(word) { mutableStateOf(false) }
    DisposableEffect(state, key, register) { onDispose { state?.unregister(key, owner) } }
    val hidden = state?.active?.let { it.word == word && it.target == key } == true
    Text(word, modifier.graphicsLayer { alpha = if (hidden) 0f else 1f }.onGloballyPositioned {
        if (register) state?.register(key, WordAnchor(it.boundsInRoot(), size.toFloat(), leading.toFloat(), owner, singleLine))
    }, color = colorInk, fontFamily = arabicFont, fontSize = size.sp, lineHeight = leading.sp,
        onTextLayout = { singleLine = it.lineCount == 1 }, textAlign = align, style = TextStyle(textDirection = TextDirection.Rtl))
}
