package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Celebration is driven by a confirmed local save, never by opening a saved word. */
@Composable
internal fun AnimatedSavePill(
    wordId: String?, saved: Boolean, onToggle: () -> Boolean, modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    fun animationsOff() = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    var reducedMotion by remember(context) { mutableStateOf(animationsOff()) }
    DisposableEffect(context) {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { reducedMotion = animationsOff() }
        }
        context.contentResolver.registerContentObserver(Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE), false, observer)
        onDispose { context.contentResolver.unregisterContentObserver(observer) }
    }
    // A new result cancels feedback belonging to the previous word.
    key(wordId) {
        val interactions = remember { MutableInteractionSource() }
        val pressed by interactions.collectIsPressedAsState()
        var success by remember { mutableIntStateOf(0) }
        var animatedSuccess by remember { mutableIntStateOf(0) }
        val bounce = remember { Animatable(1f) }
        val check = remember { Animatable(if (saved) 1f else 0f) }
        LaunchedEffect(success, saved, reducedMotion) {
            val celebrate = success > animatedSuccess
            animatedSuccess = success
            bounce.snapTo(1f)
            check.snapTo(if (saved) 1f else 0f)
            if (celebrate && saved && !reducedMotion) {
                check.snapTo(0f)
                kotlinx.coroutines.coroutineScope {
                    launch {
                        bounce.animateTo(1f, keyframes {
                            durationMillis = 280
                            1f at 0; 1.035f at 85; 0.99f at 175; 1f at 280
                        })
                    }
                    launch { check.animateTo(1f, tween(200)) }
                }
            }
        }
        val press by animateFloatAsState(if (pressed && !reducedMotion) 0.96f else 1f,
            if (reducedMotion) tween(0) else spring(dampingRatio = .82f, stiffness = 700f), label = "Save press")
        val baseFill = if (saved) colorPrimary else colorPrimaryLight
        val fill by animateColorAsState(lerp(baseFill, if (isDark) Color.White else Color.Black, if (pressed) 0.06f else 0f),
            tween(if (reducedMotion) 0 else 150), label = "Save fill")
        val ink by animateColorAsState(if (saved) colorPrimaryFg else colorPrimaryLightFg,
            tween(if (reducedMotion) 0 else 150), label = "Save ink")
        Box(modifier.heightIn(min = 48.dp)
            .semantics(mergeDescendants = true) {
                stateDescription = tr(if (wordId == null) "Look up a word first" else if (saved) "Word saved" else "Word not saved")
                liveRegion = LiveRegionMode.Polite
            }
            .clip(RoundedCornerShape(50))
            .clickable(enabled = wordId != null, role = Role.Button,
                interactionSource = interactions, indication = null,
                onClickLabel = tr(if (saved) "Remove saved word" else "Save word")) {
                if (onToggle()) success++
            }, contentAlignment = Alignment.Center) {
            Row(Modifier.padding(vertical = 6.dp).fillMaxWidth().heightIn(min = 36.dp)
                .graphicsLayer {
                    val scale = if (reducedMotion) 1f else press * bounce.value
                    scaleX = scale; scaleY = scale
                    alpha = if (wordId == null) 0.55f else 1f
                }
                .background(fill, RoundedCornerShape(50)).padding(horizontal = 5.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(13.dp)) {
                    val path = Path()
                    val stroke = Stroke(width = 1.7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    if (saved) {
                        path.moveTo(size.width * 0.13f, size.height * 0.52f)
                        path.lineTo(size.width * 0.4f, size.height * 0.78f)
                        path.lineTo(size.width * 0.88f, size.height * 0.23f)
                        val measure = PathMeasure().apply { setPath(path, false) }
                        val segment = Path()
                        measure.getSegment(0f, measure.length * check.value, segment, true)
                        drawPath(segment, ink, style = stroke)
                    } else {
                        path.moveTo(size.width * 0.25f, size.height * 0.12f)
                        path.lineTo(size.width * 0.75f, size.height * 0.12f)
                        path.lineTo(size.width * 0.75f, size.height * 0.88f)
                        path.lineTo(size.width * 0.5f, size.height * 0.7f)
                        path.lineTo(size.width * 0.25f, size.height * 0.88f)
                        path.close()
                        drawPath(path, ink, style = stroke)
                    }
                }
                Crossfade(saved, animationSpec = tween(if (reducedMotion) 0 else 100), label = "Save label",
                    modifier = Modifier.weight(1f, fill = false)) { checked ->
                    Text(if (checked) "Saved" else "Save", color = ink, fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
