package app.kalima

import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Immutable local search material, independent of the UI and request client. */
internal data class LocalWordCandidate(val id: String, val arabic: String, val fields: List<String>)
internal object HomeSearchIndex {
    fun normalize(text: String): String {
        val decomposed = Normalizer.normalize(text.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        val cleaned = buildString {
            for (c in decomposed) {
                val type = Character.getType(c)
                if (type == Character.ENCLOSING_MARK.toInt() || type == Character.NON_SPACING_MARK.toInt() || type == Character.COMBINING_SPACING_MARK.toInt() || type == Character.FORMAT.toInt() || c == 'ـ') continue
                append(when (c) { 'ى', 'ی' -> 'ي'; 'ک' -> 'ك'; 'ٱ' -> 'ا'; else -> if (c.isWhitespace()) ' ' else c })
            }
        }
        return cleaned.split(' ').filter { it.isNotEmpty() }.joinToString(" ")
    }
    fun build(entries: List<JSONObject>): List<LocalWordCandidate> {
        val result = linkedMapOf<String, LocalWordCandidate>()
        entries.forEach { entry ->
            val id = (entry.opt("id") as? String)?.takeIf { it.isNotBlank() } ?: return@forEach
            val data = entry.optJSONObject("data") ?: return@forEach
            val arabic = (data.opt("word") as? String)?.takeIf { it.isNotBlank() } ?: id
            val fields = mutableListOf(id, arabic)
            (data.opt("transliteration") as? String)?.let(fields::add)
            data.optJSONObject("meaning")?.let { meaning ->
                meaning.keys().forEach { key -> (meaning.opt(key) as? String)?.let(fields::add) }
            }
            data.optJSONObject("trans")?.let { trans ->
                trans.keys().forEach { key -> (trans.optJSONObject(key)?.opt("meaning") as? String)?.let(fields::add) }
            }
            result.putIfAbsent(id, LocalWordCandidate(id, arabic, fields.map(::normalize).filter { it.isNotEmpty() }.distinct()))
        }
        return result.values.toList()
    }
    fun search(index: List<LocalWordCandidate>, query: String, limit: Int = 6): List<LocalWordCandidate> {
        val q = normalize(query)
        if (q.isEmpty() || limit <= 0) return emptyList()
        return index.mapIndexedNotNull { position, word ->
            val ar = normalize(word.arabic)
            val rank = when {
                ar == q -> 0
                ar.startsWith(q) -> 1
                word.fields.any { it.startsWith(q) } -> 2
                word.fields.any { field -> field.split(' ').any { it.startsWith(q) } } -> 3
                word.fields.any { it.contains(q) } -> 4
                else -> return@mapIndexedNotNull null
            }
            Triple(rank, position, word)
        }.sortedWith(compareBy<Triple<Int, Int, LocalWordCandidate>> { it.first }.thenBy { it.second })
            .take(limit).map { it.third }
    }
}
