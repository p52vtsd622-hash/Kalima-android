package app.kalima

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF4A835C), onPrimary = Color.White,
    background = Color(0xFFF8F6F0), onBackground = Color(0xFF1D231F),
    surface = Color.White, onSurface = Color(0xFF1D231F),
    surfaceVariant = Color(0xFFE3EDE5), onSurfaceVariant = Color(0xFF6A7A71),
    outline = Color(0xFFDEDAD1), error = Color(0xFFA8382F)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB89B), onPrimary = Color(0xFF161718),
    background = Color(0xFF161718), onBackground = Color(0xFFE0E2E0),
    surface = Color(0xFF1B1D1C), onSurface = Color(0xFFE0E2E0),
    surfaceVariant = Color(0xFF0D1C12), onSurfaceVariant = Color(0xFF828683),
    outline = Color(0xFF2D302E), error = Color(0xFFF08A80)
)
private fun readingTypography(language: String): Typography {
    val font = translationFont(language)
    return Typography(
        headlineLarge = TextStyle(fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 30.sp, lineHeight = 42.sp),
        bodyLarge = TextStyle(fontFamily = font, fontSize = 17.sp, lineHeight = 27.sp),
        bodyMedium = TextStyle(fontFamily = font, fontSize = 16.sp, lineHeight = 25.sp),
        bodySmall = TextStyle(fontFamily = font, fontSize = 14.sp, lineHeight = 22.sp),
        titleLarge = TextStyle(fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 32.sp),
        titleMedium = TextStyle(fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 28.sp),
        labelLarge = TextStyle(fontFamily = font, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 23.sp)
    )
}
@Composable
fun KalimaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val language = appPrefs?.appLanguage ?: "en"
    val typography = remember(language) { readingTypography(language) }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = typography, content = content)
}
