package app.kalima

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF4A835C), onPrimary = Color.White,
    background = Color(0xFFF8F6F0), onBackground = Color(0xFF1D231F),
    surface = Color.White, onSurface = Color(0xFF1D231F),
    surfaceVariant = Color(0xFFE3EDE5), onSurfaceVariant = Color(0xFF6A7A71),
    outline = Color(0xFFDEDAD1), error = Color(0xFFA8382F)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB89B), onPrimary = Color(0xFF161718),
    background = Color(0xFF161718), onBackground = Color(0xFFE0E2E0),
    surface = Color(0xFF1B1D1C), onSurface = Color(0xFFE0E2E0),
    surfaceVariant = Color(0xFF0D1C12), onSurfaceVariant = Color(0xFF828683),
    outline = Color(0xFF2D302E), error = Color(0xFFF08A80)
)
private val WebTypography = Typography(
    bodyLarge = TextStyle(fontFamily = latinFont, fontSize = 17.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontFamily = latinFont, fontSize = 16.sp, lineHeight = 25.sp),
    bodySmall = TextStyle(fontFamily = latinFont, fontSize = 14.sp, lineHeight = 22.sp),
    titleLarge = TextStyle(fontFamily = latinFont, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontFamily = latinFont, fontWeight = FontWeight.Medium, fontSize = 17.sp, lineHeight = 26.sp),
    labelLarge = TextStyle(fontFamily = latinFont, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 23.sp)
)
@Composable
fun KalimaTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = WebTypography, content = content)
}
