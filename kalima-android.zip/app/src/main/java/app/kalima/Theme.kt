package app.kalima

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF274690),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF16213A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF16213A),
    surfaceVariant = Color(0xFFF5F7FA),
    onSurfaceVariant = Color(0xFF5A6479),
    outline = Color(0xFFD8DEE8),
    error = Color(0xFFA8382F)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3A5BB0),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFF0F1524),
    onBackground = Color(0xFFE8ECF5),
    surface = Color(0xFF0F1524),
    onSurface = Color(0xFFE8ECF5),
    surfaceVariant = Color(0xFF172036),
    onSurfaceVariant = Color(0xFF98A2B8),
    outline = Color(0xFF2A3550),
    error = Color(0xFFF08A80)
)

@Composable
fun KalimaTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content
    )
}
