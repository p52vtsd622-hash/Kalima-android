package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Physical horizontal directions are explicitly labelled and never auto-mirrored. */
internal object FlashcardSwipe {
    fun grade(offset: Float, width: Float, revealed: Boolean): Boolean? {
        if (!revealed || !offset.isFinite() || !width.isFinite() || width <= 0f || abs(offset) < width * 0.28f) return null
        return offset > 0f
    }
}

@Composable
internal fun InteractiveFlashcard(w: Word, lang: String, flipped: Boolean, onFlip: () -> Unit, onGrade: (Boolean) -> Boolean) {
    val reduced = rememberReducedMotion()
    val noMotion by rememberUpdatedState(reduced)
    val angle by animateFloatAsState(if (flipped) 180f else 0f, tween(if (reduced) 0 else 300), label = "Flashcard flip")
    val showBack = angle >= 90f
    val scope = rememberCoroutineScope()
    var offset by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    val returnMotion = remember { Animatable(0f) }
    val density = LocalDensity.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val width = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
        val canGrade = flipped && angle >= 179.9f && !busy
        val latestGrade by rememberUpdatedState(onGrade)
        fun commit(correct: Boolean) {
            if (busy || !flipped || angle < 179.9f) return
            busy = true
            scope.launch {
                try {
                    if (!noMotion) {
                        returnMotion.snapTo(offset)
                        returnMotion.animateTo(if (correct) width * 1.15f else -width * 1.15f, tween(160)) { offset = value }
                    }
                    if (!latestGrade(correct)) {
                        returnMotion.snapTo(offset)
                        returnMotion.animateTo(0f, if (noMotion) tween(0) else spring(dampingRatio = .9f, stiffness = 650f)) { offset = value }
                    }
                } finally { busy = false }
            }
        }
        Column(Modifier.fillMaxWidth()) {
            Text(if (!flipped) "Tap to reveal the meaning" else "← Again     ·     Got it →", color = colorMuted,
                fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), textAlign = TextAlign.Center)
            val gesture = if (canGrade) Modifier.pointerInput(width, canGrade) {
                detectHorizontalDragGestures(
                    onDragStart = { offset = 0f },
                    onDragCancel = {
                        busy = true
                        scope.launch { try { returnMotion.snapTo(offset); returnMotion.animateTo(0f, if (noMotion) tween(0) else spring(dampingRatio = .9f, stiffness = 650f)) { offset = value } } finally { busy = false } }
                    },
                    onDragEnd = {
                        val grade = FlashcardSwipe.grade(offset, width, flipped)
                        if (grade != null) commit(grade)
                        else {
                            busy = true
                            scope.launch { try { returnMotion.snapTo(offset); returnMotion.animateTo(0f, if (noMotion) tween(0) else spring(dampingRatio = .9f, stiffness = 650f)) { offset = value } } finally { busy = false } }
                        }
                    },
                    onHorizontalDrag = { change, amount -> change.consume(); offset = (offset + amount).coerceIn(-width, width) }
                )
            } else Modifier
            Card(Modifier.fillMaxWidth().then(gesture)
                .graphicsLayer {
                    translationX = offset
                    rotationY = if (reduced) 0f else angle
                    rotationZ = if (reduced) 0f else (offset / width * 7f).coerceIn(-7f, 7f)
                    val drag = (abs(offset) / width).coerceIn(0f, 1f)
                    rotationX = if (reduced) 0f else -drag * 1.5f
                    shadowElevation = if (reduced) 0f else (2f + drag * 8f) * density.density
                    shape = KalimaDesign.cardShape
                    clip = false
                    cameraDistance = 14f * density.density
                }
                .semantics { stateDescription = tr(if (showBack) "Meaning revealed" else "Arabic word") }
                .clickable(enabled = !busy, role = Role.Button, onClickLabel = tr(if (flipped) "Show Arabic" else "Reveal meaning"), onClick = onFlip),
                shape = KalimaDesign.cardShape, border = BorderStroke(1.dp, colorLine),
                colors = CardDefaults.cardColors(containerColor = colorPrimaryLight)) {
                Box(Modifier.fillMaxWidth().heightIn(min = 250.dp)) {
                    Column(Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp)
                        .graphicsLayer { alpha = if (showBack) 0f else 1f }
                        .then(if (showBack) Modifier.clearAndSetSemantics {} else Modifier), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(w.word, style = TextStyle(fontFamily = arabicFont, fontSize = 60.sp, lineHeight = 84.sp, textDirection = TextDirection.Rtl), color = colorInk, textAlign = TextAlign.Center)
                        Text("Tap to see the meaning", color = colorPrimaryLightFg, fontSize = 14.sp)
                    }
                    Column(Modifier.fillMaxWidth().padding(24.dp)
                        .graphicsLayer { rotationY = if (reduced) 0f else 180f; alpha = if (showBack) 1f else 0f }
                        .then(if (!showBack) Modifier.clearAndSetSemantics {} else Modifier), horizontalAlignment = Alignment.CenterHorizontally) {
                        ArabicText(w.word, 40, Modifier.fillMaxWidth())
                        if (w.translit.isNotBlank() && (appPrefs?.appLanguage ?: "en") != "ar") Text(w.translit, color = colorPrimaryLightFg, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(w.meaningEn, fontSize = 18.sp, color = colorInk, textAlign = TextAlign.Center)
                        TxLine(w.meaningTx, lang)
                        if (w.root.isNotEmpty()) Text("Root: " + w.root.joinToString(" · "), fontFamily = arabicFont, color = colorPrimaryLightFg)
                        w.examples.firstOrNull()?.let { ex ->
                            Spacer(Modifier.height(12.dp))
                            Text(ex.ar, style = TextStyle(fontFamily = arabicFont, fontSize = 20.sp, lineHeight = 34.sp, textDirection = TextDirection.Rtl), color = colorInk, textAlign = TextAlign.Center)
                            Text(ex.en, color = colorPrimaryLightFg, fontSize = 14.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
            TextButton(onClick = onFlip, enabled = !busy, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text(if (flipped) "Show Arabic" else "Reveal meaning")
            }
            if (flipped) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { commit(false) }, enabled = canGrade, modifier = Modifier.weight(1f)) { Text("Again") }
                    Button(onClick = { commit(true) }, enabled = canGrade, modifier = Modifier.weight(1f)) { Text("Got it") }
                }
            }
        }
    }
    }
}
