package app.kalima

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class NahjEntry(val kind: String, val num: Int, val text: String)

class QuranCorpus(val verses: List<String>, val index: KalimaSearch.Index, private val cum: IntArray) {
    /** 1-based surah and ayah number for a verse's position in the flat verse list. */
    fun ref(u: Int): Pair<Int, Int> {
        var s = 0
        while (s + 1 < cum.size && cum[s + 1] <= u) s++
        return Pair(s + 1, u - cum[s] + 1)
    }
}

class NahjCorpus(val kinds: Map<String, String>, val passages: List<NahjEntry>, val index: KalimaSearch.Index)

/** Loads the bundled Quran and Nahj al-Balagha texts from assets and builds their search indices once. */
object Corpus {
    @Volatile private var quranCache: QuranCorpus? = null
    @Volatile private var nahjCache: NahjCorpus? = null
    private val quranLock = Any()
    private val nahjLock = Any()

    suspend fun quran(context: Context): QuranCorpus = withContext(Dispatchers.Default) {
        quranCache ?: synchronized(quranLock) {
            quranCache ?: buildQuran(context.applicationContext).also { quranCache = it }
        }
    }

    suspend fun nahj(context: Context): NahjCorpus = withContext(Dispatchers.Default) {
        nahjCache ?: synchronized(nahjLock) {
            nahjCache ?: buildNahj(context.applicationContext).also { nahjCache = it }
        }
    }

    private fun buildQuran(context: Context): QuranCorpus {
        val text = context.assets.open("quran-data.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val obj = JSONObject(text)
        val countsArr = obj.getJSONArray("counts")
        val counts = IntArray(countsArr.length()) { countsArr.getInt(it) }
        val versesArr = obj.getJSONArray("verses")
        val verses = ArrayList<String>(versesArr.length())
        for (i in 0 until versesArr.length()) verses.add(versesArr.getString(i))
        val cum = IntArray(counts.size)
        var s = 0
        for (i in counts.indices) { cum[i] = s; s += counts[i] }
        val index = KalimaSearch.buildIndex(verses) { tok -> KalimaSearch.quranVariants(tok) }
        return QuranCorpus(verses, index, cum)
    }

    private fun buildNahj(context: Context): NahjCorpus {
        val text = context.assets.open("nahj-data.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val obj = JSONObject(text)
        val kindsObj = obj.optJSONObject("kinds")
        val kinds = HashMap<String, String>()
        kindsObj?.keys()?.forEach { k -> kinds[k] = kindsObj.optString(k) }
        val pArr = obj.getJSONArray("p")
        val passages = ArrayList<NahjEntry>(pArr.length())
        for (i in 0 until pArr.length()) {
            val item = pArr.getJSONArray(i)
            passages.add(NahjEntry(item.getString(0), item.getInt(1), item.getString(2)))
        }
        val units = passages.map { it.text }
        val index = KalimaSearch.buildIndex(units) { tok -> KalimaSearch.standardVariants(tok) }
        return NahjCorpus(kinds, passages, index)
    }
}

/** Builds the word/verb forms used to search the texts, the same way the web app does. */
data class FormsBundle(val forms: List<String>, val verbForms: List<String>, val exact: List<String>, val exactIsVerb: Boolean)

fun collectForms(w: Word): FormsBundle {
    val verbForms = ArrayList<String>()
    val forms = ArrayList<String>()
    val exact = if (w.word.isNotBlank()) listOf(w.word) else emptyList()
    val v = w.verb
    if (v != null) {
        for (i in v.past.indices) {
            if (v.past[i].isNotBlank()) verbForms.add(v.past[i])
            if (i < v.present.size && v.present[i].isNotBlank()) verbForms.add(v.present[i])
        }
        if (v.dictionaryForm.isNotBlank()) verbForms.add(v.dictionaryForm)
        if (v.presentForm.isNotBlank()) verbForms.add(v.presentForm)
        if (v.masdar.isNotBlank()) forms.add(v.masdar)
    } else if (w.word.isNotBlank()) {
        forms.add(w.word)
    }
    forms.addAll(w.forms)

    fun clean(list: List<String>): List<String> {
        val seen = HashSet<String>()
        val out = ArrayList<String>()
        for (f in list) {
            val n = KalimaSearch.baseNorm(f)
            if (n.isNotEmpty() && seen.add(n)) out.add(f)
        }
        return out
    }
    return FormsBundle(clean(forms), clean(verbForms), exact, v != null)
}

/** Keeps up to 3 results from different groups first (e.g. different surahs), then the rest - so
 *  the first few examples shown are not all from the same place. Same rule as the web app: a group
 *  seen again later always goes to "rest", even if fewer than 3 distinct groups exist overall. */
fun <T> diverse(items: List<T>, groupOf: (T) -> Any): List<T> {
    val seen = HashSet<Any>()
    val first = ArrayList<T>()
    val rest = ArrayList<T>()
    for (item in items) {
        val g = groupOf(item)
        if (!seen.contains(g) && first.size < 3) {
            seen.add(g)
            first.add(item)
        } else {
            rest.add(item)
        }
    }
    return first + rest
}
