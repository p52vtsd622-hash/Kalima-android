package app.kalima

import androidx.compose.runtime.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlin.math.abs

internal class GlassMotion(initial: Float) {
    var position by mutableFloatStateOf(initial)
    var velocity by mutableFloatStateOf(0f)
    var dragging by mutableStateOf(false)
        private set
    var releaseRevision by mutableIntStateOf(0)
        private set
    private var lastTouchTime = 0L

    // Called on contact, before the drag threshold: a held lens cannot drift away.
    fun beginDrag(time: Long) {
        dragging = true
        velocity = 0f
        lastTouchTime = time
    }

    // Continuous fractional position, updated in the input callback, not rounded
    // to a tab and not delayed by a spring/recomposition/frame coroutine.
    fun dragTo(slot: Float, time: Long) {
        val next = slot.coerceIn(0f, 3f)
        val seconds = (time - lastTouchTime) / 1000f
        velocity = if (seconds > 0f) ((next - position) / seconds).coerceIn(-12f, 12f) else 0f
        position = next
        lastTouchTime = time
    }

    fun endDrag() {
        dragging = false
        // Settle gently to the nearest tab, without fling overshoot.
        velocity = 0f
        releaseRevision++
    }
}

@Composable
internal fun rememberGlassMotion(target: Float, reducedMotion: Boolean): GlassMotion {
    val motion = remember { GlassMotion(target) }
    val destination = rememberUpdatedState(target)
    // Finger movement updates the destination without cancelling the frame loop.
    LaunchedEffect(reducedMotion) {
        var last = 0L
        while (isActive) {
            if (motion.dragging) {
                snapshotFlow { motion.dragging }.first { !it }
                last = 0L
                continue
            }
            val goal = destination.value
            val release = motion.releaseRevision
            if (reducedMotion || (abs(motion.position - goal) <= 0.0003f && abs(motion.velocity) <= 0.001f)) {
                motion.position = goal; motion.velocity = 0f
                snapshotFlow { Triple(destination.value, motion.dragging, motion.releaseRevision) }
                    .first { it.first != goal || it.second || it.third != release }
                last = 0L
            } else {
                val now = withFrameNanos { it }
                if (motion.dragging) { last = 0L; continue }
                val dt = if (last == 0L) 1f / 60f else (now - last) / 1_000_000_000f
                val next = GlassSpring.advance(motion.position, motion.velocity, destination.value, dt)
                motion.position = next.first; motion.velocity = next.second; last = now
            }
        }
    }
    return motion
}
