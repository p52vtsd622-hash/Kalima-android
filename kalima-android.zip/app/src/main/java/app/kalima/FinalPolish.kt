package app.kalima

import app.kalima.LocalizedText as Text
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One incoming view only: no outgoing controls or duplicated network effects. */
@Composable
internal fun GentleContent(target: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val reduced = rememberReducedMotion()
    val alpha = remember(target, reduced) { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(alpha) { if (!reduced) alpha.animateTo(1f, tween(140)) }
    Box(modifier.graphicsLayer { this.alpha = if (reduced) 1f else alpha.value }) { content() }
}

@Composable
internal fun LoadingBars(compact: Boolean = false) {
    val scale = LocalDensity.current.fontScale.coerceAtLeast(1f)
    Column(Modifier.fillMaxWidth().clearAndSetSemantics {}, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val widths = if (compact) listOf(.85f, .6f) else listOf(.5f, 1f, .82f)
        widths.forEachIndexed { i, width ->
            Box(Modifier.fillMaxWidth(width).height((if (!compact && i == 0) 30.dp else 12.dp) * scale)
                .background(colorLine, RoundedCornerShape(6.dp)))
        }
    }
}

@Composable
internal fun LookupLoadingPlaceholder() {
    Column(Modifier.fillMaxWidth().clearAndSetSemantics {}, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ReadingSurface { LoadingBars(); Spacer(Modifier.height(24.dp)); LoadingBars(compact = true) }
        ReadingSurface { LoadingBars(compact = true); Spacer(Modifier.height(16.dp)) }
    }
}

internal enum class InteractionHaptic { Selection, Confirmation }

@Composable
internal fun rememberInteractionHaptic(prefs: Prefs): (InteractionHaptic) -> Unit {
    val view = LocalView.current
    return remember(view, prefs) { { event ->
        if (prefs.haptics && view.isHapticFeedbackEnabled) {
            val pattern = if (event == InteractionHaptic.Confirmation && Build.VERSION.SDK_INT >= 30)
                HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.CLOCK_TICK
            view.performHapticFeedback(pattern)
        }
        Unit
    } }
}

@Composable
internal fun UndoFeedback(vm: MainViewModel) {
    val pending = vm.pendingUndo ?: return
    val haptic = rememberInteractionHaptic(vm.prefs)
    val message = when (pending) {
        is UndoChange.Saved -> "Removed ${pending.word}"
        is UndoChange.History -> "Recent searches cleared"
    }
    Surface(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)
        .semantics { liveRegion = LiveRegionMode.Polite },
        color = colorPrimaryLight, shape = KalimaDesign.controlShape) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(message, color = colorPrimaryLightFg, fontSize = 15.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { vm.dismissUndo() }, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Dismiss") }
                TextButton(onClick = { if (vm.undoLastRemoval()) haptic(InteractionHaptic.Confirmation) },
                    colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Undo") }
            }
        }
    }
}
