package app.kalima

import kotlin.random.Random

internal data class SuggestedWord(val arabic: String, val kind: String)

/** A two-way timeline: revisiting a position always restores its original word. */
internal class SuggestionDeck(private val random: Random = Random.Default, previousWord: String? = null) {
    private val history = mutableMapOf<Int, SuggestedWord>()
    private val remaining = mutableListOf<SuggestedWord>()
    private var lastDraw: SuggestedWord? = words.find { it.arabic == previousWord }

    fun at(position: Int): SuggestedWord = history.getOrPut(position) {
        if (remaining.isEmpty()) remaining.addAll(words.shuffled(random))
        val excluded = setOf(lastDraw, history[position - 1], history[position + 1])
        val index = remaining.indexOfFirst { it !in excluded }
        val next = if (index >= 0) remaining.removeAt(index) else {
            // Keep adjacent pages different even across a shuffled-pool boundary.
            words.filter { it !in excluded }.random(random).also { remaining.remove(it) }
        }
        lastDraw = next
        next
    }

    fun refresh(previousPosition: Int = 0, lastVisibleWord: String? = null) {
        val previous = words.find { it.arabic == lastVisibleWord } ?: history[previousPosition] ?: lastDraw
        history.clear(); remaining.clear()
        remaining.addAll(words.shuffled(random))
        lastDraw = previous
        at(0)
    }

    companion object {
        // Offline, vocalized study starters. A shuffled pool cycles after exhaustion;
        // browsing never sends a network request. History lasts until Home refreshes.
        val words: List<SuggestedWord> = buildList {
            fun group(kind: String, text: String) { text.split(' ').forEach { add(SuggestedWord(it, kind)) } }
            group("masdar", "كِتَابَةٌ قِرَاءَةٌ دِرَاسَةٌ تَعَلُّمٌ تَعْلِيمٌ فَهْمٌ عِلْمٌ عَمَلٌ صَبْرٌ شُكْرٌ ذِكْرٌ فِكْرٌ سَفَرٌ دُخُولٌ خُرُوجٌ جُلُوسٌ قِيَامٌ رُجُوعٌ وُصُولٌ سَمَاعٌ نَظَرٌ كَلَامٌ سُؤَالٌ جَوَابٌ مَعْرِفَةٌ مَحَبَّةٌ مُسَاعَدَةٌ اِجْتِهَادٌ اِسْتِغْفَارٌ تَفْكِيرٌ")
            group("noun", "كِتَابٌ قَلَمٌ بَيْتٌ بَابٌ مَسْجِدٌ مَدْرَسَةٌ طَالِبٌ مُعَلِّمٌ رَجُلٌ اِمْرَأَةٌ طِفْلٌ صَدِيقٌ أَخٌ أُخْتٌ أَبٌ أُمٌّ شَمْسٌ قَمَرٌ نَجْمٌ سَمَاءٌ أَرْضٌ بَحْرٌ نَهْرٌ جَبَلٌ شَجَرَةٌ زَهْرَةٌ قَلْبٌ عَقْلٌ لِسَانٌ يَدٌ")
            group("verb", "كَتَبَ قَرَأَ دَرَسَ عَلِمَ فَهِمَ عَمِلَ صَبَرَ شَكَرَ ذَكَرَ فَكَّرَ سَافَرَ دَخَلَ خَرَجَ جَلَسَ قَامَ رَجَعَ وَصَلَ سَمِعَ نَظَرَ تَكَلَّمَ سَأَلَ أَجَابَ عَرَفَ أَحَبَّ سَاعَدَ اِجْتَهَدَ اِسْتَغْفَرَ تَعَلَّمَ عَلَّمَ ذَهَبَ")
        }
    }
}
