package app.kalima

import org.json.JSONArray

internal data class ConjugationColumn(val key: String, val title: String)
internal data class ConjugationForm(val text: String, val matched: Boolean) {
    val canListen get() = text != "—"
}
internal object ConjugationPresentation {
    val columns = listOf(
        ConjugationColumn("past", "Past"), ConjugationColumn("present", "Present"),
        ConjugationColumn("subjunctive", "Subjunctive"), ConjugationColumn("jussive", "Jussive"),
        ConjugationColumn("imperative", "Imperative"), ConjugationColumn("passivePast", "Passive past"),
        ConjugationColumn("passivePresent", "Passive present"))
    // Keep all fourteen pronoun positions even when a tense or person is missing.
    fun rows(data: JSONArray, matchIndex: Int, matchTense: String): List<List<ConjugationForm>> =
        PRONOUNS.indices.map { index -> columns.map { column ->
            val value = (data.optJSONObject(index)?.opt(column.key) as? String)?.trim()
            val text = value?.takeIf { it.isNotBlank() && it.lowercase() != "null" } ?: "—"
            ConjugationForm(text, text != "—" && index == matchIndex && column.key == matchTense)
        } }
}
