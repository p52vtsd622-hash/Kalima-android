package app.kalima
import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.semantics.*

/** Natural RTL wrapping in sentence order, without fixed card heights or clipped large text. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SentenceWordsContent(vm:MainViewModel){
    val state=vm.grammar.words
    val lang=vm.prefs.appLanguage
    ReadingSurface {
        Text("Words",color=colorPrimaryLightFg,fontSize=16.sp)
        vm.grammar.submitted?.let { sentence ->
            GrammarArabic(sentence,true)
            TextButton(onClick={vm.speak(sentence)}) { Text("Listen",color=colorPrimaryLightFg) }
        }
        Text("AI-generated contextual meanings.",color=colorMuted,fontSize=14.sp)
    }
    if(state.loading){
        SectionRequestFeedback(true,null,"Loading word meanings…",{})
        TextButton(onClick=state::cancel){Text("Cancel",color=colorPrimaryLightFg)}
    }
    state.error?.let { SectionRequestFeedback(false,tr(it),"",{vm.sentenceWords(true)}) }
    val result=state.result?.takeIf { it.language==lang && it.sentence==vm.grammar.submitted }
    if(result!=null){
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl){
            BoxWithConstraints(Modifier.fillMaxWidth()) {
            val fullWidth=maxWidth
            val scale=androidx.compose.ui.platform.LocalDensity.current.fontScale
            val columns=if(scale>1.3f || maxWidth<300.dp) 1 else if(maxWidth>=600.dp) 3 else 2
            val width=(maxWidth-12.dp*(columns-1))/columns
            FlowRow(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                result.items.forEachIndexed { index,item ->
                    val phrase=item.arabic.trim().split(Regex("\\s+")).size>1
                    Surface(Modifier.width(if(phrase) fullWidth else width),shape=KalimaDesign.cardShape,color=colorSurface,border=androidx.compose.foundation.BorderStroke(1.dp,colorLine)){
                        Column(Modifier.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){
                            RawText(item.arabic,Modifier.fillMaxWidth(),color=colorPrimaryLightFg,fontFamily=arabicFont,fontSize=28.sp,lineHeight=48.sp,textAlign=TextAlign.Center,style=TextStyle(textDirection=TextDirection.Rtl))
                            RawText(item.transliteration,Modifier.fillMaxWidth(),color=colorPrimaryLightFg,fontSize=16.sp,textAlign=TextAlign.Center,style=TextStyle(textDirection=TextDirection.Ltr))
                            Spacer(Modifier.height(8.dp))
                            RawText(item.meaning,Modifier.fillMaxWidth(),color=colorInk,fontFamily=translationFont(lang),fontSize=if(lang in listOf("ar","ur","fa"))20.sp else 17.sp,
                                lineHeight=if(lang=="ur")42.sp else 30.sp,textAlign=TextAlign.Center,style=TextStyle(textDirection=if(Langs.isRtl(lang))TextDirection.Rtl else TextDirection.Ltr))
                            TextButton(modifier=Modifier.springPress().heightIn(min=48.dp).semantics {contentDescription=tr("Listen")+": "+item.arabic},onClick={vm.speak(item.arabic)}){Text("Listen",color=colorPrimaryLightFg)}
                        }
                    }
                }
            }
        }
        }
        TextButton(onClick={vm.sentenceWords(true)}){Text("Refresh meanings",color=colorPrimaryLightFg)}
    } else if(!state.loading && state.error==null){
        TextButton(onClick={vm.sentenceWords()}){Text("Load word meanings",color=colorPrimaryLightFg)}
    }
}
