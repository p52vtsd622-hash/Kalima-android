package app.kalima

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.flow.first
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** One position for direct manipulation and settling; new input cancels the old job. */
internal class SpringSheetState {
    var offset by mutableFloatStateOf(0f)
    var height by mutableFloatStateOf(0f)
    var settling by mutableStateOf(false)
    var job: Job? = null
    var reduced = false
    var closing by mutableStateOf(false)
    fun drag(delta: Float): Float {
        if (closing) return 0f
        job?.cancel()
        settling = false
        val before = offset
        offset = (offset + delta).coerceIn(0f, height)
        return offset - before
    }
    suspend fun settle(target: Float, velocity: Float = 0f) {
        settling = true
        try {
            if (reduced) offset = target
            else Animatable(offset).animateTo(target, spring(dampingRatio = 1f, stiffness = 420f),
                initialVelocity = velocity) { offset = value.coerceIn(0f, height) }
        } finally { settling = false }
    }
    suspend fun hide() {
        closing = true
        job?.cancel()
        settle(height)
    }
}

@Composable
internal fun rememberSpringSheetState(): SpringSheetState = remember { SpringSheetState() }

@Composable
internal fun SpringBottomSheet(title: String, onDismissRequest: () -> Unit, sheetState: SpringSheetState,
    containerColor: Color, contentColor: Color, shape: Shape,
    dragHandle: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val reduced = rememberReducedMotion()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density
    val dismiss by rememberUpdatedState(onDismissRequest)
    sheetState.reduced = reduced
    fun close() {
        if (!sheetState.closing) scope.launch { sheetState.hide(); dismiss() }
    }
    fun release(velocity: Float) {
        if (sheetState.closing) return
        sheetState.job?.cancel()
        sheetState.job = scope.launch {
            if (sheetShouldDismiss(sheetState.offset / density, sheetState.height / density, velocity / density)) {
                sheetState.closing = true
                sheetState.settle(sheetState.height, velocity)
                dismiss()
            } else sheetState.settle(0f, velocity)
        }
    }
    val scroll = remember(sheetState) { object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
            if (source == NestedScrollSource.UserInput && available.y < 0f && sheetState.offset > 0f)
                Offset(0f, sheetState.drag(available.y)) else Offset.Zero
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
            if (source == NestedScrollSource.UserInput && available.y > 0f)
                Offset(0f, sheetState.drag(available.y)) else Offset.Zero
        override suspend fun onPreFling(available: Velocity): Velocity {
            if (sheetState.offset <= 0f) return Velocity.Zero
            release(available.y)
            return available
        }
    } }
    LaunchedEffect(sheetState) {
        snapshotFlow { sheetState.height }.first { it > 0f }
        if (!sheetState.closing) sheetState.job = scope.launch { sheetState.settle(0f) }
    }
    LaunchedEffect(reduced) {
        if (reduced && sheetState.settling) {
            sheetState.job?.cancel()
            sheetState.offset = if (sheetState.closing) sheetState.height else 0f
            if (sheetState.closing) dismiss()
        }
    }
    Dialog(onDismissRequest = { close() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f) }
        Box(Modifier.fillMaxSize().imePadding()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (sheetState.height > 0f) .32f * (1f - sheetState.offset / sheetState.height).coerceIn(0f, 1f) else 0f))
                .semantics { contentDescription = tr("Close") }.clickable(role = Role.Button, onClick = { close() }))
            Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .onSizeChanged { val first = sheetState.height == 0f; sheetState.height = it.height.toFloat(); sheetState.offset = if (first) sheetState.height else sheetState.offset.coerceIn(0f, sheetState.height) }
                .graphicsLayer { translationY = sheetState.offset; alpha = if (sheetState.height == 0f) 0f else 1f }
                .nestedScroll(scroll).semantics { paneTitle = tr(title) }, shape = shape, color = containerColor, contentColor = contentColor) {
                Column(Modifier.navigationBarsPadding()) {
                    Box(Modifier.fillMaxWidth().draggable(
                        state = rememberDraggableState { sheetState.drag(it) }, orientation = Orientation.Vertical,
                        startDragImmediately = sheetState.settling,
                        onDragStarted = { sheetState.drag(0f) }, onDragStopped = { release(it) }),
                        contentAlignment = Alignment.Center) { dragHandle() }
                    content()
                }
            }
        }
    }
}

internal fun sheetShouldDismiss(offset: Float, height: Float, velocity: Float): Boolean =
    height > 0f && (velocity > 1100f || (offset > height * .35f && velocity > -1100f))
