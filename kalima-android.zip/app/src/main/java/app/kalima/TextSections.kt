package app.kalima

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Surah names, in Quran order 1-114. Generated directly from the same list used by the tested
// web app, so the two never drift apart.
val SURAH_EN = listOf("Al-Fatihah", "Al-Baqarah", "Ali 'Imran", "An-Nisa", "Al-Ma'idah", "Al-An'am", "Al-A'raf", "Al-Anfal", "At-Tawbah", "Yunus", "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra", "Al-Kahf", "Maryam", "Ta-Ha", "Al-Anbiya", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan", "Ash-Shu'ara", "An-Naml", "Al-Qasas", "Al-'Ankabut", "Ar-Rum", "Luqman", "As-Sajdah", "Al-Ahzab", "Saba", "Fatir", "Ya-Sin", "As-Saffat", "Sad", "Az-Zumar", "Ghafir", "Fussilat", "Ash-Shura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jathiyah", "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf", "Adh-Dhariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman", "Al-Waqi'ah", "Al-Hadid", "Al-Mujadila", "Al-Hashr", "Al-Mumtahanah", "As-Saff", "Al-Jumu'ah", "Al-Munafiqun", "At-Taghabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij", "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddaththir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba", "An-Nazi'at", "'Abasa", "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Inshiqaq", "Al-Buruj", "At-Tariq", "Al-A'la", "Al-Ghashiyah", "Al-Fajr", "Al-Balad", "Ash-Shams", "Al-Layl", "Ad-Duha", "Ash-Sharh", "At-Tin", "Al-'Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-'Adiyat", "Al-Qari'ah", "At-Takathur", "Al-'Asr", "Al-Humazah", "Al-Fil", "Quraysh", "Al-Ma'un", "Al-Kawthar", "Al-Kafirun", "An-Nasr", "Al-Masad", "Al-Ikhlas", "Al-Falaq", "An-Nas")
val SURAH_AR = listOf("الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه", "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم", "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر", "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس", "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس")
val NAHJ_KIND_AR = mapOf("S" to "خطبة", "L" to "كتاب", "H" to "حكمة")

@Composable
fun TextSections(w: Word) {
    val context = LocalContext.current
    var quran by remember(w.word) { mutableStateOf<QuranCorpus?>(null) }
    var nahj by remember(w.word) { mutableStateOf<NahjCorpus?>(null) }
    var failed by remember(w.word) { mutableStateOf(false) }

    LaunchedEffect(w.word) {
        try {
            quran = Corpus.quran(context)
            nahj = Corpus.nahj(context)
        } catch (e: Exception) {
            failed = true
        }
    }

    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    if (failed) {
        Text("The Quran and Nahj al-Balagha texts couldn't be loaded. Reopen the app and look the word up again.", color = muted)
        return
    }
    val qc = quran
    val nc = nahj
    if (qc == null || nc == null) {
        Text("Searching the Quran and Nahj al-Balagha…", color = muted)
        return
    }

    val forms = remember(w.word) { collectForms(w) }

    SectionTitle("In the Quran")
    QuranResults(qc, forms)
    Spacer(Modifier.height(8.dp))
    Text(
        "Text: Tanzil Project (tanzil.net), Uthmani, version 1.1 (CC BY 3.0). The text is shown unchanged.",
        color = muted, fontSize = 12.sp
    )

    SectionDivider()
    SectionTitle("In Nahj al-Balagha")
    NahjResults(nc, forms)
    Spacer(Modifier.height(8.dp))
    Text(
        "Arabic text from the Alhassanain Network edition of Nahj al-Balagha, compiled by ash-Sharif ar-Radi. Numbering follows that edition.",
        color = muted, fontSize = 12.sp
    )
}

@Composable
fun QuranResults(c: QuranCorpus, f: FormsBundle) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val order = remember(f) {
        val ranked = KalimaSearch.rank(KalimaSearch.findMatches(c.index, f.forms, f.exact, f.verbForms, f.exactIsVerb), c.index)
        diverse(ranked) { m -> c.ref(m.u).first }
    }
    if (order.isEmpty()) {
        Text("No verse found containing this word or its forms.", color = muted)
        return
    }
    Text(
        "Found in " + order.size + " verse" + (if (order.size == 1) "" else "s") +
            ". Matches are found by spelling, so a highlighted word can occasionally be a different word with the same letters.",
        color = muted, fontSize = 14.sp
    )
    Spacer(Modifier.height(10.dp))
    var shown by remember(f) { mutableStateOf(3) }
    for (m in order.take(shown)) {
        val (surah, ayah) = c.ref(m.u)
        TextCard(
            tokens = c.index.tokens[m.u],
            hitToks = m.toks,
            refEn = SURAH_EN[surah - 1] + " " + surah + ":" + ayah,
            refAr = "سورة " + SURAH_AR[surah - 1],
            noun = "verse"
        )
    }
    if (shown < order.size) {
        TextButton(onClick = { shown = minOf(shown + 3, order.size) }, contentPadding = PaddingValues(0.dp)) {
            Text("Show more")
        }
    }
}

@Composable
fun NahjResults(c: NahjCorpus, f: FormsBundle) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val order = remember(f) {
        val ranked = KalimaSearch.rank(KalimaSearch.findMatches(c.index, f.forms, f.exact, f.verbForms, f.exactIsVerb), c.index)
        diverse(ranked) { m -> c.passages[m.u].kind + c.passages[m.u].num }
    }
    if (order.isEmpty()) {
        Text("No passage found containing this word or its forms.", color = muted)
        return
    }
    Text(
        "Found in " + order.size + " passage" + (if (order.size == 1) "" else "s") +
            ". Matches are found by spelling, so a highlighted word can occasionally be a different word with the same letters.",
        color = muted, fontSize = 14.sp
    )
    Spacer(Modifier.height(10.dp))
    var shown by remember(f) { mutableStateOf(3) }
    for (m in order.take(shown)) {
        val p = c.passages[m.u]
        val kind = c.kinds[p.kind] ?: p.kind
        TextCard(
            tokens = c.index.tokens[m.u],
            hitToks = m.toks,
            refEn = kind + " " + p.num,
            refAr = (NAHJ_KIND_AR[p.kind] ?: "") + " " + p.num,
            noun = "passage"
        )
    }
    if (shown < order.size) {
        TextButton(onClick = { shown = minOf(shown + 3, order.size) }, contentPadding = PaddingValues(0.dp)) {
            Text("Show more")
        }
    }
}

@Composable
fun TextCard(tokens: List<String>, hitToks: List<Int>, refEn: String, refAr: String, noun: String) {
    val hitSet = remember(hitToks) { hitToks.toHashSet() }
    var expanded by remember(tokens) { mutableStateOf(false) }
    val maxT = 42
    var start = 0
    var end = tokens.size
    if (tokens.size > maxT) {
        start = maxOf(0, (hitToks.firstOrNull() ?: 0) - 14)
        end = minOf(tokens.size, start + maxT)
        start = maxOf(0, end - maxT)
    }
    val showToggle = start > 0 || end < tokens.size
    val qs = if (expanded) 0 else start
    val qe = if (expanded) tokens.size else end

    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val hitColor = if (isDark) Color(0xFF4A3C10) else Color(0xFFFFEDB8)

    val quote = remember(qs, qe, expanded) {
        buildAnnotatedString {
            if (qs > 0) append("… ")
            for (i in qs until qe) {
                if (hitSet.contains(i)) {
                    withStyle(SpanStyle(background = hitColor)) { append(tokens[i]) }
                } else {
                    append(tokens[i])
                }
                append(" ")
            }
            if (qe < tokens.size) append("…")
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                quote,
                style = TextStyle(fontSize = 21.sp, lineHeight = 34.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(refEn, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    refAr,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = TextStyle(fontSize = 16.sp, textDirection = TextDirection.Rtl)
                )
            }
            if (showToggle) {
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { expanded = !expanded }, contentPadding = PaddingValues(0.dp)) {
                    Text(if (expanded) "Show less" else "Show the full " + noun, fontSize = 13.sp)
                }
            }
        }
    }
}
