package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Sends a prompt to the shared service without a passcode, or uses an optional personal key. */
object Gemini {

    suspend fun ask(prefs: Prefs, prompt: String): String {
        return if (prefs.useShared()) viaProxy(prefs, prompt) else direct(prefs, prompt)
    }

    private val requests = Executors.newFixedThreadPool(4) { runnable -> Thread(runnable, "kalima-request").apply { isDaemon = true } }

    private suspend fun post(urlStr: String, body: String, headers: Map<String, String>): Pair<Int, String> = suspendCancellableCoroutine { continuation ->
        val conn = try {
            val url = URL(urlStr)
            require(url.protocol == "https")
            url.openConnection() as HttpURLConnection
        } catch (_: Exception) {
            continuation.resumeWithException(ApiError("network"))
            return@suspendCancellableCoroutine
        }
        continuation.invokeOnCancellation { conn.disconnect() }
        requests.execute {
            try {
                if (!continuation.isActive) return@execute
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 120000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                for ((k, v) in headers) conn.setRequestProperty(k, v)
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (continuation.isActive) continuation.resume(Pair(code, text))
            } catch (_: Exception) {
                if (continuation.isActive) continuation.resumeWithException(ApiError("network"))
            } finally { conn.disconnect() }
        }
    }

    private suspend fun viaProxy(prefs: Prefs, prompt: String): String {
        val body = JSONObject().put("prompt", prompt).toString()
        val url = prefs.proxyUrl.trim().trimEnd('/')
        val result = post(url, body, emptyMap())
        val code = result.first
        val obj = parseObjectOrNull(result.second)
        if (code !in 200..299) {
            val msg = obj?.optJSONObject("error")?.optString("message", "") ?: ""
            throw ApiError("http_" + code, msg)
        }
        val text = obj?.str("text") ?: ""
        if (text.isBlank()) throw ApiError("empty")
        return text
    }

    private suspend fun direct(prefs: Prefs, prompt: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(prefs.model.trim(), "UTF-8") + ":generateContent"
        val part = JSONObject().put("text", prompt)
        val content = JSONObject().put("role", "user").put("parts", JSONArray().put(part))
        val config = JSONObject()
            .put("temperature", 0.2)
            .put("maxOutputTokens", 8192)
            .put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put("generationConfig", config)
            .toString()
        val result = post(url, body, mapOf("x-goog-api-key" to prefs.apiKey.trim()))
        val code = result.first
        val obj = parseObjectOrNull(result.second)
        if (code !in 200..299) {
            val msg = obj?.optJSONObject("error")?.optString("message", "") ?: ""
            throw ApiError("http_" + code, msg)
        }
        val sb = StringBuilder()
        val parts = obj?.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.str("text"))
            }
        }
        if (sb.isBlank()) throw ApiError("empty")
        return sb.toString()
    }

    /** Plain-English message for a problem, matching what the web app says. */
    fun friendly(e: ApiError, shared: Boolean): String {
        val c = e.code
        val m = e.detail
        if (shared) {
            if (c == "http_401" || c == "http_403") return "Shared access isn't available yet. Please contact the person who maintains Kalima, or add an optional personal Gemini key in Settings."
            if (c == "http_404") return "Kalima couldn't connect to its shared service. Try again later."
            if (c == "http_429") return "Kalima's shared allowance is used up for now. Try again later, or add an optional personal Gemini key in Settings."
            if (c.startsWith("http_5")) return "Kalima is temporarily unavailable. Try again later, or use an optional personal Gemini key in Settings."
            if (c.startsWith("http_")) return "Kalima couldn't complete this request. Try again."
        }
        if (c == "network") return "Couldn't connect. Check your internet connection and try again."
        if (c == "http_400") {
            return if (m.contains("api key", ignoreCase = true)) "Your personal Gemini key isn't valid. Check it in Settings."
            else "The request couldn't be completed. Try again, or turn off your personal key in Settings."
        }
        if (c == "http_401" || c == "http_403") return "This key can't be used here. Check it in Settings, or create a new one in AI Studio."
        if (c == "http_404") return "Your personal key couldn't complete this lookup. Turn it off in Settings to use Kalima's shared access, or restore the defaults under Advanced."
        if (c == "http_429") return "Free limit reached for now. Wait a minute and try again, or try again tomorrow."
        if (c.startsWith("http_5")) return "The service is busy right now. Try again in a moment."
        if (c == "model") return "That doesn't look like an Arabic word. " + m
        if (c == "invalid_json" || c == "empty") return "The reply couldn't be read. Try again."
        return "Kalima couldn't get an answer. Try again."
    }
}
