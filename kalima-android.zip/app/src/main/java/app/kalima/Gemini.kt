package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Sends a prompt either to the class server (passcode) or straight to Gemini (own key). Blocking: call it off the main thread. */
object Gemini {

    fun ask(prefs: Prefs, prompt: String): String {
        return if (prefs.useShared()) viaProxy(prefs, prompt) else direct(prefs, prompt)
    }

    private fun post(urlStr: String, body: String, headers: Map<String, String>): Pair<Int, String> {
        val conn = try {
            URL(urlStr).openConnection() as HttpURLConnection
        } catch (e: IOException) {
            throw ApiError("network")
        }
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } catch (e: IOException) {
            throw ApiError("network")
        } finally {
            conn.disconnect()
        }
    }

    private fun viaProxy(prefs: Prefs, prompt: String): String {
        val body = JSONObject().put("prompt", prompt).toString()
        val url = prefs.proxyUrl.trim().trimEnd('/')
        val result = post(url, body, mapOf("X-Passcode" to prefs.passcode.trim()))
        val code = result.first
        val obj = parseObjectOrNull(result.second)
        if (code !in 200..299) {
            val msg = obj?.optJSONObject("error")?.optString("message", "") ?: ""
            throw ApiError("http_" + code, msg)
        }
        val text = obj?.str("text") ?: ""
        if (text.isBlank()) throw ApiError("empty")
        return text
    }

    private fun direct(prefs: Prefs, prompt: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(prefs.model.trim(), "UTF-8") + ":generateContent"
        val part = JSONObject().put("text", prompt)
        val content = JSONObject().put("role", "user").put("parts", JSONArray().put(part))
        val config = JSONObject()
            .put("temperature", 0.2)
            .put("maxOutputTokens", 8192)
            .put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put("generationConfig", config)
            .toString()
        val result = post(url, body, mapOf("x-goog-api-key" to prefs.apiKey.trim()))
        val code = result.first
        val obj = parseObjectOrNull(result.second)
        if (code !in 200..299) {
            val msg = obj?.optJSONObject("error")?.optString("message", "") ?: ""
            throw ApiError("http_" + code, msg)
        }
        val sb = StringBuilder()
        val parts = obj?.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.str("text"))
            }
        }
        if (sb.isBlank()) throw ApiError("empty")
        return sb.toString()
    }

    /** Plain-English message for a problem, matching what the web app says. */
    fun friendly(e: ApiError, shared: Boolean): String {
        val c = e.code
        val m = e.detail
        if (shared) {
            if (c == "http_401") return "That passcode isn't right. Check it in Settings."
            if (c == "http_404") return "The class server wasn't found. Check its address in Settings."
            if (c == "http_429") return "The shared free limit is used up for now. Try again in a few minutes."
            if (c == "http_500") return "The class server isn't set up correctly. Tell whoever runs it."
            if (c == "http_502") return "The class server couldn't get an answer from Gemini. " + m
        }
        if (c == "network") return "Couldn't connect. Check your internet connection and try again."
        if (c == "http_400") {
            return if (m.contains("api key", ignoreCase = true)) "Gemini says the key isn't valid. Check it in Settings."
            else "Gemini rejected the request. " + m
        }
        if (c == "http_401" || c == "http_403") return "This key can't be used here. Check it in Settings, or create a new one in AI Studio."
        if (c == "http_404") return "Gemini doesn't know that model name. Set it to gemini-2.5-flash in Settings."
        if (c == "http_429") return "Free limit reached for now. Wait a minute and try again, or try again tomorrow."
        if (c.startsWith("http_5")) return "Gemini is busy right now. Try again in a moment."
        if (c == "model") return "That doesn't look like an Arabic word. " + m
        if (c == "invalid_json" || c == "empty") return "The reply couldn't be read. Try again."
        return "Something went wrong reaching Gemini. Try again."
    }
}
