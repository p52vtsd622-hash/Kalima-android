package app.kalima

import app.kalima.LocalizedIcon as Icon

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import android.provider.Settings
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.input.pointer.RequestDisallowInterceptTouchEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/** Native version of the supplied HTML lens, not a WebView or a screen blur. */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun LiquidGlassNavigation(currentTab: String, onSelect: (String) -> Unit) {
    val tabs = listOf(
        Triple("lookup", Icons_DadBubble, "Lookup"),
        Triple("saved", Icons_BrainProfile, "Saved Words"),
        Triple("practice", Icons_GradCap, "Practice"),
        Triple("settings", Icons_SettingsGear, "Settings")
    )
    val selectedIndex = tabs.indexOfFirst { it.first == currentTab }.coerceAtLeast(0)
    val select by rememberUpdatedState(onSelect)
    val density = LocalDensity.current
    val context = LocalContext.current
    // Honour Android's system-wide animation-off setting.
    // Also update when the setting changes while Kalima is open.
    var reducedMotion by remember(context) { mutableStateOf(Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) }
    var highContrast by remember(context) { mutableStateOf(Settings.Secure.getInt(context.contentResolver, "high_text_contrast_enabled", 0) == 1) }
    DisposableEffect(context) {
        fun updatePreferences() {
            reducedMotion = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
            highContrast = Settings.Secure.getInt(context.contentResolver, "high_text_contrast_enabled", 0) == 1
        }
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) = updatePreferences()
        }
        updatePreferences()
        context.contentResolver.registerContentObserver(Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE), false, observer)
        context.contentResolver.registerContentObserver(Settings.Secure.getUriFor("high_text_contrast_enabled"), false, observer)
        onDispose { context.contentResolver.unregisterContentObserver(observer) }
    }
    val motion = rememberGlassMotion(selectedIndex.toFloat(), reducedMotion)
    val press = animateFloatAsState(if (motion.dragging && !reducedMotion && !highContrast) 1f else 0f,
        animationSpec = tween(if (reducedMotion) 0 else 110), label = "Glass contact")
    // Smooth only the decorative deformation. Position always tracks the finger directly.
    val energy = animateFloatAsState(
        if (reducedMotion || highContrast) 0f else (abs(motion.velocity) / 12f).coerceIn(0f, 1f),
        animationSpec = tween(if (reducedMotion) 0 else 90), label = "Glass stretch")
    val activeInk = if (isDark) colorAccentFg else colorNavFg

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier.fillMaxWidth()
                .shadow(4.dp, RoundedCornerShape(50), spotColor = Color.Black.copy(alpha = 0.05f))
                .clip(RoundedCornerShape(50))
                .background(colorNavBg)
                .border(1.dp, colorLine, RoundedCornerShape(50))
        ) {
            val pad = with(density) { 10.dp.toPx() }
            val gap = with(density) { 6.dp.toPx() }
            val widthPx = with(density) { maxWidth.toPx() }
            val itemWidth = ((widthPx - 2 * pad - 3 * gap) / 4).coerceAtLeast(1f)
            val stride = itemWidth + gap
            val firstCenter = pad + itemWidth / 2
            val preventInterception = remember { RequestDisallowInterceptTouchEvent() }
            var activePointer by remember { mutableIntStateOf(-1) }
            var downX by remember { mutableFloatStateOf(0f) }
            var grabOffset by remember { mutableFloatStateOf(0f) }
            var didDrag by remember { mutableStateOf(false) }
            val dragThreshold = with(density) { 3.dp.toPx() }
            val bg = colorAccent

            Canvas(Modifier.matchParentSize()) {
                val position = motion.position
                val velocity = motion.velocity
                val energy = energy.value
                val contact = press.value
                val height = 46.dp.toPx()
                val top = 7.dp.toPx()
                val stretch = 1f + energy * 0.10f + contact * 0.025f
                val lensWidth = itemWidth * stretch
                val lensHeight = height * (1f - energy * 0.064f)
                val centerX = firstCenter + position.coerceIn(0f, 3f) * stride
                val lensTop = top + (height - lensHeight) / 2
                val corner = CornerRadius(lensHeight / 2)
                val origin = Offset(centerX - lensWidth / 2, lensTop)
                val lensSize = Size(lensWidth, lensHeight)
                if (!highContrast && !reducedMotion && contact > 0.001f) {
                    drawRoundRect(Color.Black.copy(alpha = .055f * contact),
                        origin + Offset(0f, 2.dp.toPx()), lensSize, corner)
                }
                drawRoundRect(bg, origin, lensSize, corner)
                if (!highContrast && !reducedMotion) {
                    drawRoundRect(Brush.verticalGradient(listOf(
                        Color.White.copy(alpha = .08f + contact * .1f), Color.Transparent),
                        startY = lensTop, endY = lensTop + lensHeight * .48f),
                        origin, lensSize, corner, style = Stroke(.75.dp.toPx()))
                }
                if (!highContrast && !reducedMotion) drawRoundRect(
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.16f + energy * 0.10f), Color.Transparent,
                            Color.Black.copy(alpha = 0.035f), Color.White.copy(alpha = 0.08f)),
                        origin, origin + Offset(lensWidth, lensHeight)
                    ), origin, lensSize, corner
                )
                val shineX = centerX + velocity.coerceIn(-10f, 10f) * stride * 0.06f
                if (!highContrast && !reducedMotion) drawRoundRect(
                    Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.07f + energy * 0.09f), Color.Transparent),
                        Offset(shineX - lensWidth * 0.65f, lensTop), Offset(shineX + lensWidth * 0.65f, lensTop + lensHeight)),
                    origin, lensSize, corner
                )
                drawRoundRect((if (highContrast) activeInk else Color.White).copy(alpha = if (highContrast) 0.6f else 0.22f + contact * 0.12f),
                    origin, lensSize, corner, style = Stroke(1.dp.toPx()))
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp).selectableGroup(),
                horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { index, (tabId, icon, description) ->
                    Box(
                        Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(50))
                            .semantics { selected = currentTab == tabId }
                            .clickable(role = Role.Tab) { select(tabId) },
                        contentAlignment = Alignment.Center
                    ) {
                        // Two inks are clipped at the moving lens edge, rather than fading
                        // the entire icon when a finger crosses an arbitrary slot boundary.
                        GlassTabArtwork(icon, tabId == "lookup", colorNavFg, colorPaper, description, Modifier.matchParentSize())
                        GlassTabArtwork(icon, tabId == "lookup", activeInk, bg, null, Modifier.matchParentSize().clearAndSetSemantics {}.drawWithContent {
                            val lensWidth = itemWidth * (1f + energy.value * 0.10f + press.value * 0.025f)
                            val lensHeight = 46.dp.toPx() * (1f - energy.value * 0.064f)
                            val center = itemWidth / 2 + (motion.position.coerceIn(0f, 3f) - index) * stride
                            val path = Path().apply { addRoundRect(RoundRect(
                                center - lensWidth / 2, (size.height - lensHeight) / 2,
                                center + lensWidth / 2, (size.height + lensHeight) / 2,
                                CornerRadius(lensHeight / 2))) }
                            clipPath(path) { this@drawWithContent.drawContent() }
                        })
                    }
                }
            }
            // Topmost hit surface owns the complete Android gesture, including icon areas.
            // Underlying tab click semantics remain available to accessibility services.
            Box(Modifier.matchParentSize().pointerInteropFilter(
                requestDisallowInterceptTouchEvent = preventInterception
            ) { event ->
                fun slot(index: Int) = (event.getX(index) - firstCenter) / stride
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        activePointer = event.getPointerId(0)
                        downX = event.getX(0)
                        didDrag = false
                        // Grabbing the lens off-centre must not teleport it on touch-down.
                        grabOffset = if (abs(slot(0) - motion.position) <= 0.5f) motion.position - slot(0) else 0f
                        motion.beginDrag(event.eventTime)
                        preventInterception(true)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val index = event.findPointerIndex(activePointer)
                        if (index >= 0) {
                            if (abs(event.getX(index) - downX) > dragThreshold) didDrag = true
                            if (didDrag) motion.dragTo(slot(index) + grabOffset, event.eventTime)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val index = event.findPointerIndex(activePointer)
                        if (index >= 0) {
                            if (didDrag) motion.dragTo(slot(index) + grabOffset, event.eventTime)
                            select(tabs[GlassSpring.nearest(if (didDrag) motion.position else slot(index))].first)
                        }
                        motion.endDrag()
                        activePointer = -1
                        preventInterception(false)
                        true
                    }
                    MotionEvent.ACTION_POINTER_UP -> {
                        if (event.getPointerId(event.actionIndex) == activePointer) {
                            val next = if (event.actionIndex == 0) 1 else 0
                            activePointer = event.getPointerId(next)
                            downX = event.getX(next)
                            grabOffset = motion.position - slot(next)
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        motion.endDrag()
                        activePointer = -1
                        preventInterception(false)
                        true
                    }
                    else -> activePointer >= 0
                }
            })
        }
    }
}

@Composable
private fun GlassTabArtwork(icon: ImageVector, lookup: Boolean, ink: Color, letter: Color, label: String?, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, Modifier.size(if (lookup) 26.dp else 24.dp), tint = ink)
        if (lookup) Text("ض", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = arabicFont,
            color = letter, modifier = Modifier.offset(y = (-1).dp))
    }
}
