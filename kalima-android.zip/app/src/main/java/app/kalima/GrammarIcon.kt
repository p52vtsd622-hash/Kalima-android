package app.kalima
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Native vector uses exactly the paths in design-assets/grammar.svg. */
internal val Icons_SentenceGrammar = ImageVector.Builder("Sentence grammar", 24.dp, 24.dp, 24f, 24f).apply {
    path(fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 1.8f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
        moveTo(3f,4f); lineTo(7f,4f); lineTo(7f,9f); lineTo(3f,9f); close()
        moveTo(10f,4f); lineTo(14f,4f); lineTo(14f,9f); lineTo(10f,9f); close()
        moveTo(17f,4f); lineTo(21f,4f); lineTo(21f,9f); lineTo(17f,9f); close()
        moveTo(5f,9f); lineTo(5f,14f); lineTo(19f,14f); lineTo(19f,9f)
        moveTo(12f,9f); lineTo(12f,18f)
        moveTo(8f,18f); lineTo(16f,18f); lineTo(16f,22f); lineTo(8f,22f); close()
    }
}.build()
