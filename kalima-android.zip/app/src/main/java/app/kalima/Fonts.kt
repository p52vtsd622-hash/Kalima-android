package app.kalima

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val arabicFont = FontFamily(Font(R.font.amiri_regular), Font(R.font.amiri_bold, FontWeight.Bold))
val quranFont = FontFamily(Font(R.font.amiri_quran))
val latinFont = FontFamily(Font(R.font.instrument_sans), Font(R.font.instrument_sans_medium, FontWeight.Medium), Font(R.font.instrument_sans_semibold, FontWeight.SemiBold))
val urduFont = FontFamily(Font(R.font.noto_nastaliq_urdu), Font(R.font.noto_nastaliq_urdu_semibold, FontWeight.SemiBold))
val persianFont = FontFamily(Font(R.font.vazirmatn), Font(R.font.vazirmatn_medium, FontWeight.Medium))
fun translationFont(lang: String) = when (lang) { "ur" -> urduFont; "fa" -> persianFont; else -> latinFont }
