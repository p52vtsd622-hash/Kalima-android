package app.kalima

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** How many days to wait before the next review, indexed by box (0 = just added or just missed). */
val SPACED_INTERVALS_DAYS = intArrayOf(0, 1, 3, 7, 14, 30)

/** Saved words on this phone: each is the exact word-lookup result, plus simple spaced-repetition state. */
class SavedStore(context: Context) {
    private val sp = context.getSharedPreferences("kalima_saved", Context.MODE_PRIVATE)

    fun load(): List<JSONObject> {
        val raw = sp.getString("list", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<JSONObject>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i)
                if (o != null) out.add(o)
            }
            out.sortedByDescending { it.optLong("addedAt", 0L) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<JSONObject>) {
        val arr = JSONArray()
        for (o in list) arr.put(o)
        sp.edit().putString("list", arr.toString()).apply()
    }
}

/** Marks a review as correct or not, and returns the same entry with box/due updated (same rule as the web app). */
fun gradeEntry(entry: JSONObject, correct: Boolean): JSONObject {
    val updated = JSONObject(entry.toString())
    val now = System.currentTimeMillis()
    if (correct) {
        val box = (entry.optInt("box", 0) + 1).coerceAtMost(SPACED_INTERVALS_DAYS.size - 1)
        updated.put("box", box)
        updated.put("due", now + SPACED_INTERVALS_DAYS[box] * 86_400_000L)
    } else {
        updated.put("box", 0)
        updated.put("due", now)
    }
    return updated
}

fun isDue(entry: JSONObject, now: Long): Boolean = entry.optLong("due", 0L) <= now
