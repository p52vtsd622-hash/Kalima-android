package app.kalima

object Config {
    // Shared service address. Configuration is available only under Advanced.
    const val DEFAULT_PROXY = "https://kalima.wyp44cctp8.workers.dev"
    const val DEFAULT_MODEL = "gemini-2.5-flash"
}

object Langs {
    val names = linkedMapOf("en" to "English", "ar" to "Arabic", "ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "fr" to "French")
    val nativeNames = mapOf("en" to "English", "ar" to "العربية", "ur" to "اردو", "fa" to "فارسی", "tr" to "Türkçe", "ru" to "Русский", "fr" to "Français")
    val promptDesc = mapOf("en" to "English", "ar" to "fully vocalized Modern Standard Arabic", "ur" to "natural Urdu in Urdu script", "fa" to "natural Iranian Persian in Persian script", "tr" to "standard Turkish", "ru" to "standard Russian", "fr" to "standard French")
    fun isRtl(lang: String) = Localization.isRtl(lang)
}
