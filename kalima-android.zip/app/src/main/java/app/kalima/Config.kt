package app.kalima

object Config {
    // Address of your class server (the Cloudflare Worker). You can change it in Settings.
    const val DEFAULT_PROXY = "https://kalima.wyp44cctp8.workers.dev"
    const val DEFAULT_MODEL = "gemini-2.5-flash"
}

object Langs {
    val names = mapOf("ur" to "Urdu", "fa" to "Persian (Farsi)", "tr" to "Turkish", "ru" to "Russian")
    val nativeNames = mapOf("ur" to "اردو", "fa" to "فارسی", "tr" to "Türkçe", "ru" to "Русский")
    val promptDesc = mapOf(
        "ur" to "Urdu written in Urdu script",
        "fa" to "Persian (Farsi) written in Persian script, in natural modern Iranian Persian",
        "tr" to "standard Turkish written in Latin letters",
        "ru" to "standard Russian written in Cyrillic script"
    )

    fun isRtl(lang: String): Boolean = lang == "ur" || lang == "fa"
}
