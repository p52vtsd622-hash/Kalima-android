package app.kalima

import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import org.json.JSONObject

/** Bundled, offline gettext-style catalogs. Source messages remain stable identifiers. */
object Localization {
    // Android uses ICU: both literal braces must be escaped, unlike OpenJDK.
    private const val PLACEHOLDER_PATTERN = "\\{[0-9]+\\}"
    val appLanguages = listOf("en", "ar", "ur", "fa", "tr", "ru", "fr")
    private var catalogs: Map<String, Map<String, String>> = emptyMap()
    private var templates: Map<String, List<Pair<Regex, String>>> = emptyMap()
    fun initialize(context: Context) {
        if (catalogs.isNotEmpty()) return
        loadCatalog(context.assets.open("ui-translations.json").bufferedReader().use { it.readText() })
    }
    fun loadCatalog(text: String) {
        val json = JSONObject(text)
        catalogs = appLanguages.associateWith { lang ->
            val o = json.optJSONObject(lang) ?: JSONObject()
            o.keys().asSequence().associateWith { o.getString(it) }
        }
        templates = catalogs.mapValues { (_, table) -> table.filterKeys { it.contains("{0}") }.map { (key, translated) ->
            val parts = key.split(Regex(PLACEHOLDER_PATTERN))
            Regex("^" + parts.joinToString("(.*?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to translated
        } }
    }
    fun extraLanguages(app: String) = appLanguages.filter { it != "ar" && it != app }
    fun isRtl(lang: String) = lang in listOf("ar", "ur", "fa")
    fun text(source: String, language: String): String {
        if (language == "en" || source.isBlank()) return source
        val table = catalogs[language].orEmpty()
        table[source]?.let { return it }
        // Message templates use {0}, {1}... so translators can reorder values.
        for ((pattern, translated) in templates[language].orEmpty()) {
            val match = pattern.matchEntire(source) ?: continue
            var result = translated
            match.groupValues.drop(1).forEachIndexed { index, value ->
                result = result.replace("{$index}", table[value] ?: value)
            }
            return result
        }
        return source // Content/proper names are not machine-translated by a UI catalog.
    }
}
fun tr(source: String): String = Localization.text(source, appPrefs?.appLanguage ?: "en")
fun trOrNull(source: String?): String? = source?.let(::tr)

@Composable
fun LocalizedText(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified, fontStyle: FontStyle? = null, fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null, letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null, textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified, overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true, maxLines: Int = Int.MAX_VALUE, minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null, style: TextStyle = LocalTextStyle.current) {
    val language = appPrefs?.appLanguage ?: "en"
    val translated = Localization.text(text, language)
    val size = if (fontSize != TextUnit.Unspecified) fontSize else style.fontSize.takeIf { it != TextUnit.Unspecified } ?: 16.sp
    val height = if (lineHeight != TextUnit.Unspecified) lineHeight else if (Localization.isRtl(language)) (size.value * if (language == "ur") 2f else 1.6f).sp else TextUnit.Unspecified
    androidx.compose.material3.Text(translated, modifier, color, fontSize, fontStyle, fontWeight,
        fontFamily ?: style.fontFamily?.takeIf { it != latinFont } ?: translationFont(language), letterSpacing, textDecoration, textAlign, height, overflow,
        softWrap, maxLines, minLines, onTextLayout = onTextLayout, style = style)
}

@Composable
fun LocalizedText(text: AnnotatedString, modifier: Modifier = Modifier, color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified, fontStyle: FontStyle? = null, fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null, letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null, textAlign: TextAlign? = null, lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip, softWrap: Boolean = true, maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1, onTextLayout: (TextLayoutResult) -> Unit = {}, style: TextStyle = LocalTextStyle.current) {
    androidx.compose.material3.Text(text, modifier, color, fontSize, fontStyle, fontWeight, fontFamily,
        letterSpacing, textDecoration, textAlign, lineHeight, overflow, softWrap, maxLines, minLines, onTextLayout = onTextLayout, style = style)
}

@Composable
fun LocalizedIcon(imageVector: ImageVector, contentDescription: String?, modifier: Modifier = Modifier,
    tint: Color = androidx.compose.material3.LocalContentColor.current) {
    androidx.compose.material3.Icon(imageVector, trOrNull(contentDescription), modifier, tint)
}
