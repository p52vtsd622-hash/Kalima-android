package app.kalima

import app.kalima.LocalizedText as Text
import app.kalima.LocalizedIcon as Icon
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private const val CENTER_PAGE = Int.MAX_VALUE / 2

@Composable
internal fun SuggestedWordCard(vm: MainViewModel) {
    key(vm.suggestionEpoch) {
        val pager = rememberPagerState(initialPage = (CENTER_PAGE.toLong() + vm.suggestionPosition).coerceIn(0, Int.MAX_VALUE.toLong() - 1).toInt(), pageCount = { Int.MAX_VALUE })
        LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { vm.suggestionShown(it - CENTER_PAGE) } }
        val scope = rememberCoroutineScope()
        val reduced = rememberReducedMotion()
        val visibleWord = vm.suggestionAt(pager.currentPage - CENTER_PAGE)
        fun study(word: String) { vm.query = word; vm.searchMode = "ar"; vm.lookup() }
        fun move(delta: Int) {
            scope.launch {
                val destination = (pager.currentPage.toLong() + delta).coerceIn(0, Int.MAX_VALUE.toLong() - 1).toInt()
                if (reduced) pager.scrollToPage(destination) else pager.animateScrollToPage(destination)
            }
        }
        Column(Modifier.fillMaxWidth().clip(KalimaDesign.cardShape).background(colorSuggestBg).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Suggested word", color = colorPrimaryLightFg, fontSize = 14.sp)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                HorizontalPager(state = pager, modifier = Modifier.fillMaxWidth(), key = { it }) { page ->
                    val word = vm.suggestionAt(page - CENTER_PAGE)
                    Column(Modifier.fillMaxWidth().clickable(role = Role.Button, onClickLabel = tr("Study word")) { study(word.arabic) }
                        .padding(horizontal = 20.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        RawText(word.arabic, Modifier.fillMaxWidth(), color = colorSuggestInk, fontSize = 64.sp, lineHeight = 108.sp,
                            fontWeight = FontWeight.Bold, fontFamily = arabicFont, textAlign = TextAlign.Center,
                            style = TextStyle(textDirection = TextDirection.Rtl))
                        Text(word.kind, color = colorPrimaryLightFg, fontSize = 14.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = { move(-1) }, modifier = Modifier.size(48.dp)) {
                        Icon(HomePreviousIcon, "Previous suggestion", tint = colorSuggestInk, modifier = Modifier.size(24.dp))
                    }
                    IconButton(onClick = { vm.speak(visibleWord.arabic) }, modifier = Modifier.size(48.dp)) {
                        Icon(HomeListenIcon, "Listen", tint = colorSuggestInk, modifier = Modifier.size(24.dp))
                    }
                    Button(onClick = { study(visibleWord.arabic) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colorPrimaryLightFg, contentColor = if (isDark) colorSurface else androidx.compose.ui.graphics.Color.White)) {
                        Text("Study word", fontSize = 14.sp)
                    }
                    IconButton(onClick = { move(1) }, modifier = Modifier.size(48.dp)) {
                        Icon(HomePreviousIcon, "Next suggestion", tint = colorSuggestInk, modifier = Modifier.size(24.dp).rotate(180f))
                    }
                }
            }
        }
    }
}
