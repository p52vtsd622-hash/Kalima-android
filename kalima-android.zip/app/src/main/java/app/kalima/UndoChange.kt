package app.kalima

import org.json.JSONObject

/** Session undo snapshots are independent of mutable cached dictionary data. */
internal sealed class UndoChange {
    class Saved(entry: JSONObject) : UndoChange() {
        private val snapshot = entry.toString()
        val word: String = entry.str("id")
        fun restore(current: List<JSONObject>): List<JSONObject> {
            // A word re-saved or reviewed after removal is newer than this snapshot.
            if (current.any { it.str("id") == word }) return current
            return (current + JSONObject(snapshot)).sortedByDescending { it.optLong("addedAt") }
        }
    }
    class History(words: List<String>) : UndoChange() {
        private val snapshot = words.toList()
        fun restore(current: List<String>): List<String> = (current + snapshot).distinct().take(8)
    }
}
