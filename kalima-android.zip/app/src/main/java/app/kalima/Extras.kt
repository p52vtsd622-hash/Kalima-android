package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CandidateCard(item: Gloss, lang: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(onClick = onClick),
        shape = KalimaDesign.cardShape, border = BorderStroke(1.dp, colorLine),
        colors = CardDefaults.cardColors(containerColor = colorSurface)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) {
                if (item.transliteration.isNotBlank() && (appPrefs?.appLanguage ?: "en") != "ar") Text(item.transliteration, fontSize = 16.sp, color = colorInk)
                if (item.partOfSpeech.isNotBlank()) Text(item.partOfSpeech, fontSize = 13.sp, color = colorMuted)
                if (item.wazn.isNotBlank()) ArabicText(item.wazn, 20)
                ReadingText(item.en)
                TxLine(item.tx, lang)
            }
            ArabicText(item.ar, 34, Modifier.widthIn(max = 150.dp))
        }
    }
}

@Composable
fun RootWordsSection(vm: MainViewModel) {
    Spacer(Modifier.height(14.dp))
    OutlinedButton(onClick = { vm.toggleRootWords() },
        shape = KalimaDesign.controlShape, border = BorderStroke(1.dp, colorLine)) {
        Text(if (vm.rootExpanded) "Hide words from this root" else "Words from this root", color = colorPrimary)
    }
    SmoothSectionVisibility(vm.rootExpanded) {
        Column(Modifier.fillMaxWidth()) {
            SectionRequestFeedback(vm.rootLoading, vm.rootError, "Finding words from this root…", { vm.retryRootWords() })
            val words = vm.rootWords.orEmpty()
            if (!vm.rootLoading && vm.rootError == null && words.isEmpty()) Text("No other common words found.", color = colorMuted)
            words.forEach { CandidateCard(it, vm.prefs.lang) { vm.openWord(it.ar) } }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TranslationBanner(vm: MainViewModel) {
    if (vm.hasLegacyTranslation) {
        Card(Modifier.fillMaxWidth(), shape = KalimaDesign.cardShape, border = BorderStroke(1.dp, colorLine), colors = CardDefaults.cardColors(containerColor = colorSurface)) {
            Column(Modifier.padding(KalimaDesign.cardInset)) {
                Text("This older Android word has a translation with no language label. Which language is it?", color = colorMuted, fontSize = 14.sp)
                Text(vm.legacyMeaning, color = colorInk)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Langs.names.forEach { (code, name) -> TextButton(onClick = { vm.assignLegacyLanguage(code) }) { Text(name) } }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
    if (!vm.hasTranslation) {
        Card(Modifier.fillMaxWidth(), shape = KalimaDesign.cardShape, border = BorderStroke(1.dp, colorLine), colors = CardDefaults.cardColors(containerColor = colorSurface)) {
            Column(Modifier.padding(KalimaDesign.cardInset)) {
                val name = vm.missingLanguages.joinToString(", ") { tr(Langs.names[it] ?: it) }
                Text("Download the $name explanation for this word.", color = colorMuted, fontSize = 15.sp)
                SectionRequestFeedback(vm.translationLoading, vm.translationError, "Adding the $name explanation…", { vm.addTranslation() })
                if (!vm.translationLoading && vm.translationError == null) TextButton(onClick = { vm.addTranslation() }) {
                    Text("Download $name", color = colorPrimary)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HistoryScreen(vm: MainViewModel) {
    val reduced = rememberReducedMotion()
    val motion = LocalWordMotion.current
    var previewWord by remember { mutableStateOf<String?>(null) }
    previewWord?.let { arabic ->
        val entry = vm.savedEntries.firstOrNull { it.str("id") == arabic }
        val word = entry?.optJSONObject("data")?.let { Word.fromJson(it, vm.prefs.lang, vm.prefs.appLanguage) } ?: vm.result?.takeIf { it.word == arabic }
        WordPreview(arabic, word, vm, onStudy = {
            if (motion != null && entry != null) motion.open("history", arabic, animate = false) { vm.openWord(arabic) } else vm.openWord(arabic)
        }, onDismiss = { previewWord = null }, onRemove = if (entry != null) ({ vm.removeSaved(entry.str("id")) }) else null)
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (vm.recentWords.isEmpty()) item { Text("Your recent searches will appear here.", color = colorMuted) }
        items(vm.recentWords.toList(), key = { it }) { word ->
            val movement = if (reduced) Modifier else Modifier.animateItem(
                fadeInSpec = tween(140), placementSpec = spring(dampingRatio = .86f, stiffness = 420f), fadeOutSpec = tween(100))
            Surface(movement.fillMaxWidth(), shape = KalimaDesign.cardShape,
                border = BorderStroke(1.dp, colorLine), color = colorSurface) {
                Column(Modifier.fillMaxWidth().combinedClickable(role = Role.Button, onClickLabel = tr("Study word"),
                    onLongClickLabel = tr("Preview word"), onLongClick = { previewWord = word }, onClick = {
                        if (motion != null && vm.isSaved(word)) motion.open("history", word) { vm.openWord(word) } else vm.openWord(word)
                    })
                    .padding(16.dp)) {
                    MovingWord(word, "history:$word", 34, 54, Modifier.align(androidx.compose.ui.AbsoluteAlignment.Right), androidx.compose.ui.text.style.TextAlign.Right)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Study word", color = colorPrimaryLightFg, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { previewWord = word }, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Preview") }
                    }
                }
            }
        }
        if (vm.recentWords.isNotEmpty()) item {
            TextButton(onClick = { vm.clearHistory() }, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) {
                Text("Clear recent searches")
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
