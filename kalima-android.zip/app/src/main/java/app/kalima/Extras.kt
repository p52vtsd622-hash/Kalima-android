package app.kalima

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CandidateCard(item: Gloss, lang: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, colorLine),
        colors = CardDefaults.cardColors(containerColor = colorSurface)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) {
                if (item.transliteration.isNotBlank()) Text(item.transliteration, fontSize = 16.sp, color = colorInk)
                if (item.partOfSpeech.isNotBlank()) Text(item.partOfSpeech, fontSize = 13.sp, color = colorMuted)
                if (item.wazn.isNotBlank()) ArabicText(item.wazn, 20)
                Text(item.en, fontSize = 17.sp, color = colorInk)
                TxLine(item.tx, lang)
            }
            ArabicText(item.ar, 34, Modifier.widthIn(max = 150.dp))
        }
    }
}

@Composable
fun RootWordsSection(vm: MainViewModel) {
    Spacer(Modifier.height(14.dp))
    OutlinedButton(onClick = { vm.toggleRootWords() }, enabled = !vm.rootLoading,
        shape = RoundedCornerShape(12.dp), border = BorderStroke(1.5.dp, colorLine)) {
        Text(if (vm.rootLoading) "Loading…" else if (vm.rootExpanded) "Hide words from this root" else "Words from this root", color = colorPrimary)
    }
    if (vm.rootExpanded) {
        Spacer(Modifier.height(12.dp))
        val words = vm.rootWords.orEmpty()
        if (words.isEmpty()) Text("No other common words found.", color = colorMuted)
        words.forEach { CandidateCard(it, vm.prefs.lang) { vm.openWord(it.ar) } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TranslationBanner(vm: MainViewModel) {
    if (vm.hasLegacyTranslation) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, colorLine), colors = CardDefaults.cardColors(containerColor = colorSurface)) {
            Column(Modifier.padding(14.dp)) {
                Text("This older Android word has a translation with no language label. Which language is it?", color = colorMuted, fontSize = 14.sp)
                Text(vm.legacyMeaning, color = colorInk)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Langs.names.forEach { (code, name) -> TextButton(onClick = { vm.assignLegacyLanguage(code) }) { Text(name) } }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
    if (vm.prefs.lang != "off" && !vm.hasTranslation) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, colorLine), colors = CardDefaults.cardColors(containerColor = colorSurface)) {
            Column(Modifier.padding(14.dp)) {
                val name = Langs.names[vm.prefs.lang] ?: "selected language"
                Text("Some $name translations are missing for this word.", color = colorMuted, fontSize = 15.sp)
                TextButton(onClick = { vm.addTranslation() }, enabled = !vm.translationLoading) {
                    Text(if (vm.translationLoading) "Translating…" else "Add $name translation", color = colorPrimary)
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        if (vm.recentWords.isEmpty()) Text("Your recent searches will appear here.", color = colorMuted)
        vm.recentWords.forEach { word ->
            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { vm.openWord(word) },
                shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, colorLine), colors = CardDefaults.cardColors(containerColor = colorSurface)) {
                ArabicText(word, 34, Modifier.fillMaxWidth().padding(16.dp))
            }
        }
        if (vm.recentWords.isNotEmpty()) TextButton(onClick = { vm.clearHistory() }) { Text("Clear recent searches") }
        Spacer(Modifier.height(24.dp))
    }
}
