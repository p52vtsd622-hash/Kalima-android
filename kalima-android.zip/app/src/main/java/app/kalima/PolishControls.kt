package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DisclosureVector = ImageVector.Builder("Disclosure chevron", 24.dp, 24.dp, 24f, 24f).apply {
    path(fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 2.25f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
        moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f)
    }
}.build()

/** The surrounding labeled row owns the full touch target and expanded semantics. */
@Composable
internal fun DisclosureChevron(expanded: Boolean) {
    val reduced = rememberReducedMotion()
    val rotation by animateFloatAsState(if (expanded) 180f else 0f,
        if (reduced) tween(0) else spring(dampingRatio = .86f, stiffness = 500f), label = "Disclosure chevron")
    Box(Modifier.size(40.dp).background(colorPrimaryLight, CircleShape).clearAndSetSemantics {}, contentAlignment = Alignment.Center) {
        Icon(DisclosureVector, null, Modifier.size(22.dp).rotate(rotation), tint = colorPrimaryLightFg)
    }
}

@Composable
internal fun SpringChoiceIndicator(selected: Boolean) {
    val reduced = rememberReducedMotion()
    val scale by animateFloatAsState(if (selected) 1f else .88f,
        if (reduced) tween(0) else spring(dampingRatio = .65f, stiffness = 450f), label = "Language selection")
    RadioButton(selected, onClick = null,
        modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clearAndSetSemantics {},
        colors = RadioButtonDefaults.colors(selectedColor = colorPrimaryLightFg))
}

/** Move a complete translated label, preserving RTL order and script shaping. */
@Composable
internal fun PracticeCounter(text: String, size: Int = 14) {
    val reduced = rememberReducedMotion()
    if (reduced) Text(text, color = colorPrimaryLightFg, fontSize = size.sp)
    else AnimatedContent(text,
        modifier = Modifier.padding(vertical = 2.dp).clearAndSetSemantics { contentDescription = tr(text) },
        transitionSpec = {
            (fadeIn(tween(140)) + slideInVertically(tween(140)) { it / 5 }) togetherWith
                (fadeOut(tween(90)) + slideOutVertically(tween(90)) { -it / 5 }) using SizeTransform(clip = false)
        }, label = "Practice count") { value -> Text(value, color = colorPrimaryLightFg, fontSize = size.sp) }
}

@Composable
internal fun PracticeProgress(completed: Int, total: Int) {
    val reduced = rememberReducedMotion()
    val actual = if (total > 0) (completed.toFloat() / total).coerceIn(0f, 1f) else 0f
    val displayed by animateFloatAsState(actual, if (reduced) tween(0) else spring(dampingRatio = 1f, stiffness = 420f), label = "Practice progress")
    LinearProgressIndicator(progress = { displayed.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth()
        .padding(vertical = 8.dp), color = colorPrimaryLightFg, trackColor = colorLine)
}
