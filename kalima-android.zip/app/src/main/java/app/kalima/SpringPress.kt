package app.kalima

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

/** Observe without consuming: the existing button owns clicks, cancellation and semantics. */
internal fun Modifier.springPress(enabled: Boolean = true): Modifier = composed {
    val reduced = rememberReducedMotion()
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed && enabled && !reduced) .97f else 1f,
        if (reduced) tween(0) else spring(dampingRatio = .82f, stiffness = 700f), label = "Action press")
    this.graphicsLayer { scaleX = scale; scaleY = scale }.pointerInput(enabled, reduced) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            pressed = enabled && !reduced
            try { waitForUpOrCancellation() } finally { pressed = false }
        }
    }
}
