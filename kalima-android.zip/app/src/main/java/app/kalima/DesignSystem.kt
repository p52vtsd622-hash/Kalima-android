package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared reading rhythm; navigation and gesture geometry keep their own metrics. */
internal object KalimaDesign {
    val screenInset = 20.dp
    val cardInset = 20.dp
    val sectionGap = 24.dp
    val itemGap = 12.dp
    val cardShape = RoundedCornerShape(20.dp)
    val controlShape = RoundedCornerShape(12.dp)
}

@Composable
internal fun ReadingSurface(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = KalimaDesign.cardShape, color = colorSurface,
        border = BorderStroke(1.dp, colorLine), tonalElevation = 0.dp, shadowElevation = 0.dp) {
        Column(Modifier.padding(KalimaDesign.cardInset), content = content)
    }
}

/** Dictionary prose is already translated content, so never pass it through UI lookup. */
@Composable
internal fun ReadingText(text: String, modifier: Modifier = Modifier, primary: Boolean = false, muted: Boolean = false) {
    if (text.isBlank()) return
    val language = appPrefs?.appLanguage ?: "en"
    val size = when (language) { "ar" -> if (primary) 24 else 21; "ur" -> if (primary) 22 else 19; "fa" -> if (primary) 20 else 18; else -> if (primary) 20 else 17 }
    val height = when (language) { "ur" -> size * 2.2f; "ar" -> size * 1.7f; "fa" -> size * 1.8f; else -> size * 1.55f }
    RawText(text, modifier = modifier.fillMaxWidth(), color = if (muted) colorMuted else colorInk,
        fontFamily = translationFont(language), fontSize = size.sp, lineHeight = height.sp,
        fontWeight = FontWeight.Normal, textAlign = TextAlign.Start,
        style = androidx.compose.ui.text.TextStyle(textDirection = if (Langs.isRtl(language)) TextDirection.Rtl else TextDirection.Ltr))
}

@Composable
internal fun StudySection(title: String, initiallyExpanded: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    ReadingSurface { ExpandableResultSection(title, initiallyExpanded, content) }
}
