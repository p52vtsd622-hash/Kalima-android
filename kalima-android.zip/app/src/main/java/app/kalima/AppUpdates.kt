package app.kalima

import android.app.Activity
import android.app.Application
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

internal class AppUpdates(private val app: Application, private val scope: CoroutineScope) {
    var checking by mutableStateOf(false); private set
    var release by mutableStateOf<UpdateRelease?>(null); private set
    var downloading by mutableStateOf(false); private set
    var progress by mutableStateOf(0); private set
    var error by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null); private set
    var installEvent by mutableStateOf(0); private set
    private var handledInstallEvent = 0
    private var checkJob: Job? = null
    private var downloadJob: Job? = null
    private var readyFile: File? = null
    private var awaitingPermission = false
    private var installerOpen = false
    private val repository get() = BuildConfig.UPDATE_REPOSITORY
    private val folder get() = File(app.cacheDir, "updates").apply { mkdirs() }
    private val installedCode get() = PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0))

    fun onForeground() {
        if (!awaitingPermission && !installerOpen && !downloading && release == null) check(false)
    }
    fun check(manual: Boolean) {
        if (checking || downloading || awaitingPermission || installerOpen) return
        if (!UpdatePolicy.repositoryValid(repository)) {
            if (manual) message = "Update checking is unavailable in this build."
            return
        }
        checking = true
        message = null
        checkJob = scope.launch {
            try {
                val next = withContext(Dispatchers.IO) {
                    val c = connection("https://github.com/$repository/releases/download/latest/update.json")
                    try {
                        require(c.contentLengthLong <= 65536)
                        val bytes = c.inputStream.use { it.readBytesBounded(65536) }
                        UpdatePolicy.parse(bytes.toString(Charsets.UTF_8), repository, installedCode, Build.VERSION.SDK_INT)
                    } finally { c.disconnect() }
                }
                release = next; error = null
                if (manual && next == null) message = "Kalima is up to date on this device."
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (manual) message = "Couldn't check for updates. Try again when you're online." }
            finally { checking = false }
        }
    }
    fun dismissMessage() { message = null }
    fun later() {
        downloadJob?.cancel(); release = null; error = null
    }
    fun download() {
        val next = release ?: return
        if (downloading || awaitingPermission || installerOpen) return
        error = null
        if (readyFile?.name == "Kalima-${next.versionCode}.apk" && readyFile?.isFile == true) { installEvent++; return }
        progress = 0; downloading = true
        downloadJob = scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    // A cancelled attempt finishes before another can start (downloading stays true).
                    folder.listFiles()?.forEach { it.delete() }
                    val partial = File(folder, "update.part")
                    val target = File(folder, "Kalima-${next.versionCode}.apk")
                    val c = connection(next.apkUrl)
                    try {
                        require(c.contentLengthLong < 0 || c.contentLengthLong == next.size)
                        val context = currentCoroutineContext()
                        var lastProgress = -1
                        c.inputStream.use { input -> partial.outputStream().use { output ->
                            UpdatePolicy.copyVerified(input, output, next, { context.ensureActive() }) { pct ->
                                if (pct != lastProgress) { lastProgress = pct; scope.launch { progress = pct } }
                            }
                        } }
                        context.ensureActive()
                        verifyApk(partial, next)
                        require(partial.renameTo(target))
                        target
                    } finally { partial.delete(); c.disconnect() }
                }
                readyFile = file; installEvent++
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { error = "The update couldn't be downloaded or verified. Please try again." }
            finally { downloading = false }
        }
    }
    fun handleInstallEvent(activity: Activity, event: Int) {
        if (event <= handledInstallEvent) return
        handledInstallEvent = event
        requestInstall(activity)
    }
    fun requestInstall(activity: Activity) {
        if (release == null || readyFile?.isFile != true) return
        try {
            if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
                awaitingPermission = true
                activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}")))
            } else launchInstaller(activity)
        } catch (_: Exception) { awaitingPermission = false; installerOpen = false; error = "Couldn't open the installer. Try again." }
    }
    fun onResume(activity: Activity) {
        if (awaitingPermission) {
            awaitingPermission = false
            if (Build.VERSION.SDK_INT < 26 || app.packageManager.canRequestPackageInstalls()) requestInstall(activity)
            else error = "Allow Kalima to install updates, then try again."
        } else if (installerOpen) { installerOpen = false }
    }
    private fun launchInstaller(activity: Activity) {
        val file = readyFile ?: return
        val info = release ?: return
        // Recheck the cached package before sharing it with Android's installer.
        verifyApk(file, info)
        val uri = FileProvider.getUriForFile(app, "${app.packageName}.updates", file)
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.clipData = ClipData.newRawUri("Kalima update", uri)
        installerOpen = true
        activity.startActivity(intent)
        release = null; error = null
    }
    @Suppress("DEPRECATION")
    private fun verifyApk(file: File, next: UpdateRelease) {
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val archive = app.packageManager.getPackageArchiveInfo(file.path, flags) ?: error("Invalid APK")
        val installed = app.packageManager.getPackageInfo(app.packageName, flags)
        require(archive.packageName == app.packageName && PackageInfoCompat.getLongVersionCode(archive) == next.versionCode)
        require(next.versionCode > PackageInfoCompat.getLongVersionCode(installed))
        if (Build.VERSION.SDK_INT >= 24) require((archive.applicationInfo?.minSdkVersion ?: Int.MAX_VALUE) <= Build.VERSION.SDK_INT)
        fun certs(info: PackageInfo): Set<String> {
            val signatures = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
            return signatures.orEmpty().map { signature ->
                MessageDigest.getInstance("SHA-256").digest(signature.toByteArray()).joinToString("") { "%02x".format(it) }
            }.toSet()
        }
        val expected = certs(installed)
        require(expected.isNotEmpty() && certs(archive) == expected) { "Wrong update signer" }
    }
    private fun connection(start: String): HttpURLConnection {
        var address = start
        repeat(6) {
            require(UpdatePolicy.trustedTransport(address))
            val c = (URL(address).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false; connectTimeout = 15000; readTimeout = 30000
                useCaches = false; setRequestProperty("User-Agent", "Kalima/${BuildConfig.VERSION_NAME}")
                setRequestProperty("Cache-Control", "no-cache")
                setRequestProperty("Accept-Encoding", "identity")
            }
            try {
                val code = c.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    address = URL(URL(address), c.getHeaderField("Location") ?: error("Missing redirect")).toString()
                    c.disconnect()
                } else { require(code == 200); return c }
            } catch (e: Exception) { c.disconnect(); throw e }
        }
        error("Too many redirects")
    }
    private fun java.io.InputStream.readBytesBounded(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        while (true) {
            val n = read(buffer); if (n < 0) break
            require(out.size() + n <= limit); out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }
}
