package app.kalima

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val savedStore = SavedStore(app)
    private val historyStore = app.getSharedPreferences("kalima_history", 0)
    var currentTab by mutableStateOf("lookup")
    val savedEntries = mutableStateListOf<JSONObject>()
    val recentWords = mutableStateListOf<String>()
    var query by mutableStateOf("")
    var searchMode by mutableStateOf("ar")
    var lookupMode by mutableStateOf("deep")
    var loading by mutableStateOf(false)
    var errorMsg by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)
    var result by mutableStateOf<Word?>(null)
    var translationOptions by mutableStateOf<List<Gloss>?>(null)
    var conjLoading by mutableStateOf(false)
    var loadedConjs by mutableStateOf<JSONArray?>(null)
    var rootLoading by mutableStateOf(false)
    var rootWords by mutableStateOf<List<Gloss>?>(null)
    var rootExpanded by mutableStateOf(false)
    var translationLoading by mutableStateOf(false)
    var extraError by mutableStateOf<String?>(null)
    var hasTranslation by mutableStateOf(false)
    var hasLegacyTranslation by mutableStateOf(false)
    var legacyMeaning by mutableStateOf("")
    private var job: Job? = null
    private var conjugationJob: Job? = null
    private var rootJob: Job? = null
    private var translationJob: Job? = null
    private var requestId = 0
    private var languageRequestId = 0
    private var lastRawObj: JSONObject? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        try { savedEntries.addAll(savedStore.load()) } catch (_: Exception) { notice = "Your saved words couldn't be opened. Restore a backup if needed." }
        try { recentWords.addAll(JSONArray(historyStore.getString("words", "[]")).strings()) } catch (_: Exception) { }
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = (tts?.setLanguage(Locale("ar")) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= 0
            }
        }
    }

    override fun onCleared() {
        super.onCleared(); tts?.stop(); tts?.shutdown()
    }

    fun speak(text: String) {
        if (!ttsReady) { notice = "Arabic pronunciation isn't available yet. Check the Arabic voice in your phone's text-to-speech settings."; return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kalima")
    }

    fun exportData() = DataCodec.export(savedEntries.toList())
    fun exportCsv() = DataCodec.csv(savedEntries.toList())

    fun importData(text: String) {
        viewModelScope.launch {
            try {
                val decoded = withContext(Dispatchers.Default) { DataCodec.decodeBackup(text) }
                val merged = savedEntries.map { DataCodec.copy(it) }.toMutableList()
                var added = 0; var enriched = 0
                for (entry in decoded) {
                    val index = merged.indexOfFirst { it.str("id") == entry.str("id") }
                    if (index < 0) { merged.add(entry); added++ }
                    else {
                        val replacement = DataCodec.merge(merged[index], entry)
                        if (replacement.toString() != merged[index].toString()) enriched++
                        merged[index] = replacement
                    }
                }
                if (commitSaved(merged.sortedByDescending { it.optLong("addedAt") })) {
                    notice = "Imported $added new words; updated $enriched existing words. Your review progress was kept."
                    lastRawObj?.str("word")?.let { id -> savedEntries.find { it.str("id") == id }?.let { refreshResult(it.getJSONObject("data")) } }
                }
            } catch (e: Exception) { notice = e.message ?: "That file isn't a Kalima backup." }
        }
    }

    private fun commitSaved(entries: List<JSONObject>): Boolean {
        return try {
            savedStore.save(entries)
            savedEntries.clear(); savedEntries.addAll(entries)
            true
        } catch (_: Exception) { notice = "Couldn't save your words. Free some space on the phone and try again."; false }
    }

    fun isSaved(id: String) = savedEntries.any { it.str("id") == id }
    fun toggleSave() {
        val d = lastRawObj ?: return
        val id = d.str("word")
        if (isSaved(id)) { removeSaved(id); return }
        val now = System.currentTimeMillis()
        val entry = JSONObject().put("id", id).put("addedAt", now).put("added", now)
            .put("box", 0).put("due", 0L).put("data", DataCodec.copy(d))
        commitSaved(listOf(entry) + savedEntries.toList())
    }

    fun removeSaved(id: String) { commitSaved(savedEntries.filter { it.str("id") != id }) }
    private fun updateSavedData(d: JSONObject) {
        val index = savedEntries.indexOfFirst { it.str("id") == d.str("word") }
        if (index < 0) return
        val entries = savedEntries.toMutableList()
        entries[index] = DataCodec.copy(entries[index]).put("data", DataCodec.copy(d))
        commitSaved(entries)
    }
    fun gradeSaved(entry: JSONObject, correct: Boolean) {
        val index = savedEntries.indexOfFirst { it.str("id") == entry.str("id") }
        if (index < 0) return
        val entries = savedEntries.toMutableList()
        entries[index] = gradeEntry(entries[index], correct)
        commitSaved(entries)
    }

    private fun invalidateRequests() {
        requestId++; languageRequestId++
        job?.cancel(); conjugationJob?.cancel(); rootJob?.cancel(); translationJob?.cancel()
        loading = false; conjLoading = false; rootLoading = false; translationLoading = false
    }
    fun clear() {
        invalidateRequests(); query = ""; result = null; lastRawObj = null; translationOptions = null
        rootWords = null; rootExpanded = false; loadedConjs = null; errorMsg = null; extraError = null
    }
    fun openSaved(entry: JSONObject) {
        invalidateRequests()
        refreshResult(DataCodec.normalizeEntry(entry).getJSONObject("data"))
        query = result?.word ?: ""; searchMode = "ar"; errorMsg = null; extraError = null
        translationOptions = null; rootExpanded = false; currentTab = "lookup"
    }
    private fun refreshResult(d: JSONObject) {
        lastRawObj = d
        result = Word.fromJson(d, prefs.lang)
        loadedConjs = d.optJSONObject("verb")?.optJSONArray("conjugation")?.takeIf { it.length() > 0 }
        val translation = d.optJSONObject("trans")?.optJSONObject(prefs.lang)
        hasTranslation = prefs.lang == "off" || (translation != null && translation.str("meaning").isNotBlank() &&
            listOf("examples", "synonyms", "antonyms").all { key ->
                val count = d.optJSONArray(key)?.length() ?: 0
                (0 until count).all { !translation.optJSONArray(key)?.optString(it, "").isNullOrBlank() }
            })
        hasLegacyTranslation = d.optJSONObject("trans")?.has("legacy") == true
        legacyMeaning = d.optJSONObject("trans")?.optJSONObject("legacy")?.str("meaning") ?: ""
        rootWords = d.optJSONObject("extras")?.optJSONArray("rootWords_" + prefs.lang)?.let { glosses(it) }
    }
    fun changeLanguage(lang: String) {
        // Full lookups may include a translation: invalidate them too rather than relabel an old answer.
        invalidateRequests(); prefs.updateLang(lang); extraError = null
        translationOptions = null
        lastRawObj?.let { refreshResult(it) }
    }
    fun assignLegacyLanguage(lang: String) {
        val d = lastRawObj ?: return
        val trans = d.optJSONObject("trans") ?: return
        val legacy = trans.optJSONObject("legacy") ?: return
        if (!trans.has(lang)) trans.put(lang, legacy)
        trans.remove("legacy")
        refreshResult(d); updateSavedData(d)
    }
    fun receiveSelectedText(raw: String) { query = raw.trim().take(60); searchMode = "ar"; currentTab = "lookup"; lookup() }
    fun openWord(word: String) {
        query = word; searchMode = "ar"; currentTab = "lookup"
        val norm = KalimaSearch.baseNorm(word)
        val exact = savedEntries.find { it.str("id") == word }
        val candidates = savedEntries.filter { KalimaSearch.baseNorm(it.str("id")) == norm }
        val saved = exact ?: candidates.singleOrNull().takeIf { !Regex("[\u064B-\u065F]").containsMatchIn(word) }
        if (saved != null) openSaved(saved) else lookup()
    }
    private fun rememberWord(word: String) {
        recentWords.remove(word); recentWords.add(0, word)
        while (recentWords.size > 8) recentWords.removeAt(recentWords.lastIndex)
        historyStore.edit().putString("words", JSONArray(recentWords.toList()).toString()).apply()
    }
    fun clearHistory() { recentWords.clear(); historyStore.edit().remove("words").apply() }
    private fun checkAccess(): Boolean {
        if (prefs.hasAccess()) return true
        currentTab = "settings"
        notice = if (prefs.useShared()) "Enter your class passcode first." else "Add your personal Gemini key first."
        return false
    }
    private fun glosses(array: JSONArray) = array.objects().filter { it.str("ar").isNotBlank() }.map {
        Gloss(it.str("ar"), it.str("en"), it.str("tx"), it.str("transliteration"), it.str("partOfSpeech"), it.str("wazn"))
    }
    private suspend fun ask(prompt: String): JSONObject = withContext(Dispatchers.IO) {
        val o = parseLoose(Gemini.ask(prefs, prompt))
        if (o.has("error") && !o.isNull("error")) throw ApiError("model", o.str("error"))
        o
    }
    fun lookup() {
        val word = query.trim().replace(Regex("\\s+"), " ").take(if (searchMode == "rev") 80 else 60)
        currentTab = "lookup"
        if (word.isEmpty()) { errorMsg = "Type a word first."; return }
        val reverse = searchMode == "rev"
        if (!reverse && !Regex("[\u0621-\u064A]").containsMatchIn(word)) {
            errorMsg = "Type an Arabic word, or switch to Reverse Search."; return
        }
        if (!checkAccess()) return
        invalidateRequests(); val id = requestId; val lang = prefs.lang; val mode = lookupMode
        loading = true; errorMsg = null; extraError = null; result = null; lastRawObj = null
        translationOptions = null; loadedConjs = null; rootWords = null; rootExpanded = false
        job = viewModelScope.launch {
            try {
                if (reverse) {
                    val o = ask(Prompts.translate(word, lang))
                    val options = glosses(o.optJSONArray("results") ?: o.optJSONArray("options") ?: JSONArray())
                    if (id == requestId) {
                        translationOptions = options
                        if (options.isEmpty()) errorMsg = "No Arabic matches found."
                    }
                } else {
                    val o = ask(Prompts.lookup(word, lang, mode))
                    if (o.str("word").isBlank()) throw ApiError("invalid_json")
                    val normalized = DataCodec.normalizeData(o, lang)
                    if (id == requestId) { refreshResult(normalized); rememberWord(o.str("word")) }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: ApiError) { if (id == requestId) errorMsg = Gemini.friendly(e, prefs.useShared()) }
            catch (_: Exception) { if (id == requestId) errorMsg = "The reply couldn't be read. Try again." }
            finally { if (id == requestId) loading = false }
        }
    }
    fun loadConjugations(dictForm: String) {
        if (conjLoading || !checkAccess()) return
        val d = lastRawObj ?: return; val id = requestId
        conjLoading = true; extraError = null
        conjugationJob = viewModelScope.launch {
            try {
                val o = ask(Prompts.conjugate(dictForm)); val a = o.optJSONArray("conjugation") ?: throw ApiError("invalid_json")
                require(a.length() == 14 && a.objects().size == 14)
                require(a.objects().all { row -> listOf("past", "present", "subjunctive", "jussive", "imperative", "passivePast", "passivePresent").all { row.has(it) && row.opt(it) is String } })
                if (id == requestId && lastRawObj === d) {
                    d.optJSONObject("verb")?.put("conjugation", a)
                    refreshResult(d); updateSavedData(d)
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (id == requestId) extraError = if (e is ApiError) Gemini.friendly(e, prefs.useShared()) else "The conjugation table was incomplete. Try again." }
            finally { if (id == requestId) conjLoading = false }
        }
    }
    fun toggleRootWords() {
        if (rootLoading) return
        if (rootExpanded) { rootExpanded = false; return }
        if (rootWords != null) { rootExpanded = true; return }
        if (!checkAccess()) return
        val d = lastRawObj ?: return; val w = result ?: return
        val id = requestId; val langId = languageRequestId; val lang = prefs.lang
        rootLoading = true; extraError = null
        rootJob = viewModelScope.launch {
            try {
                val o = ask(Prompts.rootWords(w.root, w.word, lang)); val a = o.optJSONArray("words") ?: throw ApiError("invalid_json")
                if (id == requestId && langId == languageRequestId && lastRawObj === d) {
                    val extras = d.optJSONObject("extras") ?: JSONObject().also { d.put("extras", it) }
                    extras.put("rootWords_$lang", a); refreshResult(d); rootExpanded = true; updateSavedData(d)
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (id == requestId && langId == languageRequestId) extraError = if (e is ApiError) Gemini.friendly(e, prefs.useShared()) else "Couldn't load words from this root. Try again." }
            finally { if (id == requestId && langId == languageRequestId) rootLoading = false }
        }
    }
    fun addTranslation() {
        if (translationLoading || prefs.lang == "off" || !checkAccess()) return
        val d = lastRawObj ?: return; val w = result ?: return
        val id = requestId; val langId = languageRequestId; val lang = prefs.lang
        translationLoading = true; extraError = null
        translationJob = viewModelScope.launch {
            try {
                val t = ask(Prompts.addTranslation(w, lang))
                require(t.opt("meaning") is String && t.str("meaning").isNotBlank())
                for ((key, size) in listOf("examples" to w.examples.size, "synonyms" to w.synonyms.size, "antonyms" to w.antonyms.size)) {
                    val array = t.optJSONArray(key) ?: throw ApiError("invalid_json")
                    require(array.length() == size && (0 until size).all { array.opt(it) is String })
                }
                if (id == requestId && langId == languageRequestId && lastRawObj === d) {
                    val trans = d.optJSONObject("trans") ?: JSONObject().also { d.put("trans", it) }
                    trans.put(lang, t); refreshResult(d); updateSavedData(d)
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (id == requestId && langId == languageRequestId) extraError = if (e is ApiError) Gemini.friendly(e, prefs.useShared()) else "The translation was incomplete. Try again." }
            finally { if (id == requestId && langId == languageRequestId) translationLoading = false }
        }
    }
    fun cancel() { invalidateRequests(); errorMsg = "Lookup stopped." }
}
