package app.kalima

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)

    var query by mutableStateOf("")
    var loading by mutableStateOf(false)
    var errorMsg by mutableStateOf<String?>(null)
    var result by mutableStateOf<Word?>(null)
    var showSettings by mutableStateOf(false)

    private var job: Job? = null
    private var requestId = 0

    /** Called when text is selected in another app and "Look up in Kalima" is chosen. */
    fun receiveSelectedText(raw: String) {
        val m = Regex("[\u0600-\u06FF]+").find(raw)
        query = (m?.value ?: raw).trim().take(60)
        lookup()
    }

    fun lookup() {
        val word = query.trim().replace(Regex("\\s+"), " ").take(60)
        if (word.isEmpty()) {
            errorMsg = "Type a word first."
            return
        }
        if (!Regex("[\u0600-\u06FF]").containsMatchIn(word)) {
            errorMsg = "Please type the word in Arabic letters."
            return
        }
        if (!prefs.hasAccess()) {
            errorMsg = if (prefs.useShared()) "Enter your class passcode first (open Settings)."
            else "Add your Gemini key first (open Settings)."
            showSettings = true
            return
        }

        requestId += 1
        val id = requestId
        job?.cancel()
        loading = true
        errorMsg = null
        result = null
        val lang = prefs.lang

        job = viewModelScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val text = Gemini.ask(prefs, Prompts.lookup(word, lang))
                    val obj = parseLoose(text)
                    if (obj.has("error") && !obj.isNull("error")) {
                        throw ApiError("model", obj.optString("error", ""))
                    }
                    Word.fromJson(obj)
                }
                if (id == requestId) result = parsed
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiError) {
                if (id == requestId) errorMsg = Gemini.friendly(e, prefs.useShared())
            } catch (e: Exception) {
                if (id == requestId) errorMsg = "Something went wrong. Try again."
            } finally {
                if (id == requestId) loading = false
            }
        }
    }

    fun cancel() {
        requestId += 1
        job?.cancel()
        loading = false
        errorMsg = "Lookup stopped."
    }
}
