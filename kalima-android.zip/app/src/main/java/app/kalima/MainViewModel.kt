package app.kalima

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val savedStore = SavedStore(app)

    var currentTab by mutableStateOf("lookup")
    val savedEntries = mutableStateListOf<org.json.JSONObject>()

    var query by mutableStateOf("")
    var loading by mutableStateOf(false)
    var errorMsg by mutableStateOf<String?>(null)
    var result by mutableStateOf<Word?>(null)
    var showSettings by mutableStateOf(false)

    private var job: Job? = null
    private var requestId = 0
    private var lastRawObj: org.json.JSONObject? = null

    init {
        refreshSaved()
    }

    private fun refreshSaved() {
        savedEntries.clear()
        savedEntries.addAll(savedStore.load())
    }

    private fun persistSaved() {
        savedStore.save(savedEntries.toList())
    }

    fun isSaved(id: String): Boolean = savedEntries.any { it.optString("id") == id }

    /** Saves or un-saves the word currently on screen (needs a completed lookup first). */
    fun toggleSave() {
        val w = result ?: return
        val obj = lastRawObj ?: return
        if (isSaved(w.word)) {
            removeSaved(w.word)
        } else {
            val entry = org.json.JSONObject()
            entry.put("id", w.word)
            entry.put("addedAt", System.currentTimeMillis())
            entry.put("box", 0)
            entry.put("due", 0L)
            entry.put("data", obj)
            savedEntries.add(0, entry)
            persistSaved()
        }
    }

    fun removeSaved(id: String) {
        val idx = savedEntries.indexOfFirst { it.optString("id") == id }
        if (idx >= 0) savedEntries.removeAt(idx)
        persistSaved()
    }

    /** Opens a saved word instantly, from what was stored - no network request. */
    fun openSaved(entry: org.json.JSONObject) {
        val dataObj = entry.optJSONObject("data") ?: return
        result = Word.fromJson(dataObj)
        lastRawObj = dataObj
        query = result?.word ?: query
        errorMsg = null
        loading = false
        currentTab = "lookup"
    }

    /** Records a practice answer (flashcard or quiz) and reschedules the word. */
    fun gradeSaved(entry: org.json.JSONObject, correct: Boolean) {
        val idx = savedEntries.indexOfFirst { it.optString("id") == entry.optString("id") }
        if (idx < 0) return
        savedEntries[idx] = gradeEntry(entry, correct)
        persistSaved()
    }

    /** Called when text is selected in another app and "Look up in Kalima" is chosen. */
    fun receiveSelectedText(raw: String) {
        val m = Regex("[\u0600-\u06FF]+").find(raw)
        query = (m?.value ?: raw).trim().take(60)
        lookup()
    }

    fun lookup() {
        val word = query.trim().replace(Regex("\\s+"), " ").take(60)
        if (word.isEmpty()) {
            errorMsg = "Type a word first."
            return
        }
        if (!Regex("[\u0600-\u06FF]").containsMatchIn(word)) {
            errorMsg = "Please type the word in Arabic letters."
            return
        }
        if (!prefs.hasAccess()) {
            errorMsg = if (prefs.useShared()) "Enter your class passcode first (open Settings)."
            else "Add your Gemini key first (open Settings)."
            showSettings = true
            return
        }

        requestId += 1
        val id = requestId
        job?.cancel()
        loading = true
        errorMsg = null
        result = null
        val lang = prefs.lang

        job = viewModelScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val text = Gemini.ask(prefs, Prompts.lookup(word, lang))
                    val obj = parseLoose(text)
                    if (obj.has("error") && !obj.isNull("error")) {
                        throw ApiError("model", obj.optString("error", ""))
                    }
                    Pair(Word.fromJson(obj), obj)
                }
                if (id == requestId) {
                    result = parsed.first
                    lastRawObj = parsed.second
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiError) {
                if (id == requestId) errorMsg = Gemini.friendly(e, prefs.useShared())
            } catch (e: Exception) {
                if (id == requestId) errorMsg = "Something went wrong. Try again."
            } finally {
                if (id == requestId) loading = false
            }
        }
    }

    fun cancel() {
        requestId += 1
        job?.cancel()
        loading = false
        errorMsg = "Lookup stopped."
    }
}
