package app.kalima

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val savedStore = SavedStore(app)

    var currentTab by mutableStateOf("lookup")
    val savedEntries = mutableStateListOf<org.json.JSONObject>()

    var query by mutableStateOf("")
    var lookupMode by mutableStateOf("deep")
    var loading by mutableStateOf(false)
    var errorMsg by mutableStateOf<String?>(null)
    var result by mutableStateOf<Word?>(null)
    var translationOptions by mutableStateOf<List<Gloss>?>(null)
    var showSettings by mutableStateOf(false)

    // Separate states for the heavy conjugation generation
    var conjLoading by mutableStateOf(false)
    var loadedConjs by mutableStateOf<org.json.JSONArray?>(null)

    private var job: Job? = null
    private var requestId = 0
    private var lastRawObj: org.json.JSONObject? = null

    private var tts: TextToSpeech? = null

    init {
        refreshSaved()
        
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ar")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    fun exportData(): String {
        val arr = org.json.JSONArray()
        savedEntries.forEach { arr.put(it) }
        return arr.toString(2)
    }

    private fun refreshSaved() {
        savedEntries.clear()
        savedEntries.addAll(savedStore.load())
    }

    private fun persistSaved() {
        savedStore.save(savedEntries.toList())
    }

    fun isSaved(id: String): Boolean = savedEntries.any { it.optString("id") == id }

    fun toggleSave() {
        val w = result ?: return
        val obj = lastRawObj ?: return
        if (isSaved(w.word)) {
            removeSaved(w.word)
        } else {
            val entry = org.json.JSONObject()
            entry.put("id", w.word)
            entry.put("addedAt", System.currentTimeMillis())
            entry.put("box", 0)
            entry.put("due", 0L)
            entry.put("data", obj)
            // Cache the loaded 14x7 conjugations so they work offline if already fetched
            if (loadedConjs != null) {
                entry.put("conjs", loadedConjs)
            }
            savedEntries.add(0, entry)
            persistSaved()
        }
    }

    fun removeSaved(id: String) {
        val idx = savedEntries.indexOfFirst { it.optString("id") == id }
        if (idx >= 0) savedEntries.removeAt(idx)
        persistSaved()
    }

    fun openSaved(entry: org.json.JSONObject) {
        val dataObj = entry.optJSONObject("data") ?: return
        result = Word.fromJson(dataObj)
        lastRawObj = dataObj
        loadedConjs = entry.optJSONArray("conjs") // Load saved conjugations if any
        query = result?.word ?: query
        errorMsg = null
        loading = false
        conjLoading = false
        translationOptions = null
        currentTab = "lookup"
    }

    fun gradeSaved(entry: org.json.JSONObject, correct: Boolean) {
        val idx = savedEntries.indexOfFirst { it.optString("id") == entry.optString("id") }
        if (idx < 0) return
        savedEntries[idx] = gradeEntry(entry, correct)
        persistSaved()
    }

    fun receiveSelectedText(raw: String) {
        query = raw.trim().take(60)
        lookup()
    }

    fun lookup() {
        val word = query.trim().replace(Regex("\\s+"), " ").take(60)
        if (word.isEmpty()) {
            errorMsg = "Type a word first."
            return
        }
        if (!prefs.hasAccess()) {
            errorMsg = if (prefs.useShared()) "Enter your class passcode first (open Settings)."
            else "Add your Gemini key first (open Settings)."
            showSettings = true
            return
        }

        requestId += 1
        val id = requestId
        job?.cancel()
        loading = true
        errorMsg = null
        result = null
        translationOptions = null
        loadedConjs = null
        conjLoading = false
        val lang = prefs.lang

        val isArabic = Regex("[\u0600-\u06FF]").containsMatchIn(word)

        job = viewModelScope.launch {
            try {
                if (isArabic) {
                    val parsed = withContext(Dispatchers.IO) {
                        val text = Gemini.ask(prefs, Prompts.lookup(word, lang, lookupMode))
                        val obj = parseLoose(text)
                        if (obj.has("error") && !obj.isNull("error")) {
                            throw ApiError("model", obj.optString("error", ""))
                        }
                        Pair(Word.fromJson(obj), obj)
                    }
                    if (id == requestId) {
                        result = parsed.first
                        lastRawObj = parsed.second
                    }
                } else {
                    val options = withContext(Dispatchers.IO) {
                        val text = Gemini.ask(prefs, Prompts.translate(word, lang))
                        val obj = parseLoose(text)
                        if (obj.has("error") && !obj.isNull("error")) {
                            throw ApiError("model", obj.optString("error", ""))
                        }
                        val list = ArrayList<Gloss>()
                        val optsArr = obj.optJSONArray("options")
                        if (optsArr != null) {
                            for (i in 0 until optsArr.length()) {
                                val item = optsArr.optJSONObject(i)
                                if (item != null) {
                                    list.add(Gloss(item.optString("ar"), item.optString("en"), item.optString("tx")))
                                }
                            }
                        }
                        list
                    }
                    if (id == requestId) {
                        if (options.isEmpty()) {
                            errorMsg = "No translations found for this word."
                        } else {
                            translationOptions = options
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiError) {
                if (id == requestId) errorMsg = Gemini.friendly(e, prefs.useShared())
            } catch (e: Exception) {
                if (id == requestId) errorMsg = "Something went wrong. Try again."
            } finally {
                if (id == requestId) loading = false
            }
        }
    }

    /** Triggered only when the user explicitly taps "Show Conjugations" */
    fun loadConjugations(dictForm: String) {
        val id = requestId
        conjLoading = true
        viewModelScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val text = Gemini.ask(prefs, Prompts.conjugate(dictForm))
                    val obj = parseLoose(text)
                    if (obj.has("error") && !obj.isNull("error")) {
                        throw ApiError("model", obj.optString("error", ""))
                    }
                    obj.optJSONArray("conjugation")
                }
                if (id == requestId) {
                    loadedConjs = parsed
                    // If the user already saved this word, auto-update the database with the new conjugations
                    if (result != null && isSaved(result!!.word)) {
                        toggleSave() 
                        toggleSave() 
                    }
                }
            } catch (e: Exception) {
                if (id == requestId) errorMsg = "Failed to load conjugations. Try again."
            } finally {
                if (id == requestId) conjLoading = false
            }
        }
    }

    fun cancel() {
        requestId += 1
        job?.cancel()
        loading = false
        conjLoading = false
        errorMsg = "Lookup stopped."
    }
}





