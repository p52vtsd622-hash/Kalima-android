package app.kalima

import org.json.JSONArray
import org.json.JSONObject

/** A problem while asking for a lookup. [code] says what kind, [detail] is extra text from the server. */
class ApiError(val code: String, val detail: String = "") : Exception(code + " " + detail)

fun parseObjectOrNull(text: String): JSONObject? {
    return try {
        JSONObject(text)
    } catch (e: Exception) {
        null
    }
}

/** Reads the model's reply even if it is wrapped in code fences or has text around it. */
fun parseLoose(text: String): JSONObject {
    var t = text.trim()
    t = t.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
    t = t.removeSuffix("```").trim()
    try {
        return JSONObject(t)
    } catch (e: Exception) {
        // fall through and try to cut out the object
    }
    val a = t.indexOf('{')
    val b = t.lastIndexOf('}')
    if (a >= 0 && b > a) {
        try {
            return JSONObject(t.substring(a, b + 1))
        } catch (e: Exception) {
            // fall through
        }
    }
    throw ApiError("invalid_json")
}

/** Text value of a key, or "" when it is missing or null (avoids the string "null"). */
fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")

fun JSONArray.objects(): List<JSONObject> {
    val out = ArrayList<JSONObject>()
    for (i in 0 until length()) {
        val x = optJSONObject(i)
        if (x != null) out.add(x)
    }
    return out
}

fun JSONArray.strings(): List<String> {
    val out = ArrayList<String>()
    for (i in 0 until length()) {
        if (!isNull(i)) out.add(optString(i, ""))
    }
    return out
}
