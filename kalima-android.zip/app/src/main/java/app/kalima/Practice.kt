package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.Surface
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject

/* ---------------- saved words ---------------- */

@Composable
fun SavedScreen(vm: MainViewModel) {
    var filter by rememberSaveable { mutableStateOf("") }
    val list = rememberLazyListState()
    val reduced = rememberReducedMotion()
    var highlight by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(highlight) { if (highlight != null) { delay(1400); highlight = null } }
    fun normalized(text: String) = text.replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "").lowercase()
    val matches = vm.savedEntries.filter { entry ->
        val d = entry.optJSONObject("data")
        val translations = d?.optJSONObject("trans")
        val meanings = translations?.keys()?.asSequence()?.map { translations.optJSONObject(it)?.str("meaning") ?: "" }?.joinToString(" ") ?: ""
        normalized(entry.str("id") + " " + (d?.str("transliteration") ?: "") + " " + (d?.optJSONObject("meaning")?.str("en") ?: "") + " " + meanings).contains(normalized(filter.trim()))
    }
    LaunchedEffect(vm.savedRevealRevision) {
        val word = vm.savedRevealWord ?: return@LaunchedEffect
        val visible = if (matches.any { it.str("id") == word }) matches else {
            filter = ""
            vm.savedEntries.toList()
        }
        val index = visible.indexOfFirst { it.str("id") == word }
        if (index >= 0) {
            snapshotFlow { list.layoutInfo.totalItemsCount }.first { it == visible.size + 2 }
            highlight = word
            if (reduced) list.scrollToItem(index + 1) else list.animateScrollToItem(index + 1)
        }
        vm.consumeSavedReveal()
    }
    LazyColumn(Modifier.fillMaxSize(), state = list, contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(key = "filter") {
            OutlinedTextField(filter, { filter = it }, Modifier.fillMaxWidth(),
                label = { Text("Filter saved words…") }, singleLine = true,
                shape = KalimaDesign.controlShape)
        }
        if (vm.savedEntries.isEmpty()) item { Text("No saved words yet. Look up a word and tap Save.", color = colorMuted) }
        else if (matches.isEmpty()) item { Text("No saved words match that filter.", color = colorMuted) }
        items(matches, key = { "word:" + it.str("id") }) {
            val movement = if (reduced) Modifier else Modifier.animateItem(
                fadeInSpec = tween(140), placementSpec = spring(dampingRatio = .86f, stiffness = 420f), fadeOutSpec = tween(100))
            SavedRow(it, vm, movement, highlight == it.str("id"))
        }
        item(key = "backups") {
            Column(Modifier.padding(top = 12.dp, bottom = 24.dp)) {
                HorizontalDivider(color = colorLine)
                Spacer(Modifier.height(20.dp))
                BackupActions(vm)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SavedRow(entry: JSONObject, vm: MainViewModel, modifier: Modifier = Modifier, highlighted: Boolean = false) {
    val motion = LocalWordMotion.current
    var preview by remember(entry) { mutableStateOf(false) }
    val data = entry.optJSONObject("data")
    val w = remember(entry, vm.prefs.lang, vm.prefs.appLanguage) { data?.let { Word.fromJson(it, vm.prefs.lang, vm.prefs.appLanguage) } }
    val word = w?.word ?: entry.str("id")
    if (preview) WordPreview(word, w, vm, onStudy = {
        if (w == null) vm.openWord(word)
        else if (motion != null) motion.open("saved", word, animate = false) { vm.openSaved(entry) } else vm.openSaved(entry)
    }, onDismiss = { preview = false }, onRemove = { vm.removeSaved(entry.str("id")) })
    Surface(modifier.fillMaxWidth(), shape = KalimaDesign.cardShape,
        border = BorderStroke(if (highlighted) 2.dp else 1.dp, if (highlighted) colorPrimaryLightFg else colorLine), color = colorSurface) {
        Column {
            Column(Modifier.fillMaxWidth().combinedClickable(enabled = w != null, role = Role.Button,
                onClickLabel = tr("Study word"), onLongClickLabel = tr("Preview word"), onLongClick = { preview = true },
                onClick = { if (motion != null) motion.open("saved", word) { vm.openSaved(entry) } else vm.openSaved(entry) })
                .padding(16.dp)) {
                MovingWord(word, "saved:$word", 34, 54, Modifier.align(androidx.compose.ui.AbsoluteAlignment.Right), TextAlign.Right)
                if (w != null) {
                    if (w.translit.isNotBlank() && vm.prefs.appLanguage != "ar")
                        RawText(w.translit, fontFamily = latinFont, fontSize = 15.sp, color = colorMuted)
                    if (w.pos.isNotBlank()) Text(w.pos, fontSize = 14.sp, color = colorMuted)
                    Spacer(Modifier.height(6.dp))
                    ReadingText(shortMeaning(w))
                    TxLine(w.meaningTx, vm.prefs.lang)
                }
            }
            HorizontalDivider(color = colorSoftLine)
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
                TextButton(modifier = Modifier.springPress(), onClick = { preview = true }, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Preview") }
                TextButton(onClick = { vm.removeSaved(entry.str("id")) },
                    modifier = Modifier.springPress().heightIn(min = 48.dp).semantics {
                        contentDescription = tr("Remove {0}").replace("{0}", word)
                    }, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) {
                    Text("Remove", fontSize = 14.sp)
                }
            }
        }
    }
}

fun Modifier.clickableRow(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)

/* ---------------- practice ---------------- */

@Composable
fun PracticeScreen(vm: MainViewModel) {
    if (vm.savedEntries.isEmpty()) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(20.dp))
            Text("Save some words first, then practice them here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(modifier = Modifier.springPress(), onClick = { vm.currentTab = "lookup" }) { Text("Go to Lookup") }
        }
        return
    }

    var mode by rememberSaveable(vm.reviewRequestEpoch) { mutableStateOf("flash") }
    val due = vm.savedEntries.count { isDue(it, System.currentTimeMillis()) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        PracticeCounter("${vm.savedEntries.size} saved · $due due now")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeChip("Flashcards", mode == "flash") { mode = "flash" }
            ModeChip("Quiz", mode == "quiz") { mode = "quiz" }
        }
        Spacer(Modifier.height(14.dp))
        androidx.compose.runtime.key(vm.reviewRequestEpoch) {
            if (mode == "flash") FlashcardSession(vm) else QuizSession(vm)
        }
    }
}

@Composable
fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(modifier = Modifier.springPress(), onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(modifier = Modifier.springPress(), onClick = onClick) { Text(label) }
    }
}

/* ---- flashcards ---- */

@Composable
fun FlashcardSession(vm: MainViewModel) {
    val now = remember { System.currentTimeMillis() }
    var all by rememberSaveable { mutableStateOf(false) }
    var queue by remember(vm.savedEntries.size, all) {
        val due = vm.savedEntries.filter { isDue(it, now) }.map { it.optString("id") }
        mutableStateOf(if (all) vm.savedEntries.map { it.optString("id") }.shuffled() else due.shuffled())
    }
    var index by remember(vm.savedEntries.size, all) { mutableStateOf(0) }
    var flipped by remember(vm.savedEntries.size, all) { mutableStateOf(false) }
    var reviewed by remember(vm.savedEntries.size, all) { mutableStateOf(0) }

    if (queue.isEmpty() && !all) {
        Text("Nothing is due right now. Come back later, or practice everything anyway.", color = colorMuted)
        Spacer(Modifier.height(12.dp))
        Button(modifier = Modifier.springPress(), onClick = { all = true }) { Text("Practice all words") }
        return
    }

    if (index >= queue.size) {
        Text("Session finished. Words reviewed: $reviewed.", fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        Button(modifier = Modifier.springPress(), onClick = { index = 0; flipped = false; reviewed = 0; queue = vm.savedEntries.map { it.optString("id") }.shuffled() }) {
            Text("Start again")
        }
        return
    }

    val id = queue[index]
    val entry = vm.savedEntries.find { it.optString("id") == id } ?: run { index++; return }
    val w = entry.optJSONObject("data")?.let { Word.fromJson(it, vm.prefs.lang, vm.prefs.appLanguage) }
    if (w == null) { index++; return }

    PracticeCounter("Card ${index + 1} of ${queue.size}", 13)
    PracticeProgress(index, queue.size)
    Spacer(Modifier.height(8.dp))

    androidx.compose.runtime.key(id, index) {
        InteractiveFlashcard(w, vm.prefs.lang, flipped, { flipped = !flipped }) { correct ->
            if (vm.gradeSaved(entry, correct)) {
                if (!correct) queue = queue + id
                reviewed++; index++; flipped = false
                true
            } else false
        }
    }
    TextButton(modifier = Modifier.springPress(), onClick = { vm.speak(w.word) }) { Text("Listen") }
}

/* ---- quiz ---- */

private data class QuizQ(val entryId: String, val toEnglish: Boolean, val optionIds: List<String>)

@Composable
fun QuizSession(vm: MainViewModel) {
    if (vm.savedEntries.size < 2) {
        Text("Save at least 2 words to take a quiz.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    fun buildQuestions(): List<QuizQ> {
        val ids = vm.savedEntries.map { it.optString("id") }.shuffled()
        val take = ids.take(10)
        return take.map { correctId ->
            val others = ids.filter { it != correctId }.shuffled().take(3)
            QuizQ(correctId, toEnglish = (0..1).random() == 0, optionIds = (listOf(correctId) + others).shuffled())
        }
    }

    var questions by remember(vm.savedEntries.size) { mutableStateOf(buildQuestions()) }
    var qi by remember(vm.savedEntries.size) { mutableStateOf(0) }
    var score by remember(vm.savedEntries.size) { mutableStateOf(0) }
    var pickedId by remember(qi) { mutableStateOf<String?>(null) }

    fun entryFor(id: String) = vm.savedEntries.find { it.optString("id") == id }
    fun wordFor(id: String) = entryFor(id)?.optJSONObject("data")?.let { Word.fromJson(it, vm.prefs.lang, vm.prefs.appLanguage) }

    if (qi >= questions.size) {
        Text("Score: $score out of ${questions.size}", fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        Button(modifier = Modifier.springPress(), onClick = { questions = buildQuestions(); qi = 0; score = 0 }) { Text("New quiz") }
        return
    }

    val q = questions[qi]
    val correctW = wordFor(q.entryId) ?: run { qi++; return }

    PracticeCounter("Question ${qi + 1} of ${questions.size}", 13)
    PracticeProgress(qi + if (pickedId != null) 1 else 0, questions.size)
    Spacer(Modifier.height(10.dp))

    if (q.toEnglish) {
        Text(correctW.word, style = TextStyle(fontFamily = arabicFont, fontSize = 46.sp, lineHeight = 69.sp, textDirection = TextDirection.Rtl), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text("What does this mean?", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    } else {
        Text(shortMeaning(correctW), fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        TxLine(correctW.meaningTx, vm.prefs.lang)
        Spacer(Modifier.height(6.dp))
        Text("Which Arabic word is this?", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
    Spacer(Modifier.height(16.dp))

    for (optId in q.optionIds) {
        val optW = wordFor(optId) ?: continue
        val isCorrect = optId == q.entryId
        val isPicked = optId == pickedId
        val showState = pickedId != null && (isCorrect || isPicked)
        QuizOption(
            label = if (q.toEnglish) shortMeaning(optW) else optW.word,
            arabic = !q.toEnglish,
            state = if (!showState) 0 else if (isCorrect) 1 else 2,
            enabled = pickedId == null
        ) {
            if (pickedId == null) {
                val committed = entryFor(q.entryId)?.let { vm.gradeSaved(it, isCorrect) } == true
                if (committed) { pickedId = optId; if (isCorrect) score++ }
            }
        }
    }

    if (pickedId != null) {
        Spacer(Modifier.height(8.dp))
        Button(modifier = Modifier.springPress(), onClick = { qi++ }) { Text(if (qi + 1 >= questions.size) "See score" else "Next") }
    }
}

/** state: 0 = neutral, 1 = correct answer, 2 = the wrong one that was picked. */
@Composable
fun QuizOption(label: String, arabic: Boolean, state: Int, enabled: Boolean, onClick: () -> Unit) {
    val border = when (state) {
        1 -> MaterialTheme.colorScheme.primary
        2 -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.outline
    }
    val bg = when (state) {
        1 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
        2 -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
        else -> MaterialTheme.colorScheme.surface
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .background(bg, RoundedCornerShape(12.dp))
            .border(1.5.dp, border, RoundedCornerShape(12.dp))
            .clickableRow(if (enabled) onClick else ({}))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(
            label,
            style = if (arabic) TextStyle(fontFamily = arabicFont, fontSize = 24.sp, lineHeight = 40.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
            else TextStyle(fontFamily = latinFont, fontSize = 17.sp, lineHeight = 26.sp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
