package app.kalima

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject

/* ---------------- saved words ---------------- */

@Composable
fun SavedScreen(vm: MainViewModel) {
    val scroll = rememberScrollState()
    Column(modifier = Modifier.fillMaxSize().verticalScroll(scroll)) {
        if (vm.savedEntries.isEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text(
                "No saved words yet. After a lookup, tap Save word to keep it here.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@Column
        }
        for (entry in vm.savedEntries) {
            SavedRow(entry, vm)
        }
        Spacer(Modifier.height(48.dp))
    }
}

@Composable
fun SavedRow(entry: JSONObject, vm: MainViewModel) {
    val data = entry.optJSONObject("data")
    val w = remember(entry) { data?.let { Word.fromJson(it) } }
    var armed by remember(entry) { mutableStateOf(false) }

    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }

    Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickableRow { if (w != null) vm.openSaved(entry) }
            ) {
                if (w != null) {
                    if (w.translit.isNotBlank()) {
                        Text(w.translit + (if (w.pos.isNotBlank()) " · " + w.pos else ""), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(shortMeaning(w), fontSize = 15.sp)
                } else {
                    Text(entry.optString("id"), fontSize = 15.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            if (w != null) {
                Text(
                    w.word,
                    style = TextStyle(fontSize = 26.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
                )
            }
            Spacer(Modifier.width(10.dp))
            TextButton(onClick = {
                if (!armed) armed = true else vm.removeSaved(entry.optString("id"))
            }) {
                Text(if (armed) "Tap again" else "Remove", fontSize = 13.sp)
            }
        }
    }
}

/** A clickable modifier without a ripple import; keeps this file's dependency list small. */
fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))

/* ---------------- practice ---------------- */

@Composable
fun PracticeScreen(vm: MainViewModel) {
    if (vm.savedEntries.isEmpty()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(Modifier.height(20.dp))
            Text("Save some words first, then practice them here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.currentTab = "lookup" }) { Text("Go to Lookup") }
        }
        return
    }

    var mode by rememberSaveable { mutableStateOf("flash") }
    val due = vm.savedEntries.count { isDue(it, System.currentTimeMillis()) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(vm.savedEntries.size.toString() + " saved · " + due + " due now", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeChip("Flashcards", mode == "flash") { mode = "flash" }
            ModeChip("Quiz", mode == "quiz") { mode = "quiz" }
        }
        Spacer(Modifier.height(14.dp))
        if (mode == "flash") FlashcardSession(vm) else QuizSession(vm)
    }
}

@Composable
fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

/* ---- flashcards ---- */

@Composable
fun FlashcardSession(vm: MainViewModel) {
    val now = remember { System.currentTimeMillis() }
    var queue by remember(vm.savedEntries.size) {
        val due = vm.savedEntries.filter { isDue(it, now) }.map { it.optString("id") }
        mutableStateOf(if (due.isEmpty()) vm.savedEntries.map { it.optString("id") }.shuffled() else due.shuffled())
    }
    var index by remember(vm.savedEntries.size) { mutableStateOf(0) }
    var flipped by remember(vm.savedEntries.size) { mutableStateOf(false) }
    var reviewed by remember(vm.savedEntries.size) { mutableStateOf(0) }

    if (index >= queue.size) {
        Text("Session finished. You reviewed " + reviewed + " word" + (if (reviewed == 1) "" else "s") + ".", fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { index = 0; flipped = false; reviewed = 0; queue = vm.savedEntries.map { it.optString("id") }.shuffled() }) {
            Text("Start again")
        }
        return
    }

    val id = queue[index]
    val entry = vm.savedEntries.find { it.optString("id") == id } ?: run { index++; return }
    val w = entry.optJSONObject("data")?.let { Word.fromJson(it) }
    if (w == null) { index++; return }

    Text("Card " + (index + 1) + " of " + queue.size, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickableRow { flipped = !flipped },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(w.word, style = TextStyle(fontSize = if (flipped) 40.sp else 60.sp, textDirection = TextDirection.Rtl), textAlign = TextAlign.Center)
            if (!flipped) {
                Spacer(Modifier.height(8.dp))
                Text("Tap the card to see the meaning", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            } else {
                Spacer(Modifier.height(10.dp))
                if (w.translit.isNotBlank()) Text(w.translit, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text(w.meaningEn, fontSize = 18.sp, textAlign = TextAlign.Center)
                val ex = w.examples.firstOrNull()
                if (ex != null) {
                    Spacer(Modifier.height(10.dp))
                    Text(ex.ar, style = TextStyle(fontSize = 20.sp, textDirection = TextDirection.Rtl), textAlign = TextAlign.Center)
                    Text(ex.en, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }

    if (flipped) {
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    vm.gradeSaved(entry, false)
                    queue = queue + id
                    reviewed++; index++; flipped = false
                },
                modifier = Modifier.weight(1f)
            ) { Text("Again", color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    vm.gradeSaved(entry, true)
                    reviewed++; index++; flipped = false
                },
                modifier = Modifier.weight(1f)
            ) { Text("Got it") }
        }
    }
}

/* ---- quiz ---- */

private data class QuizQ(val entryId: String, val toEnglish: Boolean, val optionIds: List<String>)

@Composable
fun QuizSession(vm: MainViewModel) {
    if (vm.savedEntries.size < 2) {
        Text("Save at least 2 words to take a quiz.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    fun buildQuestions(): List<QuizQ> {
        val ids = vm.savedEntries.map { it.optString("id") }.shuffled()
        val take = ids.take(10)
        return take.map { correctId ->
            val others = ids.filter { it != correctId }.shuffled().take(3)
            QuizQ(correctId, toEnglish = (0..1).random() == 0, optionIds = (listOf(correctId) + others).shuffled())
        }
    }

    var questions by remember(vm.savedEntries.size) { mutableStateOf(buildQuestions()) }
    var qi by remember(vm.savedEntries.size) { mutableStateOf(0) }
    var score by remember(vm.savedEntries.size) { mutableStateOf(0) }
    var pickedId by remember(qi) { mutableStateOf<String?>(null) }

    fun entryFor(id: String) = vm.savedEntries.find { it.optString("id") == id }
    fun wordFor(id: String) = entryFor(id)?.optJSONObject("data")?.let { Word.fromJson(it) }

    if (qi >= questions.size) {
        Text("Score: " + score + " out of " + questions.size, fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { questions = buildQuestions(); qi = 0; score = 0 }) { Text("New quiz") }
        return
    }

    val q = questions[qi]
    val correctW = wordFor(q.entryId) ?: run { qi++; return }

    Text("Question " + (qi + 1) + " of " + questions.size, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(10.dp))

    if (q.toEnglish) {
        Text(correctW.word, style = TextStyle(fontSize = 46.sp, textDirection = TextDirection.Rtl), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text("What does this mean?", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    } else {
        Text(shortMeaning(correctW), fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text("Which Arabic word is this?", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
    Spacer(Modifier.height(16.dp))

    for (optId in q.optionIds) {
        val optW = wordFor(optId) ?: continue
        val isCorrect = optId == q.entryId
        val isPicked = optId == pickedId
        val showState = pickedId != null && (isCorrect || isPicked)
        QuizOption(
            label = if (q.toEnglish) shortMeaning(optW) else optW.word,
            arabic = !q.toEnglish,
            state = if (!showState) 0 else if (isCorrect) 1 else 2,
            enabled = pickedId == null
        ) {
            if (pickedId == null) {
                pickedId = optId
                val correct = isCorrect
                if (correct) score++
                entryFor(q.entryId)?.let { vm.gradeSaved(it, correct) }
            }
        }
    }

    if (pickedId != null) {
        Spacer(Modifier.height(8.dp))
        Button(onClick = { qi++ }) { Text(if (qi + 1 >= questions.size) "See score" else "Next") }
    }
}

/** state: 0 = neutral, 1 = correct answer, 2 = the wrong one that was picked. */
@Composable
fun QuizOption(label: String, arabic: Boolean, state: Int, enabled: Boolean, onClick: () -> Unit) {
    val border = when (state) {
        1 -> MaterialTheme.colorScheme.primary
        2 -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.outline
    }
    val bg = when (state) {
        1 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
        2 -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
        else -> MaterialTheme.colorScheme.surface
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .background(bg, RoundedCornerShape(12.dp))
            .border(1.5.dp, border, RoundedCornerShape(12.dp))
            .clickableRow(if (enabled) onClick else ({}))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(
            label,
            style = if (arabic) TextStyle(fontSize = 24.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
            else TextStyle(fontSize = 17.sp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
