package app.kalima

object Prompts {
    private const val ORDER_TEXT = "0 هُوَ, 1 هُمَا (masc. dual), 2 هُمْ, 3 هِيَ, 4 هُمَا (fem. dual), 5 هُنَّ, 6 أَنْتَ, 7 أَنْتُمَا (masc.), 8 أَنْتُمْ, 9 أَنْتِ, 10 أَنْتُمَا (fem.), 11 أَنْتُنَّ, 12 أَنَا, 13 نَحْنُ"
    private fun translationShape() = """{"root":"root meaning","meaning":"meaning","partOfSpeech":"localized part of speech","grammarNote":"localized grammar note or empty","waznNote":"localized pattern explanation or empty","note":"localized usage note or empty","inputPerson":"localized person description or empty","examples":["translated example"],"synonyms":["translated gloss"],"antonyms":["translated gloss"]}"""
    fun translate(word: String, lang: String, appLanguage: String = "en"): String = """A learner typed: $word. It may be in any language. Give 3 to 5 natural Modern Standard Arabic equivalents, most common first. For verbs use the past he-form. Fully vocalize Arabic. Do not invent words.
Return ONLY JSON: {"results":[{"ar":"vocalized Arabic","transliteration":"Latin transliteration","partOfSpeech":"verb | noun | adjective | other","en":"English meaning","main":"meaning in ${Langs.promptDesc[appLanguage]}","tx":"meaning in ${Langs.promptDesc[lang] ?: "English"}"}]}. If meaningless return {"error":"invalid input"}."""
    fun rootWords(root: List<String>, word: String, lang: String, appLanguage: String = "en"): String {
        val fields = mutableListOf("\"ar\":\"fully vocalized Arabic word\"", "\"partOfSpeech\":\"verb | noun | adjective | other\"", "\"wazn\":\"Arabic morphological pattern\"", "\"en\":\"short English gloss\"")
        if (appLanguage != "en") fields.add("\"main\":\"short meaning in ${Langs.promptDesc[appLanguage]}\"")
        if (lang !in listOf("off", "en")) fields.add("\"tx\":\"short meaning in ${Langs.promptDesc[lang]}\"")
        return """Arabic root: ${root.joinToString(" ")}. Exclude this word: $word.
List 8 to 12 attested, common Modern Standard Arabic words from this root. Give fewer if necessary; never invent a word. Fully vocalize each Arabic word. Use short dictionary glosses, not sentences. English is canonical storage; also supply every requested localized meaning.
Return exactly one complete JSON object with this schema: {"words":[{${fields.joinToString(",")}}]}.
Keep these machine keys exactly. Use double-quoted JSON strings, no Markdown, commentary or trailing commas. Every entry must contain all requested keys. Return {"words":[]} only if there are no suitable words."""
    }
    fun addTranslation(w: Word, lang: String): String {
        fun numbered(values: List<String>) = values.mapIndexed { i, text -> "${i + 1}. $text" }.joinToString("\n")
        return """Translate all explanatory content into ${Langs.promptDesc[lang]}. Arabic word: ${w.word}.
Return ONLY JSON shaped like ${translationShape()}.
Use exactly ${w.examples.size} examples, ${w.synonyms.size} synonyms and ${w.antonyms.size} antonyms in the original order. Natural translations, not transliteration. Include every metadata key even if empty. Fully vocalize Arabic. Do not add examples or change the sense.
root: ${w.rootGloss}
meaning: ${w.meaningEn}
partOfSpeech: ${w.pos}
grammarNote: ${w.grammar}
waznNote: ${w.waznNote}
note: ${w.note}
inputPerson: ${w.verb?.inputPerson.orEmpty()}
examples:
${numbered(w.examples.map { it.en })}
synonyms:
${numbered(w.synonyms.map { it.ar + " = " + it.en })}
antonyms:
${numbered(w.antonyms.map { it.ar + " = " + it.en })}"""
    }
    fun conjugate(verb: String): String {
        val out = ArrayList<String>()
        out.add("You are an expert Arabic teacher. Provide the full 14-pronoun conjugation for the Arabic verb: " + verb)
        out.add("")
        out.add("Reply with ONLY one JSON object in exactly this shape:")
        out.add("{")
        out.add("""  "conjugation": [ { "past": "...", "present": "...", "subjunctive": "...", "jussive": "...", "imperative": "...", "passivePast": "...", "passivePresent": "..." } ]""")
        out.add("}")
        out.add("")
        out.add("Rules:")
        out.add("- The array must contain exactly 14 items in this order: " + ORDER_TEXT + ".")
        out.add("- Give the verb only, without the pronoun.")
        out.add("- \"passivePast\" and \"passivePresent\": the passive voice. If the verb is intransitive and doesn't take a passive, use \"\" for all items.")
        out.add("- \"imperative\": only fill it for 2nd person (indices 6-11); use \"\" for others.")
        out.add("- Fully vocalize (tashkeel) all Arabic text. Take extra care with hollow, defective, doubled and hamzated verbs.")
        return out.joinToString("\n")
    }


    fun lookup(word: String, lang: String, mode: String = "deep", appLanguage: String = "en"): String {
        val requested = listOf(appLanguage, lang).distinct().filter { it !in listOf("en", "off") }
        val translations = requested.joinToString(",") { "\"$it\":" + translationShape() }
        return """You are an expert Arabic teacher. Analyze this Arabic word: $word.
Return ONLY JSON. Keep these machine keys exactly; canonical English fields are for storage, not the interface:
{"word":"fully vocalized Arabic","transliteration":"Latin transliteration","partOfSpeech":"verb | noun | adjective | adverb | preposition | particle | pronoun | other","grammarNote":"English gender/plural note or empty","root":["ك","ت","ب"],"rootGloss":"English root idea","wazn":{"pattern":"ف ع ل morphological pattern","note":"English pattern description"},"meaning":{"en":"English meaning","ar":"simple Arabic definition"},"examples":[{"ar":"Arabic sentence","en":"English translation"},{"ar":"Arabic sentence","en":"English translation"}],
"forms": ${if (mode == "fast") "[]" else "[\"related Arabic forms without attached particles or pronouns\"]"},
"synonyms": ${if (mode == "fast") "[]" else "[{\"ar\":\"Arabic\",\"en\":\"English gloss\"}]"},
"antonyms": ${if (mode == "fast") "[]" else "[{\"ar\":\"Arabic\",\"en\":\"English gloss\"}]"},
"verb":null,"note":"English ambiguity/usage note or empty","trans":{$translations}}
Fully vocalize ALL Arabic, including examples and definitions. Give an accurate wazn for every inflected word; use an empty pattern only for words without a pattern. Root has 3 letters or 4 for quadriliterals; particles/loanwords may have [].
For trans: ${requested.joinToString("; ") { "$it = ${Langs.promptDesc[it]}" }}. Every trans object must translate the SAME sense, root idea, metadata, examples, synonyms and antonyms in the exact same order as canonical fields. Arrays must have identical lengths. Include all metadata keys, even when empty. No English explanations inside these objects except unavoidable proper names.
${if (mode == "fast") "FAST MODE: forms, synonyms, antonyms must be []; verb must be null; grammarNote and note must be empty. Keep short." else "DEEP MODE: give up to 25 useful related forms, 3–5 synonyms and 0–3 real antonyms. For a verb in ANY tense/person, set verb to {\"form\":\"I–X or Quadriliteral\",\"pattern\":\"past and present pattern\",\"dictionaryForm\":\"past he\",\"presentForm\":\"present he\",\"masdar\":\"verbal noun\",\"masdarWazn\":\"pattern\",\"inputTense\":\"past | present | subjunctive | jussive | imperative | passivePast | passivePresent\",\"inputPerson\":\"English person description\",\"inputMatch\":{\"index\":0,\"tense\":\"past\"},\"conjugation\":[]}. inputMatch uses the 14-pronoun order $ORDER_TEXT. Do not generate conjugations here. For nonverbs keep verb null."}
If meaningless return {"error":"invalid input"}. Analyze only the first word if several are given."""
    }
}
