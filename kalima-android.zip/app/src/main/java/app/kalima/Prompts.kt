package app.kalima

object Prompts {

    private const val ORDER_TEXT =
        "0 هُوَ, 1 هُمَا (masc. dual), 2 هُمْ, 3 هِيَ, 4 هُمَا (fem. dual), 5 هُنَّ, 6 أَنْتَ, 7 أَنْتُمَا (masc.), 8 أَنْتُمْ, 9 أَنْتِ, 10 أَنْتُمَا (fem.), 11 أَنْتُنَّ, 12 أَنَا, 13 نَحْنُ"

    /** The translation prompt for non-Arabic words. */
    fun translate(word: String, lang: String): String {
        val n = Langs.names[lang] ?: ""
        val hasL = n.isNotEmpty()
        val out = ArrayList<String>()

        out.add("You are an expert Arabic translator. The user searched for a non-Arabic word: \"$word\".")
        out.add("Reply with ONLY a JSON object containing an array of 3 to 6 accurate Modern Standard Arabic translations for this word.")
        out.add("Format EXACTLY like this:")
        out.add("{")
        out.add("  \"options\": [")
        out.add("    { \"ar\": \"Arabic word 1 fully vocalized\", \"en\": \"Specific nuance or meaning of this word in English\"" +
            (if (hasL) ", \"tx\": \"Nuance in $n\"" else "") + " },")
        out.add("    { \"ar\": \"Arabic word 2 fully vocalized\", \"en\": \"Specific nuance or meaning of this word in English\"" +
            (if (hasL) ", \"tx\": \"Nuance in $n\"" else "") + " }")
        out.add("  ]")
        out.add("}")
        out.add("Do not include any other text. Fully vocalize all Arabic words.")
        
        return out.joinToString("\n")
    }

    /** The full word analysis. [lang] is ur, fa, tr or off. [mode] dictates generation depth. */
    fun lookup(word: String, lang: String, mode: String = "deep"): String {
        val n = Langs.names[lang] ?: ""
        val d = Langs.promptDesc[lang] ?: ""
        val hasL = n.isNotEmpty()
        val out = ArrayList<String>()

        out.add("You are an expert teacher of Modern Standard Arabic helping a learner whose languages are English" +
            (if (hasL) " and " + n else "") + ". Analyze this ARABIC word: " + word)
        out.add("")
        out.add("Reply with ONLY one JSON object and nothing else, analyzing the ARABIC word in exactly this shape:")
        out.add("{")
        out.add("""  "word": "the Arabic word fully vocalized with tashkeel",""")
        out.add("""  "transliteration": "simple Latin transliteration",""")
        out.add("""  "partOfSpeech": "verb | noun | adjective | adverb | preposition | particle | pronoun | other",""")
        out.add("""  "grammarNote": "for nouns and adjectives: gender and plural, e.g. feminine · plural مَدَارِسُ. Otherwise null",""")
        out.add("""  "root": ["ك","ت","ب"],""")
        out.add("""  "rootGloss": "core idea of the root in English, 2-5 words",""")
        if (hasL) out.add("  \"rootGlossTx\": \"the same idea in " + n + "\",")
        out.add("""  "wazn": { "pattern": "the morphological pattern (وزن) of the word, written with the root letters ف ع ل and vowel marks, e.g. فَاعِل, مَفْعَلَة, أَفْعَال, يَفْعُلُونَ, اِسْتَفْعَلَ", "note": "very short English label, e.g. active participle, noun of place, broken plural, form X past" },""")
        out.add("  \"meaning\": { \"en\": \"clear English meaning\", " +
            (if (hasL) "\"tx\": \"clear, natural " + n + " meaning\", " else "") +
            "\"ar\": \"short, simple Arabic definition, fully vocalized\" },")
        out.add("  \"examples\": [ { \"ar\": \"Arabic sentence\", \"en\": \"English translation\"" +
            (if (hasL) ", \"tx\": \"" + n + " translation\"" else "") +
            " }, { \"ar\": \"...\", \"en\": \"...\"" +
            (if (hasL) ", \"tx\": \"...\"" else "") + " } ],")
        out.add("""  "forms": ["up to 25 related forms of this word, used to find it in the Quran and other texts. Give them WITHOUT attached prefixes (و ف ب ل ك س ال) or pronoun endings. For a verb: the masdar, participles and derived nouns (NOT the conjugations, which are listed separately). For a noun or adjective: singular, dual, plural and broken-plural forms and closely related forms of the same root and meaning. Fully vocalized"],""")
        out.add("""  "verb": null,""")
        out.add("  \"synonyms\": [ { \"ar\": \"...\", \"en\": \"English gloss\"" +
            (if (hasL) ", \"tx\": \"" + n + " gloss\"" else "") + " } ],")
        out.add("  \"antonyms\": [ { \"ar\": \"...\", \"en\": \"English gloss\"" +
            (if (hasL) ", \"tx\": \"" + n + " gloss\"" else "") + " } ],")
        out.add("""  "note": null""")
        out.add("}")
        out.add("")
        out.add("Rules:")
        out.add("- Fully vocalize (tashkeel) ALL Arabic text you write: the word, definition, examples, synonyms, antonyms and conjugations.")
        if (hasL) out.add("- All " + n + " text must be natural " + d + ", not transliteration.")
        out.add("""- "root": the root letters as separate single characters, in order (3 letters, or 4 for a quadriliteral root). If the word has no root (particle, loanword), use [] and set rootGloss""" +
            (if (hasL) " and rootGlossTx" else "") + " to null.")
        out.add("""- "wazn": ALWAYS give the wazn of the Arabic word, for every kind of word (verbs in any tense or person, nouns, adjectives, participles, plurals, verbal nouns). Replace the root letters with ف ع ل (add a second ل for a 4th radical) and keep all other letters, prefixes, suffixes and vowel marks. Examples: كَتَبَ → فَعَلَ; يَكْتُبُونَ → يَفْعُلُونَ; كَاتِب → فَاعِل; مَكْتُوب → مَفْعُول; مَدْرَسَة → مَفْعَلَة; كُتُب → فُعُل; اِسْتِخْدَام → اِسْتِفْعَال. Only use null if the word truly has no pattern (a particle or loanword).""")
        out.add("""- "examples": exactly 2 natural sentences that use the word, each with an English""" +
            (if (hasL) " and a " + n else "") +
            " translation. If the word is a verb, use the same inflected form as the primary word in the first sentence when natural.")
        
        if (mode == "fast") {
            out.add("- FAST MODE: Set \"forms\", \"synonyms\", and \"antonyms\" to []. Set \"verb\" to null. Set \"grammarNote\" and \"note\" to \"\". Do not generate verb conjugations or extra related forms. Keep the response as short and fast as possible.")
        } else {
            out.add("""- "synonyms": 3 to 5 items. "antonyms": 1 to 3 items, or [] if no real antonym exists.""")
            out.add("""- If the word is ambiguous without vowels, choose the most common meaning and mention the alternatives briefly in "note" (English). Otherwise "note" is null.""")
            out.add("""- If the input is completely meaningless, reply only with {"error": "short reason in English"}.""")
            out.add("- If several words were given, analyze only the first.")
            out.add("""- If (and only if) the ARABIC word is a verb in ANY tense, person or the imperative, set "verb" to this object; otherwise keep it null:""")
            out.add("  {")
            out.add("""    "form": "I, II, III, IV, V, VI, VII, VIII, IX or X (or Quadriliteral)",""")
            out.add("""    "pattern": "past and present pattern of this form, e.g. فَعَلَ – يَفْعُلُ, or اِسْتَفْعَلَ – يَسْتَفْعِلُ",""")
            out.add("""    "dictionaryForm": "past tense, he (3rd masc. singular), vocalized",""")
            out.add("""    "presentForm": "present tense, he (3rd masc. singular), vocalized",""")
            out.add("""    "masdar": "the masdar (verbal noun) of this verb, vocalized. Always provide it",""")
            out.add("""    "masdarWazn": "the wazn of that masdar using ف ع ل, e.g. فِعَالَة or اِسْتِفْعَال",""")
            out.add("""    "inputTense": "past | present | subjunctive | jussive | imperative | passivePast | passivePresent",""")
            out.add("""    "inputPerson": "who the form refers to, e.g. they (masculine plural)",""")
            out.add("""    "inputMatch": { "index": 2, "tense": "present" },""")
            out.add("""    "conjugation": [ { "past": "...", "present": "...", "subjunctive": "...", "jussive": "...", "imperative": "...", "passivePast": "...", "passivePresent": "..." } ]""")
            out.add("  }")
            out.add("""  "inputMatch": index (0-13) into the conjugation list below and which tense column the word matches, or null if it is an imperative or does not match.""")
            out.add("""  "conjugation": conjugate the DICTIONARY verb with exactly 14 items in this order: """ + ORDER_TEXT +
                """. For each, provide "past", "present" (indicative/مرفوع), "subjunctive" (منصوب), "jussive" (مجزوم). """ +
                """For "imperative" (أمر), only fill it for 2nd person (indices 6-11); use "" for others. """ +
                """For "passivePast" and "passivePresent", fill them if the verb is transitive; otherwise use "". """ +
                """Take extra care with hollow, defective, doubled and hamzated verbs.""")
        }

        return out.joinToString("\n")
    }
}
