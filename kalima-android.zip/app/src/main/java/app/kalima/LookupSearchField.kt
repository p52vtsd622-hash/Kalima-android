package app.kalima

import app.kalima.LocalizedText as Text
import app.kalima.LocalizedIcon as Icon
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Both submit paths share explicit lookup and keyboard dismissal; typing stays local. */
@Composable
internal fun LookupSearchField(vm: MainViewModel, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val reverse = vm.searchMode == "rev"
    val hint = if (reverse) "Find Arabic for..." else "Type an Arabic word…"
    val canSubmit = vm.query.isNotBlank()
    val submit = {
        if (vm.query.isNotBlank()) {
            vm.searchFocused = false
            keyboard?.hide()
            focus.clearFocus()
            vm.lookup()
        }
    }
    val shape = RoundedCornerShape(28.dp)
    Row(modifier.fillMaxWidth().background(colorInputBg, shape)
        .border(if (focused) 2.dp else 1.dp, if (focused) colorPrimaryLightFg else colorLine, shape)
        .padding(start = 18.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(vm.query, { vm.query = it },
            modifier = Modifier.weight(1f).heightIn(min = 48.dp).onFocusChanged { focused = it.isFocused; vm.searchFocused = it.isFocused && vm.currentTab == "lookup" }
                .semantics { contentDescription = tr(hint) },
            singleLine = true,
            cursorBrush = SolidColor(colorPrimaryLightFg),
            textStyle = TextStyle(color = colorInk, fontSize = if (reverse) 17.sp else 22.sp,
                lineHeight = if (reverse && vm.prefs.appLanguage == "ur") 38.sp else 36.sp,
                fontFamily = if (reverse) translationFont(vm.prefs.appLanguage) else arabicFont,
                textAlign = if (reverse) TextAlign.Start else TextAlign.Right,
                textDirection = if (reverse) TextDirection.Content else TextDirection.Rtl),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            decorationBox = { field ->
                Box(Modifier.fillMaxWidth().heightIn(min = 48.dp), contentAlignment = Alignment.CenterStart) {
                    if (vm.query.isEmpty()) Text(hint, color = colorMuted, fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth(), textAlign = if (reverse) TextAlign.Start else TextAlign.Right)
                    field()
                }
            })
        Spacer(Modifier.width(8.dp))
        IconButton(onClick = submit, enabled = canSubmit,
            modifier = Modifier.size(48.dp).background(if (canSubmit) colorPrimaryLightFg else colorLine, CircleShape)) {
            Icon(Icons_SendArrow, "Search", tint = if (canSubmit && !isDark) Color.White else if (canSubmit) colorSurface else colorMuted,
                modifier = Modifier.size(22.dp))
        }
    }
}
