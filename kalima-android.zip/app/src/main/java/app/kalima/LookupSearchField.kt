package app.kalima

import app.kalima.LocalizedText as Text
import app.kalima.LocalizedIcon as Icon
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Both submit paths share explicit lookup and keyboard dismissal; typing stays local. */
@Composable
internal fun LookupSearchField(vm: MainViewModel, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val grammar = vm.currentTab in listOf("grammar", "sentence_history")
    val value = if (grammar) vm.grammar.query else vm.query
    val reverse = !grammar && vm.searchMode == "rev"
    val hint = if (grammar) "Type an Arabic sentence…" else if (reverse) "Find Arabic for..." else "Type an Arabic word…"
    val canSubmit = value.isNotBlank() && (!grammar || !vm.grammar.loading)
    val submit = {
        if (canSubmit) {
            vm.searchFocused = false
            keyboard?.hide()
            focus.clearFocus()
            if (grammar) vm.analyseSentence() else vm.lookup()
        }
    }
    val shape = RoundedCornerShape(24.dp)
    Row(modifier.fillMaxWidth().background(colorInputBg, shape)
        .border(if (focused) 2.dp else 1.dp, if (focused) colorPrimaryLightFg else colorLine, shape)
        .padding(start = 14.dp, end = 0.dp),
        verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(value, { if (grammar) vm.grammar.edit(it) else vm.query = it },
            modifier = Modifier.weight(1f).heightIn(min = 48.dp).onFocusChanged { focused = it.isFocused; vm.searchFocused = it.isFocused && vm.currentTab == "lookup" }
                .semantics { contentDescription = tr(hint) },
            singleLine = true,
            cursorBrush = SolidColor(colorPrimaryLightFg),
            textStyle = TextStyle(color = colorInk, fontSize = if (reverse) 16.sp else 20.sp,
                lineHeight = if (reverse && vm.prefs.appLanguage == "ur") 36.sp else 32.sp,
                fontFamily = if (reverse) translationFont(vm.prefs.appLanguage) else arabicFont,
                textAlign = if (reverse) TextAlign.Start else TextAlign.Right,
                textDirection = if (reverse) TextDirection.Content else TextDirection.Rtl),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            decorationBox = { field ->
                Box(Modifier.fillMaxWidth().heightIn(min = 48.dp), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = colorMuted, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth(), textAlign = if (reverse) TextAlign.Start else TextAlign.Right)
                    field()
                }
            })
        Spacer(Modifier.width(8.dp))
        IconButton(onClick = submit, enabled = canSubmit,
            modifier = Modifier.springPress(canSubmit).size(48.dp)) {
            Box(Modifier.size(36.dp).background(if (canSubmit) colorPrimaryLightFg else colorLine, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons_SendArrow, if (grammar) "Analyse sentence" else "Search", tint = if (canSubmit && !isDark) Color.White else if (canSubmit) colorSurface else colorMuted,
                modifier = Modifier.size(20.dp))
            }
        }
    }
}
