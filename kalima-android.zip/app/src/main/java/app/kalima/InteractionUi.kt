package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText

import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
internal fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    fun read() = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    var disabled by remember(context) { mutableStateOf(read()) }
    DisposableEffect(context) {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { disabled = read() }
        }
        context.contentResolver.registerContentObserver(Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE), false, observer)
        onDispose { context.contentResolver.unregisterContentObserver(observer) }
    }
    return disabled
}

@Composable
internal fun ExpandableResultSection(title: String, initiallyExpanded: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var expanded by rememberSaveable { mutableStateOf(initiallyExpanded) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp)
            .semantics(mergeDescendants = true) { stateDescription = tr(if (expanded) "Expanded" else "Collapsed") }
            .clickable(role = Role.Button, onClickLabel = tr(if (expanded) "Collapse $title" else "Expand $title")) { expanded = !expanded }
            .padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = colorInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(12.dp))
            DisclosureChevron(expanded)
        }
        SmoothSectionVisibility(expanded) { Column(Modifier.fillMaxWidth().padding(top = 8.dp), content = content) }
    }
}

@Composable
internal fun SmoothSectionVisibility(visible: Boolean, content: @Composable () -> Unit) {
    val reduced = rememberReducedMotion()
    AnimatedVisibility(visible,
        enter = if (reduced) EnterTransition.None else expandVertically(spring(dampingRatio = 1f, stiffness = 420f), expandFrom = Alignment.Top) + fadeIn(tween(140)),
        exit = if (reduced) ExitTransition.None else shrinkVertically(spring(dampingRatio = 1f, stiffness = 420f), shrinkTowards = Alignment.Top) + fadeOut(tween(100))) { content() }
}

@Composable
internal fun SectionRequestFeedback(loading: Boolean, error: String?, description: String, onRetry: () -> Unit) {
    if (!loading && error == null) return
    Surface(Modifier.fillMaxWidth().padding(vertical = 8.dp).semantics { liveRegion = LiveRegionMode.Polite },
        color = colorPrimaryLight, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (loading) {
                    if (!rememberReducedMotion()) CircularProgressIndicator(Modifier.size(22.dp), color = colorPrimaryLightFg, strokeWidth = 2.dp)
                    Text(description, color = colorPrimaryLightFg, fontSize = 15.sp, modifier = Modifier.weight(1f))
                } else {
                    Column(Modifier.weight(1f)) {
                        Text("Couldn't finish this section", color = colorPrimaryLightFg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(error.orEmpty(), color = colorPrimaryLightFg, fontSize = 14.sp)
                    }
                    TextButton(onClick = onRetry) { Text("Retry", color = colorPrimaryLightFg) }
                }
            }
            if (loading) { Spacer(Modifier.height(16.dp)); LoadingBars(compact = true) }
        }
    }
}

/** Settings always chooses the complete interface language; it has no Off option. */
@Composable
internal fun AppLanguageSelectionSheet(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    LanguageSelectionSheet(selected, onSelect, onDismiss, "App language",
        "Change all menus, messages and explanations.", Localization.appLanguages)
}

/** Home only chooses an additional translation, independently of the interface. */
@Composable
internal fun ExtraTranslationSelectionSheet(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    LanguageSelectionSheet(selected, onSelect, onDismiss, "Extra translation",
        "Add a translation alongside Arabic and your app language.",
        Localization.extraLanguages(appPrefs?.appLanguage ?: "en") + "off")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageSelectionSheet(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit,
    title: String, description: String, languages: List<String>) {
    val sheet = rememberSpringSheetState()
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    var pendingChoice by remember { mutableStateOf<String?>(null) }
    fun closeSheet(selection: String? = null) {
        if (closing || sheet.closing) return
        closing = true
        if (selection != null) { pendingChoice = selection; onSelect(selection) }
        scope.launch {
            try { sheet.hide() } finally { onDismiss() }
        }
    }
    SpringBottomSheet(title = title, onDismissRequest = onDismiss, sheetState = sheet,
        containerColor = colorSurface, contentColor = colorInk, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { BottomSheetDefaults.DragHandle(color = colorMuted) }) {
        Column(Modifier.fillMaxWidth().widthIn(max = 560.dp).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = colorPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = { closeSheet() }, enabled = !closing && !sheet.closing) { Text("Close", color = colorInk) }
            }
            Text(description, color = colorMuted, fontSize = 15.sp)
            Spacer(Modifier.height(16.dp))
            languages.map { it to (Langs.names[it] ?: "Off") }.forEach { (code, name) ->
                val chosen = code == (pendingChoice ?: selected)
                Surface(Modifier.fillMaxWidth().padding(bottom = 8.dp), color = if (chosen) colorPrimaryLight else colorSurface,
                    shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, if (chosen) colorPrimary else colorLine)) {
                    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).selectable(chosen, enabled = !closing && !sheet.closing, role = Role.RadioButton) { closeSheet(code) }
                        .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(name, color = colorInk, fontSize = 17.sp, fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Normal)
                            if (code == "off") Text("No extra translation", color = colorMuted, fontSize = 14.sp)
                        }
                        if (code != "off") RawText(Langs.nativeNames[code].orEmpty(), fontFamily = translationFont(code), color = colorPrimary, fontSize = 20.sp, lineHeight = if (code == "ur") 44.sp else 30.sp)
                        SpringChoiceIndicator(chosen)
                    }
                }
            }
        }
    }
}
