package app.kalima

/** Shared access is ready by default; personal access is an explicit, optional choice. */
internal object AccessPolicy {
    fun useShared(access: String, key: String): Boolean = access != "own" || key.isBlank()
    fun hasAccess(access: String, key: String, server: String): Boolean =
        if (useShared(access, key)) server.isNotBlank() else key.isNotBlank()
}
