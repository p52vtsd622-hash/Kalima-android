package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun SettingsGroup(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        if (title != null) Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = colorMuted,
            modifier = Modifier.padding(start = 4.dp, bottom = 10.dp).semantics { heading() })
        ReadingSurface(content = content)
    }
}

/** Values wrap below labels on narrow screens and at larger font scales. */
@Composable
private fun SettingsValueRow(label: String, value: String = "", expanded: Boolean? = null, onClick: () -> Unit) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val stacked = maxWidth < 340.dp || LocalDensity.current.fontScale > 1.25f
        Row(Modifier.fillMaxWidth().heightIn(min = 64.dp)
            .semantics(mergeDescendants = true) {
                if (expanded != null) stateDescription = tr(if (expanded) "Expanded" else "Collapsed")
            }.clickable(role = Role.Button, onClick = onClick).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (stacked) Column(Modifier.weight(1f)) {
                Text(label, color = colorInk, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                if (value.isNotBlank()) Text(value, color = colorPrimaryLightFg, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
            } else {
                Text(label, color = colorInk, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                if (value.isNotBlank()) Text(value, color = colorPrimaryLightFg, fontSize = 15.sp, modifier = Modifier.widthIn(max = 160.dp))
            }
            if (expanded != null) DisclosureChevron(expanded)
            else RawText(if (rtl) "‹" else "›", color = colorMuted, fontSize = 24.sp,
                modifier = Modifier.clearAndSetSemantics {})
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    val activity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
    var languageChanged by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }
    var showLanguage by remember { mutableStateOf(false) }
    var showAppearance by rememberSaveable { mutableStateOf(false) }
    var showPersonalKey by rememberSaveable { mutableStateOf(false) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    val appearanceName = when (p.theme) { "dark" -> "Dark"; "light" -> "Light"; else -> "System" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = KalimaDesign.screenInset),
        verticalArrangement = Arrangement.spacedBy(KalimaDesign.sectionGap)) {
        Text("Settings", color = colorInk, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.semantics { heading() })
        SettingsGroup("General") {
            SettingsValueRow("App language", Langs.names[p.appLanguage] ?: "English", onClick = { showLanguage = true })
            Text("Change all menus, messages and explanations.", color = colorMuted, fontSize = 14.sp)
            HorizontalDivider(Modifier.padding(top = 16.dp), color = colorLine)
            SettingsValueRow("Appearance", appearanceName, showAppearance) { showAppearance = !showAppearance }
            SmoothSectionVisibility(showAppearance) {
                Column(Modifier.padding(top = 4.dp, bottom = 4.dp)) {
                    Segmented(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), p.theme) { p.updateTheme(it) }
                }
            }
            HorizontalDivider(Modifier.padding(top = 16.dp), color = colorLine)
            Row(Modifier.fillMaxWidth().heightIn(min = 64.dp)
                .toggleable(value = p.haptics, role = Role.Switch, onValueChange = { p.updateHaptics(it) }),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Haptic feedback", color = colorInk, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Text("Small taps for navigation, saving and Undo.", color = colorMuted, fontSize = 14.sp)
                }
                Switch(checked = p.haptics, onCheckedChange = null)
            }
        }
        if (showLanguage) AppLanguageSelectionSheet(p.appLanguage,
            { if (it != p.appLanguage) { vm.changeAppLanguage(it); languageChanged = true } },
            { showLanguage = false; if (languageChanged) activity?.recreate() })
        SettingsGroup {
            SettingsValueRow("Personal Gemini key", if (p.apiKey.isBlank()) "Optional" else if (p.useShared()) "Off" else "On", showPersonalKey) { showPersonalKey = !showPersonalKey }
            SmoothSectionVisibility(showPersonalKey) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Kalima works without a key. Add your own if shared access reaches its limit.", color = colorMuted, fontSize = 14.sp)
                    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text(if (p.apiKey.isBlank()) "Paste your key" else "Replace saved key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, shape = KalimaDesign.controlShape)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg), onClick = { p.updateApiKey(key); key = ""; vm.notice = "Personal key saved and enabled." }, enabled = key.isNotBlank()) { Text("Save key") }
                        if (p.apiKey.isNotBlank()) TextButton(colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg), onClick = { p.updateApiKey(""); key = ""; vm.notice = "Personal key removed. Kalima will use shared access." }) { Text("Remove key") }
                    }
                    if (p.apiKey.isNotBlank()) {
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).toggleable(value = !p.useShared(), role = Role.Switch, onValueChange = { p.updateAccess(if (it) "own" else "shared") }), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Use my personal key", color = colorInk, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Switch(checked = !p.useShared(), onCheckedChange = null)
                        }
                        Text(if (p.useShared()) "Your key is saved but switched off." else "Your lookups use your personal key.", color = colorMuted, fontSize = 14.sp)
                    }
                }
            }
        }
        SettingsGroup("Your words and backups") { BackupActions(vm) }
        SettingsGroup {
            SettingsValueRow("Advanced", expanded = advanced) { advanced = !advanced }
            SmoothSectionVisibility(advanced) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true, shape = KalimaDesign.controlShape)
                    OutlinedTextField(proxy, { proxy = it }, Modifier.fillMaxWidth(), label = { Text("Shared server address") }, singleLine = true, shape = KalimaDesign.controlShape)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg), onClick = {
                            val address = proxy.trim()
                            if (address.isNotEmpty() && !address.startsWith("https://")) vm.notice = "Use a secure server address starting with https://."
                            else { p.updateModel(model.trim().ifBlank { Config.DEFAULT_MODEL }); p.updateProxyUrl(address.ifBlank { Config.DEFAULT_PROXY }); vm.notice = "Configuration saved." }
                        }) { Text("Save configuration") }
                        TextButton(colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg), onClick = {
                            model = Config.DEFAULT_MODEL; proxy = Config.DEFAULT_PROXY
                            p.updateModel(model); p.updateProxyUrl(proxy); vm.notice = "Default configuration restored."
                        }) { Text("Restore defaults") }
                    }
                }
            }
        }
        SettingsGroup("About") {
            Text("Kalima · 1.0", color = colorInk, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            SettingsValueRow("Check for updates", if (vm.updates.checking) "Checking for updates…" else "") { vm.updates.check(manual = true) }
            Spacer(Modifier.height(8.dp))
            Text("Pronunciation uses your phone's Arabic voice. New lookups need internet; saved words and practice work offline.", color = colorMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
