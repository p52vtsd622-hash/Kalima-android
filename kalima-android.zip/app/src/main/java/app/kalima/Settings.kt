package app.kalima

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }
    var advanced by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Settings", color = colorPrimary, fontSize = 28.sp, modifier = Modifier.padding(bottom = 20.dp))
        SectionTitle("Translation")
        Text("Shown alongside Arabic and English", color = colorMuted, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off"), p.lang) { vm.changeLanguage(it) }
        Spacer(Modifier.height(24.dp))
        SectionTitle("Appearance")
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), p.theme) { p.updateTheme(it) }
        Spacer(Modifier.height(24.dp))
        SectionTitle("Personal Gemini key")
        Text("Optional", color = colorMuted, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Text("Kalima works without a key. Add your own if shared access reaches its limit.", color = colorMuted, fontSize = 14.sp)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text(if (p.apiKey.isBlank()) "Paste your key" else "Replace saved key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Row {
            TextButton(onClick = { p.updateApiKey(key); key = ""; vm.notice = "Personal key saved and enabled." }, enabled = key.isNotBlank()) { Text("Save key") }
            if (p.apiKey.isNotBlank()) {
                TextButton(onClick = { p.updateApiKey(""); key = ""; vm.notice = "Personal key removed. Kalima will use shared access." }) { Text("Remove key") }
            }
        }
        if (p.apiKey.isNotBlank()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Use my personal key", color = colorPrimary, fontSize = 14.sp)
                Switch(checked = !p.useShared(), onCheckedChange = { p.updateAccess(if (it) "own" else "shared") })
            }
            Text(if (p.useShared()) "Your key is saved but switched off." else "Your lookups use your personal key.", color = colorMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(24.dp))
        HorizontalDivider(color = colorLine)
        TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "Advanced · Hide" else "Advanced") }
        if (advanced) {
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(proxy, { proxy = it }, Modifier.fillMaxWidth(), label = { Text("Shared server address") }, singleLine = true)
            TextButton(onClick = {
                val address = proxy.trim()
                if (address.isNotEmpty() && !address.startsWith("https://")) vm.notice = "Use a secure server address starting with https://."
                else { p.updateModel(model.trim().ifBlank { Config.DEFAULT_MODEL }); p.updateProxyUrl(address.ifBlank { Config.DEFAULT_PROXY }); vm.notice = "Configuration saved." }
            }) { Text("Save configuration") }
            TextButton(onClick = {
                model = Config.DEFAULT_MODEL; proxy = Config.DEFAULT_PROXY
                p.updateModel(model); p.updateProxyUrl(proxy)
                vm.notice = "Default configuration restored."
            }) { Text("Restore defaults") }
        }
        Spacer(Modifier.height(24.dp))
        SectionTitle("Your words and backups")
        BackupActions(vm)
        Spacer(Modifier.height(24.dp))
        Text("Kalima · 0.7\nArabic pronunciation uses your phone's installed Arabic voice. New lookups need internet; saved words and practice work offline.", color = colorMuted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
    }
}
