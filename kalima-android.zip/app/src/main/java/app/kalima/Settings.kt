package app.kalima

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    var pass by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var proxy by remember { mutableStateOf(p.proxyUrl) }
    var advanced by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Settings", color = colorPrimary, fontSize = 28.sp, modifier = Modifier.padding(bottom = 20.dp))
        Text("Translation shown with Arabic and English", color = colorMuted, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("ur" to "Urdu", "fa" to "Farsi", "tr" to "Turkish", "ru" to "Russian", "off" to "Off"), p.lang) { vm.changeLanguage(it) }
        Spacer(Modifier.height(24.dp))
        Text("Appearance", color = colorMuted, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), p.theme) { p.updateTheme(it) }
        Spacer(Modifier.height(24.dp))
        SectionTitle("AI access")
        Segmented(listOf("shared" to "Class account", "own" to "Personal key"), p.access) { p.updateAccess(it) }
        Spacer(Modifier.height(12.dp))
        if (p.access == "shared") {
            Text(if (p.passcode.isBlank()) "Enter the passcode provided by your teacher." else "A passcode is saved. It will be checked when you look up a word.", color = colorMuted, fontSize = 14.sp)
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Class passcode") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            Row {
                TextButton(onClick = { p.updatePasscode(pass.trim()); pass = ""; vm.notice = "Passcode saved." }, enabled = pass.isNotBlank()) { Text("Save passcode") }
                TextButton(onClick = { p.updatePasscode(""); pass = "" }) { Text("Remove passcode") }
            }
        } else {
            Text(if (p.apiKey.isBlank()) "Use your personal Gemini API key." else "A personal key is saved. It will be checked when you look up a word.", color = colorMuted, fontSize = 14.sp)
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Personal Gemini key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            Row {
                TextButton(onClick = { p.updateApiKey(key.trim()); key = ""; vm.notice = "Personal key saved." }, enabled = key.isNotBlank()) { Text("Save key") }
                TextButton(onClick = { p.updateApiKey(""); key = "" }) { Text("Remove key") }
            }
        }
        HorizontalDivider(color = colorLine)
        TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "Hide advanced settings" else "Advanced settings") }
        if (advanced) {
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(proxy, { proxy = it }, Modifier.fillMaxWidth(), label = { Text("Class server address") }, singleLine = true)
            TextButton(onClick = {
                val address = proxy.trim()
                if (address.isNotEmpty() && !address.startsWith("https://")) vm.notice = "Use a secure class server address starting with https://."
                else { p.updateModel(model.trim().ifBlank { Config.DEFAULT_MODEL }); p.updateProxyUrl(address); vm.notice = "Configuration saved." }
            }) { Text("Save configuration") }
        }
        Spacer(Modifier.height(24.dp))
        SectionTitle("Your words and backups")
        BackupActions(vm)
        Spacer(Modifier.height(24.dp))
        Text("Kalima · 0.5\nArabic pronunciation uses your phone's installed Arabic voice. New AI answers need internet; saved words and practice work offline.", color = colorMuted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
    }
}
