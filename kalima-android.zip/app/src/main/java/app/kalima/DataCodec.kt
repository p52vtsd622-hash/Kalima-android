package app.kalima

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** One interoperable format for the browser, old Android backups and native storage. */
object DataCodec {
    fun copy(o: JSONObject) = JSONObject(o.toString())

    fun normalizeData(input: JSONObject, knownLanguage: String? = null): JSONObject {
        val d = copy(input)
        val trans = d.optJSONObject("trans") ?: JSONObject().also { d.put("trans", it) }
        val meaning = d.optJSONObject("meaning") ?: JSONObject().also { d.put("meaning", it) }
        val legacyUrdu = meaning.has("ur") || d.has("rootGlossUr") ||
            listOf("examples", "synonyms", "antonyms").any { key ->
                d.optJSONArray(key)?.objects()?.any { it.has("ur") } == true
            }
        if (legacyUrdu && !trans.has("ur")) trans.put("ur", translationFromFields(d, "ur", "rootGlossUr"))
        val hasTx = meaning.has("tx") || d.has("rootGlossTx") ||
            listOf("examples", "synonyms", "antonyms").any { key ->
                d.optJSONArray(key)?.objects()?.any { it.has("tx") } == true
            }
        if (hasTx) {
            val lang = knownLanguage?.takeIf { Langs.names.containsKey(it) }
                ?: d.str("translationLanguage").takeIf { Langs.names.containsKey(it) } ?: "legacy"
            if (!trans.has(lang)) trans.put(lang, translationFromFields(d, "tx", "rootGlossTx"))
        }
        meaning.remove("tx"); meaning.remove("ur")
        d.remove("rootGlossTx"); d.remove("rootGlossUr")
        for (key in listOf("examples", "synonyms", "antonyms")) {
            d.optJSONArray(key)?.objects()?.forEach { it.remove("tx"); it.remove("ur") }
        }
        val extras = d.optJSONObject("extras")
        extras?.optJSONArray("rootWords")?.let { words ->
            words.objects().forEach { w -> if (w.has("ur")) { w.put("tx", w.str("ur")); w.remove("ur") } }
            extras.put("rootWords_ur", words); extras.remove("rootWords")
        }
        return d
    }

    private fun translationFromFields(d: JSONObject, field: String, rootField: String): JSONObject {
        val t = JSONObject().put("root", d.str(rootField))
            .put("meaning", d.optJSONObject("meaning")?.str(field) ?: "")
        for (key in listOf("examples", "synonyms", "antonyms")) {
            t.put(key, JSONArray().also { a -> d.optJSONArray(key)?.objects()?.forEach { a.put(it.str(field)) } })
        }
        return t
    }

    fun normalizeEntry(input: JSONObject): JSONObject {
        val entry = copy(input)
        val data = entry.optJSONObject("data") ?: throw IllegalArgumentException("A saved word is missing its details.")
        val id = entry.str("id").ifBlank { data.str("word") }
        require(id.isNotBlank() && data.str("word").isNotBlank()) { "A saved word has no Arabic word." }
        val normalized = normalizeData(data)
        val oldConjs = entry.optJSONArray("conjs")
        if (oldConjs != null && oldConjs.length() > 0) normalized.optJSONObject("verb")?.put("conjugation", oldConjs)
        entry.remove("conjs")
        entry.put("id", id).put("data", normalized)
        val added = entry.optLong("addedAt", entry.optLong("added", System.currentTimeMillis()))
        entry.put("addedAt", added).put("added", added)
        entry.put("box", entry.optInt("box", 0).coerceIn(0, 5))
        entry.put("due", entry.optLong("due", 0).coerceAtLeast(0))
        return entry
    }

    fun decodeBackup(text: String): List<JSONObject> {
        require(text.toByteArray(Charsets.UTF_8).size <= 20 * 1024 * 1024) { "This backup is too large (maximum 20 MB)." }
        val value = JSONTokener(text).nextValue()
        val array = when (value) {
            is JSONArray -> value
            is JSONObject -> {
                val app = value.str("app")
                require(app.isEmpty() || app == "kalima") { "This isn't a Kalima backup." }
                require(value.optInt("version", 1) <= 2) { "This backup needs a newer Kalima app." }
                value.optJSONArray("words") ?: throw IllegalArgumentException("This isn't a Kalima backup.")
            }
            else -> throw IllegalArgumentException("This isn't a Kalima backup.")
        }
        require(array.length() <= 10000) { "This backup contains too many words." }
        // Validate the whole file before any changes are made.
        return (0 until array.length()).map { i ->
            normalizeEntry(array.optJSONObject(i) ?: throw IllegalArgumentException("Word ${i + 1} is invalid."))
        }
    }

    fun export(entries: List<JSONObject>): String = JSONObject()
        .put("app", "kalima").put("version", 2)
        .put("exported", java.text.SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss\'Z\'", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date()))
        .put("words", JSONArray().also { a -> entries.forEach { a.put(normalizeEntry(it)) } }).toString(2)

    fun csv(entries: List<JSONObject>): String {
        fun cell(v: String) = "\"" + v.replace("\r", " ").replace("\n", " ").replace("\"", "\"\"") + "\""
        val header = listOf("Arabic", "Transliteration", "Root", "Part of speech", "Wazn", "English", "Urdu", "Persian", "Turkish", "Russian", "Arabic definition", "Example (Arabic)", "Example (English)")
        val rows = entries.map { entry ->
            val d = entry.getJSONObject("data"); val m = d.optJSONObject("meaning"); val ex = d.optJSONArray("examples")?.optJSONObject(0)
            listOf(d.str("word"), d.str("transliteration"), d.optJSONArray("root")?.strings()?.joinToString(" ") ?: "",
                d.str("partOfSpeech"), d.optJSONObject("wazn")?.str("pattern") ?: "", m?.str("en") ?: "") +
                listOf("ur", "fa", "tr", "ru").map { d.optJSONObject("trans")?.optJSONObject(it)?.str("meaning") ?: "" } +
                listOf(m?.str("ar") ?: "", ex?.str("ar") ?: "", ex?.str("en") ?: "")
        }
        return "\uFEFF" + (listOf(header) + rows).joinToString("\r\n") { it.joinToString(",") { s -> cell(s) } }
    }

    /** Fill gaps without replacing existing meanings or resetting review progress. */
    fun merge(existing: JSONObject, incoming: JSONObject): JSONObject {
        val out = copy(existing); val d = out.getJSONObject("data"); val src = incoming.getJSONObject("data")
        val t = d.optJSONObject("trans") ?: JSONObject().also { d.put("trans", it) }
        src.optJSONObject("trans")?.let { translations ->
            translations.keys().forEach { lang ->
                // A second AI answer may have a different sense or example order.
                // Never attach a translation to unrelated English text.
                if (!t.has(lang) && d.optJSONObject("meaning")?.str("en") == src.optJSONObject("meaning")?.str("en")) {
                    val incoming = translations.optJSONObject(lang)
                    if (incoming != null) {
                        val aligned = JSONObject().put("meaning", incoming.str("meaning"))
                            .put("root", if (d.str("rootGloss") == src.str("rootGloss")) incoming.str("root") else "")
                        for (key in listOf("examples", "synonyms", "antonyms")) {
                            val targets = d.optJSONArray(key)?.objects().orEmpty()
                            val sources = src.optJSONArray(key)?.objects().orEmpty()
                            val values = incoming.optJSONArray(key)
                            aligned.put(key, JSONArray().also { a -> targets.forEach { target ->
                                val i = sources.indexOfFirst { it.str("ar") == target.str("ar") && it.str("en") == target.str("en") }
                                a.put(if (i >= 0) values?.optString(i, "") ?: "" else "")
                            } })
                        }
                        t.put(lang, aligned)
                    }
                }
            }
        }
        val v = d.optJSONObject("verb"); val sv = src.optJSONObject("verb")
        if (v != null && v.str("dictionaryForm") == sv?.str("dictionaryForm") && (v.optJSONArray("conjugation")?.length() ?: 0) == 0) sv?.optJSONArray("conjugation")?.let { v.put("conjugation", it) }
        val extra = d.optJSONObject("extras") ?: JSONObject().also { d.put("extras", it) }
        src.optJSONObject("extras")?.let { s -> s.keys().forEach { k -> if (!extra.has(k)) extra.put(k, s.get(k)) } }
        return out
    }
}
