package app.kalima
import app.kalima.LocalizedText as Text
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.*

@Composable
internal fun SentenceHistoryScreen(vm:MainViewModel){
    BackHandler {vm.currentTab="grammar"}
    Column(Modifier.fillMaxSize().padding(horizontal=20.dp)){
        TextButton(onClick={vm.currentTab="grammar"}) {Text("Back",color=colorPrimaryLightFg)}
        if(vm.sentenceHistoryUndo!=null){
            Surface(color=colorPrimaryLight,shape=KalimaDesign.controlShape){
                Row(Modifier.fillMaxWidth().padding(12.dp)){
                    Text("Sentence history cleared",Modifier.weight(1f),color=colorPrimaryLightFg,fontSize=15.sp)
                    TextButton(onClick=vm::undoSentenceHistory){Text("Undo",color=colorPrimaryLightFg)}
                }
            }
        }
        if(vm.sentenceHistory.isEmpty()){
            Text("Your analysed sentences will appear here.",color=colorMuted,fontSize=17.sp,modifier=Modifier.padding(vertical=20.dp))
        }else{
            TextButton(onClick=vm::clearSentenceHistory){Text("Clear recent searches",color=colorPrimaryLightFg)}
            Text("Tap a sentence to analyse it again.",color=colorMuted,fontSize=14.sp)
            LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(vertical=16.dp)){
                items(vm.sentenceHistory.toList(),key={it}){sentence ->
                    ReadingSurface(Modifier.heightIn(min=48.dp).semantics(mergeDescendants=true) {}.clickable(role=Role.Button,onClickLabel=tr("Analyse sentence")){vm.openSentence(sentence)}) {
                        GrammarArabic(sentence,true)
                        Text("Analyse sentence",color=colorPrimaryLightFg,fontSize=14.sp)
                    }
                }
            }
        }
    }
}
