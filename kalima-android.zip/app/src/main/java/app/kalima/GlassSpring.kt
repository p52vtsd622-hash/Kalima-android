package app.kalima

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.abs

/** Same stiffness/damping and bounded substeps as the reference animation. */
internal object GlassSpring {
    fun iconCoverage(index: Int, position: Float): Float =
        ((0.65f - abs(index - position)) / 0.3f).coerceIn(0f, 1f)
    fun nearest(slot: Float): Int = floor(slot.coerceIn(0f, 3f) + 0.5f).toInt().coerceIn(0, 3)
    fun advance(position: Float, velocity: Float, target: Float, seconds: Float): Pair<Float, Float> {
        val dt = seconds.coerceIn(0f, 0.032f)
        val count = ceil(dt / 0.008f).toInt().coerceAtLeast(1)
        val h = dt / count
        var x = position
        var v = velocity
        repeat(count) { v += (460f * (target - x) - 31f * v) * h; x += v * h }
        return x to v
    }
}
