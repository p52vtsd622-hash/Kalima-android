package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/** Preview stays local; only Study invokes the existing open/search action. */
@Composable
internal fun WordPreview(arabic: String, word: Word?, vm: MainViewModel, onStudy: () -> Unit,
    onDismiss: () -> Unit, onRemove: (() -> Unit)? = null) {
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    LaunchedEffect(Unit) { keyboard?.hide(); focus.clearFocus() }
    val reduced = rememberReducedMotion()
    val lift = remember { Animatable(if (reduced) 1f else .96f) }
    LaunchedEffect(reduced) { if (reduced) lift.snapTo(1f) else lift.animateTo(1f, spring(dampingRatio = .85f, stiffness = 450f)) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().graphicsLayer { scaleX = lift.value; scaleY = lift.value },
            shape = KalimaDesign.cardShape, color = colorSurface, border = BorderStroke(1.dp, colorLine), shadowElevation = 8.dp) {
            Column(Modifier.heightIn(max = (LocalConfiguration.current.screenHeightDp * .8f).dp)
                .verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                RawText(arabic, Modifier.fillMaxWidth(), color = colorInk, fontFamily = arabicFont,
                    fontSize = 40.sp, lineHeight = 64.sp, style = TextStyle(textDirection = TextDirection.Rtl, textAlign = TextAlign.Center))
                if (word != null) {
                    if (word.pos.isNotBlank()) Text(word.pos, color = colorMuted, fontSize = 14.sp)
                    ReadingText(word.meaningEn)
                    TxLine(word.meaningTx, vm.prefs.lang)
                }
                Button(onClick = { onDismiss(); onStudy() }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colorPrimaryLightFg,
                        contentColor = if (isDark) colorSurface else androidx.compose.ui.graphics.Color.White)) { Text("Study word") }
                OutlinedButton(onClick = { vm.speak(arabic) }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = colorPrimaryLightFg)) { Text("Listen") }
                if (onRemove != null) TextButton(onClick = { onDismiss(); onRemove() },
                    colors = ButtonDefaults.textButtonColors(contentColor = colorError)) { Text("Remove") }
                TextButton(onClick = onDismiss, colors = ButtonDefaults.textButtonColors(contentColor = colorPrimaryLightFg)) { Text("Close") }
            }
        }
    }
}
