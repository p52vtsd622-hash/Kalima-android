package app.kalima

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

/** Root-list replies may be an object, a bare array, or a fenced/wrapped list.
 * Accept complete containers only: never manufacture missing text or close a
 * truncated JSON response. Normalize only the small root-list schema.
 */
internal object RootWordsReply {
    fun parse(text: String, word: String, language: String, appLanguage: String): JSONArray {
        if (text.isBlank()) throw ApiError("empty")
        for (container in containers(text)) {
            val array = try {
                if (container.startsWith("[")) JSONArray(container) else {
                    val obj = JSONObject(container)
                    if (obj.has("error") && !obj.isNull("error")) throw ApiError("model", obj.str("error"))
                    findArray(obj)
                }
            } catch (e: ApiError) { throw e }
              catch (_: Exception) { null }
            if (array != null) return normalize(array, word, language, appLanguage)
        }
        throw ApiError("invalid_json")
    }

    private fun findArray(obj: JSONObject, depth: Int = 0): JSONArray? {
        for (key in listOf("words", "results", "rootWords")) {
            when (val value = obj.opt(key)) {
                is JSONArray -> return value
                is String -> if (value.trim().startsWith("[")) {
                    try { return JSONArray(value) } catch (_: Exception) { }
                }
            }
        }
        if (depth < 2) for (key in listOf("data", "result")) {
            obj.optJSONObject(key)?.let { findArray(it, depth + 1)?.let { array -> return array } }
        }
        return null
    }

    private fun normalize(array: JSONArray, word: String, language: String, appLanguage: String): JSONArray {
        val output = JSONArray()
        val seen = mutableListOf(word)
        for (i in 0 until array.length()) {
            val source = array.optJSONObject(i) ?: continue
            fun value(key: String) = (source.opt(key) as? String)?.trim().orEmpty()
            val ar = value("ar").ifBlank { value("word") }
            val id = KalimaSearch.baseNorm(ar)
            val en = value("en")
            val main = if (appLanguage == "en") en else value("main")
            val tx = if (language == "en") en else value("tx")
            if (id.isBlank() || ar.none { it in '\u0621'..'\u064A' } || en.isBlank() || main.isBlank()) continue
            if (language != "off" && tx.isBlank()) continue
            if (seen.any { equivalent(it, ar) }) continue
            seen.add(ar)
            output.put(JSONObject().put("ar", ar).put("en", en).put("main", main)
                .put("tx", if (language == "off") "" else tx)
                .put("partOfSpeech", value("partOfSpeech").ifBlank { value("pos") })
                .put("wazn", value("wazn").ifBlank { value("pattern") })
                .put("transliteration", value("transliteration")))
            if (output.length() == 12) break
        }
        if (array.length() > 0 && output.length() == 0) throw ApiError("invalid_json")
        return output
    }

    private fun equivalent(left: String, right: String): Boolean {
        fun clean(value: String) = Normalizer.normalize(value, Normalizer.Form.NFC).replace("ـ", "").trim()
        val a = clean(left); val b = clean(right)
        if (a == b) return true
        fun vocalized(value: String) = value.any { it in '\u064B'..'\u0652' }
        // Preserve distinct vowel patterns (كَتَبَ / كُتُبٌ). An unvocalized
        // spelling can only be treated as an ambiguous duplicate.
        return (!vocalized(a) || !vocalized(b)) && KalimaSearch.baseNorm(a) == KalimaSearch.baseNorm(b)
    }

    private fun containers(text: String): Sequence<String> = sequence {
        var start = -1
        val stack = mutableListOf<Char>()
        var quoted = false
        var escaped = false
        for ((i, c) in text.withIndex()) {
            if (start < 0) {
                if (c == '{' || c == '[') { start = i; stack.add(c) }
                continue
            }
            if (quoted) {
                if (escaped) escaped = false else if (c == '\\') escaped = true else if (c == '"') quoted = false
                continue
            }
            when (c) {
                '"' -> quoted = true
                '{', '[' -> stack.add(c)
                '}', ']' -> {
                    val expected = if (c == '}') '{' else '['
                    if (stack.lastOrNull() != expected) {
                        start = -1; stack.clear(); quoted = false; escaped = false
                    } else {
                        stack.removeAt(stack.lastIndex)
                        if (stack.isEmpty()) { yield(text.substring(start, i + 1)); start = -1 }
                    }
                }
            }
        }
    }
}

internal object RootWordsRequest {
    private const val MAX_ATTEMPTS = 3
    suspend fun load(root: List<String>, word: String, language: String, appLanguage: String,
        pause: suspend (Long) -> Unit = { delay(it) }, fetch: suspend (String) -> String): JSONArray {
        val prompt = Prompts.rootWords(root, word, language, appLanguage)
        for (attempt in 0 until MAX_ATTEMPTS) {
            currentCoroutineContext().ensureActive()
            try {
                val request = if (attempt == 0) prompt else prompt + "\nThe previous reply was unreadable or incomplete. Return the complete JSON object with the exact requested keys and no surrounding text."
                return RootWordsReply.parse(fetch(request), word, language, appLanguage)
            } catch (e: CancellationException) { throw e }
              catch (e: ApiError) {
                if (e.code !in listOf("invalid_json", "empty") || attempt == MAX_ATTEMPTS - 1) throw e
            }
            pause(350L * (attempt + 1))
        }
        throw ApiError("invalid_json")
    }
}
