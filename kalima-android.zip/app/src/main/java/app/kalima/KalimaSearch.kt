package app.kalima

/** Finds real occurrences of an Arabic word (and its forms) inside bundled texts (Quran, Nahj al-Balagha).
 *  This is a direct port of the web app's search.js, kept in the same structure on purpose so the two
 *  stay easy to compare. It only ever returns text taken from the data files - it never invents anything. */
object KalimaSearch {

    private val MARKS = Regex("[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200c-\u200f\u202a-\u202e]")
    // Every pattern is compiled exactly once, here, and reused on every call - baseNorm() runs on
    // every word of the Quran and Nahj al-Balagha the first time a search happens (~190,000 calls),
    // so building a fresh Regex per call instead of reusing these was what made that first search slow.
    private val ALEF_VARIANTS = Regex("[\u0622\u0623\u0625\u0671]")
    private val ALEF_MAKSURA = Regex("\u0649")
    private val WAW_HAMZA = Regex("\u0624")
    private val YEH_HAMZA = Regex("\u0626")
    private val NON_ARABIC_LETTER = Regex("[^\u0621-\u064A]")
    private val WHITESPACE = Regex("\\s+")
    const val STRIDE = 512 // max tokens per unit (verse / passage)

    /** Normalise ordinary (standard-spelling) Arabic: no vowel marks, one alef, one yeh. */
    fun baseNorm(s: String?): String {
        val str = s ?: return ""
        var t = str
        t = MARKS.replace(t, "")
        t = ALEF_VARIANTS.replace(t, "\u0627")     // آ أ إ ٱ -> ا
        t = ALEF_MAKSURA.replace(t, "\u064A")      // ى -> ي
        t = WAW_HAMZA.replace(t, "\u0648")         // ؤ -> و
        t = YEH_HAMZA.replace(t, "\u064A")         // ئ -> ي
        t = NON_ARABIC_LETTER.replace(t, "")        // keep letters only
        return t
    }

    private val WAW_DAGGER = Regex("\u0648\u0670")
    private val HAMZA_TATWEEL = Regex("\u0640(?:\u0654([\u064E\u064F\u0650])|([\u064E\u064F\u0650])\u0654)")
    private val SMALL_YEH = Regex("\u06E7")
    private val DAGGER_ALEF = Regex("\u0670")
    private val HAMZA_ALEF_MADD = Regex("\u0621\u0627")
    private val TEH_END = Regex("\u062A$")

    /** Uthmani spelling differs from standard spelling (dagger alef, hamza seats, small yeh...).
     *  Returns several normalised readings of one Uthmani word so standard spellings can match. */
    fun quranVariants(tok: String): List<String> {
        var t = tok
        t = WAW_DAGGER.replace(t, "\u0627")                            // waw + dagger alef -> alef (الصلوٰة -> الصلاة)
        t = HAMZA_TATWEEL.replace(t) { m ->                            // hamza on tatweel: the seat letter follows its vowel
            val v = m.groupValues[1].ifEmpty { m.groupValues[2] }
            when (v) {
                "\u064E" -> "\u0627"
                "\u064F" -> "\u0648"
                else -> "\u064A"
            }
        }
        t = SMALL_YEH.replace(t, "\u064A")                             // small yeh -> yeh (إبراهيم)

        val out = LinkedHashSet<String>()
        for (v in listOf(DAGGER_ALEF.replace(t, "\u0627"), DAGGER_ALEF.replace(t, ""))) {
            var n = baseNorm(v)
            n = HAMZA_ALEF_MADD.replace(n, "\u0627")                   // ءا (Uthmani madd) -> ا (standard آ)
            if (n.isEmpty()) continue
            out.add(n)
            if (TEH_END.containsMatchIn(n)) out.add(n.dropLast(1) + "\u0629") // final ت may be standard ة (رحمت -> رحمة)
        }
        return out.toList()
    }

    fun standardVariants(tok: String): List<String> {
        val n = baseNorm(tok)
        return if (n.isNotEmpty()) listOf(n) else emptyList()
    }

    fun tokenize(text: String): List<String> = text.trim().split(WHITESPACE).filter { it.isNotEmpty() }

    /** units: one string per verse/passage. variantFn: token -> its normalised readings. */
    class Index(val tokens: List<List<String>>, val map: Map<String, List<Int>>)

    fun buildIndex(units: List<String>, variantFn: (String) -> List<String>): Index {
        val idx = HashMap<String, MutableList<Int>>()
        val toks = ArrayList<List<String>>(units.size)
        for (u in units.indices) {
            val t = tokenize(units[u])
            toks.add(t)
            var k = 0
            while (k < t.size && k < STRIDE) {
                for (v in variantFn(t[k])) idx.getOrPut(v) { ArrayList() }.add(u * STRIDE + k)
                k++
            }
        }
        return Index(toks, idx)
    }

    private val P1 = listOf("", "\u0648", "\u0641")                                                          // و ف
    private val P2 = listOf("", "\u0628", "\u0644", "\u0643", "\u0633", "\u0627\u0644", "\u0628\u0627\u0644", "\u0643\u0627\u0644", "\u0644\u0644") // ب ل ك س ال بال كال لل
    private val P2_VERB = listOf("", "\u0628", "\u0644", "\u0643", "\u0633")                                  // verbs never take the article ال
    private val SUF = listOf("", "\u0647", "\u0647\u0627", "\u0647\u0645", "\u0647\u0645\u0627", "\u0647\u0646", "\u0643", "\u0643\u0645", "\u0643\u0645\u0627", "\u0643\u0646", "\u0646\u064A", "\u0646\u0627", "\u064A")

    /** All spellings a form can take once common prefixes and pronoun endings are attached. */
    fun expandForm(form: String, looseOnly: Boolean = false, isVerb: Boolean = false): List<String> {
        val f = baseNorm(form)
        if (f.isEmpty()) return emptyList()
        if (f.length < 3 || looseOnly) return listOf(f)
        val pre2 = if (isVerb) P2_VERB else P2
        val out = LinkedHashSet<String>()
        for (suf in SUF) {
            val variants = ArrayList<String>()
            variants.add(f)
            if (suf.isNotEmpty()) {
                if (f.endsWith("\u0629")) variants.add(f.dropLast(1) + "\u062A")   // ة -> ت before an ending
                if (f.endsWith("\u064A")) variants.add(f.dropLast(1) + "\u0627")   // ى -> ا before an ending
                if (f.endsWith("\u0648\u0627")) variants.add(f.dropLast(1))         // silent alef dropped: كتبوا -> كتبوه
            }
            for (variant in variants) {
                val core = variant + suf
                for (p1 in P1) for (p2 in pre2) out.add(p1 + p2 + core)
            }
        }
        return out.toList()
    }

    data class Match(val u: Int, val toks: List<Int>, val exact: Boolean, val v: Int, val nn: Int)

    /** Find units containing any form of the word.
     *  forms: word forms (standard spelling, vowels optional).
     *  exactForms: forms that count as the word the user actually searched (ranked higher).
     *  verbForms: conjugated verb forms (they never take the article ال, which avoids false matches). */
    fun findMatches(
        index: Index,
        forms: List<String>,
        exactForms: List<String> = emptyList(),
        verbForms: List<String> = emptyList(),
        exactIsVerb: Boolean = false
    ): List<Match> {
        // LinkedHashSet, not HashSet: iteration order decides which key "claims" a shared token
        // position first (verb vs non-verb), so it must match the JS Set's insertion order.
        val keys = LinkedHashSet<String>()
        val exactKeys = HashSet<String>()
        val verbKeys = HashSet<String>()

        for (f in forms) for (k in expandForm(f)) keys.add(k)
        for (f in verbForms) for (k in expandForm(f, false, true)) { keys.add(k); verbKeys.add(k) }
        for (f in exactForms) for (k in expandForm(f, false, exactIsVerb)) {
            exactKeys.add(k); keys.add(k)
            if (exactIsVerb) verbKeys.add(k)
        }

        class Acc { val toks = LinkedHashSet<Int>(); var exact = false; var v = 0; var nn = 0 }
        val by = LinkedHashMap<Int, Acc>()
        for (key in keys) {
            val occ = index.map[key] ?: continue
            val isExact = exactKeys.contains(key)
            val isVerb = verbKeys.contains(key)
            for (o in occ) {
                val u = o / STRIDE
                val k = o % STRIDE
                val e = by.getOrPut(u) { Acc() }
                if (e.toks.add(k)) {
                    if (isVerb) e.v++ else e.nn++
                }
                if (isExact) e.exact = true
            }
        }
        return by.map { (u, e) -> Match(u, e.toks.sorted(), e.exact, e.v, e.nn) }
    }

    /** Rank: exact form first, then real verb-form hits, then other forms, then shorter units. */
    private fun score(m: Match, index: Index): Double =
        (if (m.exact) 100.0 else 0.0) + minOf(m.v, 3) * 3.0 + minOf(m.nn, 3) - index.tokens[m.u].size / 40.0

    fun rank(matches: List<Match>, index: Index): List<Match> =
        matches.sortedWith(compareByDescending<Match> { score(it, index) }.thenBy { it.u })
}
