package app.kalima

import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.URI
import java.security.MessageDigest

internal data class UpdateRelease(val versionCode: Long, val versionName: String, val apkUrl: String,
    val sha256: String, val size: Long, val minSdk: Int, val notes: String)

/** Untrusted release metadata must pass these checks before any APK is downloaded. */
internal object UpdatePolicy {
    const val MAX_APK_BYTES = 100L * 1024 * 1024
    fun repositoryValid(repo: String) = repo.matches(Regex("[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*"))
    fun parse(text: String, repository: String, installedCode: Long, sdk: Int): UpdateRelease? {
        require(repositoryValid(repository) && text.toByteArray().size <= 65536)
        val j = JSONObject(text)
        require(j.getInt("schema") == 1 && j.getString("packageName") == "app.kalima")
        val code = j.getLong("versionCode")
        require(code > 0)
        val version = j.getString("versionName").also { require(it.matches(Regex("[0-9][A-Za-z0-9._-]{0,49}"))) }
        val checksum = j.getString("sha256").lowercase().also { require(it.matches(Regex("[0-9a-f]{64}"))) }
        val size = j.getLong("size").also { require(it in 1..MAX_APK_BYTES) }
        val minSdk = j.getInt("minSdk").also { require(it >= 24) }
        val url = j.getString("apkUrl")
        val uri = URI(url)
        val prefix = "/$repository/releases/download/latest/"
        require(uri.scheme == "https" && uri.host == "github.com" && uri.port == -1 && uri.userInfo == null && uri.query == null && uri.fragment == null)
        require(uri.rawPath.startsWith(prefix) && uri.rawPath.removePrefix(prefix).matches(Regex("Kalima-[A-Za-z0-9._-]+\\.apk")))
        val notes = j.optString("notes", "").also { require(it.length <= 4000) }
        return if (code <= installedCode || minSdk > sdk) null else UpdateRelease(code, version, url, checksum, size, minSdk, notes)
    }
    fun trustedTransport(url: String): Boolean = runCatching {
        val u = URI(url)
        u.scheme == "https" && u.userInfo == null && u.port == -1 &&
            (u.host == "github.com" || u.host in setOf("release-assets.githubusercontent.com", "objects.githubusercontent.com", "github-releases.githubusercontent.com"))
    }.getOrDefault(false)
    fun copyVerified(input: InputStream, output: OutputStream, release: UpdateRelease,
        checkCancelled: () -> Unit = {}, progress: (Int) -> Unit = {}) {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(32768)
        var total = 0L
        while (true) {
            checkCancelled()
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) continue
            total += count
            require(total <= release.size && total <= MAX_APK_BYTES) { "Unexpected update size" }
            digest.update(buffer, 0, count); output.write(buffer, 0, count)
            progress((total * 100 / release.size).toInt())
        }
        require(total == release.size) { "Incomplete update" }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        require(MessageDigest.isEqual(actual.toByteArray(), release.sha256.toByteArray())) { "Update checksum mismatch" }
    }
}
