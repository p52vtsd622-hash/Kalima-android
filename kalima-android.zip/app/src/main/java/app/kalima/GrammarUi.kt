package app.kalima

import app.kalima.LocalizedText as Text
import androidx.compose.material3.Text as RawText
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.*

@Composable
internal fun LearnScreen(vm: MainViewModel) {
    val tabs = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeChip("Saved words", vm.learnMode == "saved") { vm.learnMode = "saved" }
            ModeChip("Practice", vm.learnMode == "practice") { vm.learnMode = "practice" }
        }
        Box(Modifier.weight(1f)) {
            tabs.SaveableStateProvider(vm.learnMode) {
                if (vm.learnMode == "saved") SavedScreen(vm) else PracticeScreen(vm)
            }
        }
    }
}

/** Formal i'rab is content in Arabic, independent of the translated app chrome. */
@Composable
internal fun GrammarArabic(value: String, prominent: Boolean = false) {
    RawText(value, Modifier.fillMaxWidth(), color = if (prominent) colorPrimaryLightFg else colorInk,
        fontFamily = arabicFont, fontSize = if (prominent) 28.sp else 21.sp,
        lineHeight = if (prominent) 48.sp else 36.sp,
        textAlign = TextAlign.Right, style = TextStyle(textDirection = TextDirection.Rtl))
}

@Composable
internal fun GrammarScreen(vm: MainViewModel) {
    val state = vm.grammar
    var view by rememberSaveable { mutableStateOf("grammar") }
    val language = vm.prefs.appLanguage
    LaunchedEffect(language, state.submitted, view) { if(view == "words" && state.submitted != null) vm.sentenceWords() }
    val grammarScroll = rememberScrollState()
    val wordsScroll = rememberScrollState()
    val scroll = if(view == "words") wordsScroll else grammarScroll
    val scope = rememberCoroutineScope()
    LaunchedEffect(state.submitted) { if(state.submitted!=null) { grammarScroll.scrollTo(0); wordsScroll.scrollTo(0) } }
    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Row(Modifier.fillMaxWidth().semantics { selectableGroup() }, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("words" to "Words", "grammar" to "Grammar").forEach { (value,label) ->
                FilterChip(selected = view == value, onClick = { view = value },
                    label = { Text(label) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp).springPress(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(50),
                    colors = FilterChipDefaults.filterChipColors(containerColor = colorSurface, labelColor = colorInk,
                        selectedContainerColor = colorPrimary, selectedLabelColor = colorPrimaryFg))
            }
        }
        if(view == "words" && state.submitted != null) {
            SentenceWordsContent(vm)
        } else {
        if (state.result == null && !state.loading && state.error == null) {
            ReadingSurface {
                Text("Understand the whole sentence", color = colorInk, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Text("Type or paste an Arabic sentence below. Switch between word meanings and Arabic grammar.", color = colorMuted, fontSize = 16.sp)
                Spacer(Modifier.height(16.dp))
                GrammarArabic("كَتَبَ الطَّالِبُ الدَّرْسَ.", prominent = true)
                TextButton(modifier = Modifier.springPress(), onClick = { state.edit("كَتَبَ الطَّالِبُ الدَّرْسَ.") }) { Text("Use this example", color = colorPrimaryLightFg) }
                Text("AI-generated analysis. More than one grammatical reading may be possible.", color = colorMuted, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text("Use up to 40 words and 600 characters.", color = colorMuted, fontSize = 14.sp)
            }
        }
        if (state.loading) {
            ReadingSurface {
                GrammarArabic(state.query)
                SectionRequestFeedback(true, null, "Analysing sentence…", {})
                TextButton(onClick = state::cancel) { Text("Cancel", color = colorPrimaryLightFg) }
            }
        }
        state.error?.let { message ->
            SectionRequestFeedback(false, tr(message), "", vm::retrySentenceGrammar)
        }
        state.result?.let { result ->
            ReadingSurface {
                Text("Grammar", color = colorPrimaryLightFg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                GrammarArabic(result.original, prominent = true)
                TextButton(modifier = Modifier.springPress(), onClick = { vm.speak(result.original) }) { Text("Listen", color = colorPrimaryLightFg) }
                Text("AI-generated analysis. More than one grammatical reading may be possible.", color = colorMuted, fontSize = 14.sp)
            }
            ReadingSurface {
                Text("Sentence structure", color = colorInk, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, modifier = Modifier.semantics { heading() })
                Spacer(Modifier.height(8.dp)); GrammarArabic(result.overview)
            }
            result.rows.forEach { item ->
                ReadingSurface {
                    GrammarArabic(item.text, prominent = true)
                    Spacer(Modifier.height(6.dp)); GrammarArabic(item.analysis)
                }
            }
            if (result.clauses.isNotEmpty()) {
                ReadingSurface {
                    ExpandableResultSection("Phrases and clauses", initiallyExpanded = true) {
                        result.clauses.forEachIndexed { index, item ->
                            if (index > 0) { HorizontalDivider(color = colorLine); Spacer(Modifier.height(12.dp)) }
                            GrammarArabic(item.text, prominent = true); GrammarArabic(item.analysis)
                            Spacer(Modifier.height(12.dp))
                        }
                    }
                }
            }
            if (result.alternatives.isNotEmpty()) {
                ReadingSurface {
                    ExpandableResultSection("Possible readings", initiallyExpanded = true) {
                        result.alternatives.forEach { GrammarArabic(it); Spacer(Modifier.height(12.dp)) }
                    }
                }
            }
            TextButton(onClick = vm::retrySentenceGrammar) { Text("Analyse again", color = colorPrimaryLightFg) }
        }
        }
        Spacer(Modifier.height(8.dp))
    }
}
