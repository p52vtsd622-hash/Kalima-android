# Android regex regression check

Run `python3 verification/check_android_regex.py` on a host with the ICU shared libraries installed. It reads the actual Kotlin production constant, compiles it with ICU, then compiles and matches each generated message template across all seven catalogs. This check catches an incompatibility that JVM tests miss: OpenJDK accepts an unescaped closing brace, while Android uses ICU and rejects it.

This is a native ICU compatibility check, not an Android emulator or physical-phone launch test. Keep running the normal Gradle unit tests and release checks as well.
