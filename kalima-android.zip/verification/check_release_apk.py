import re,shutil,sys
from pathlib import Path
badging,apk,out=Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])
line=badging.read_text().splitlines()[0]
m=re.search(r"package: name='([^']+)' versionCode='([0-9]+)' versionName='([^']+)'",line)
assert m and m[1]=='app.kalima', 'Wrong package: never publish the Test APK to the main feed'
code=int(m[2]);version=m[3]
assert code>=8 and re.fullmatch(r'[0-9][A-Za-z0-9._-]{0,49}',version)
min_sdk=int(re.search(r"^sdkVersion:'([0-9]+)'",badging.read_text(),re.MULTILINE)[1])
assert min_sdk>=24
asset=f'Kalima-{version}-{code}.apk'
out.mkdir(exist_ok=True);shutil.copy2(apk,out/asset)
for name,text in [('asset-name',asset),('version-code',str(code)),('version-name',version),('min-sdk',str(min_sdk))]:
 (out/(name+'.txt')).write_text(text)
