import json,sys
from pathlib import Path
old,new=map(Path,sys.argv[1:]);latest=json.loads(new.read_text())
if old.exists():
 previous=json.loads(old.read_text())
 assert latest['versionCode']>=previous['versionCode'], 'Refusing to publish an older main build'
 if latest['versionCode']==previous['versionCode']:
  assert latest['sha256']==previous['sha256'], 'Increase versionCode before publishing a changed APK'
print('Release version guard passed')
