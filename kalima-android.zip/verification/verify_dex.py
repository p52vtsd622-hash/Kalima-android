"""Reject malformed DEX payloads before publishing an otherwise signed APK."""
import hashlib,struct,sys,zipfile,zlib
with zipfile.ZipFile(sys.argv[1]) as apk:
 names=[n for n in apk.namelist() if n.endswith('.dex')]
 assert names, 'APK has no bytecode'
 for name in names:
  data=apk.read(name)
  assert data[:4]==b'dex\n' and len(data)>=112, name
  assert struct.unpack('<I',data[32:36])[0]==len(data), f'{name}: wrong file size'
  assert data[12:32]==hashlib.sha1(data[32:]).digest(), f'{name}: wrong SHA-1 signature'
  assert struct.unpack('<I',data[8:12])[0]==zlib.adler32(data[12:])&0xffffffff, f'{name}: wrong Adler32 checksum'
 print(f'Bytecode integrity passed for {len(names)} DEX files')
