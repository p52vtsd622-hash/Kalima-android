"""Check localization startup regexes against native ICU, as used by Android.
Run with Python 3 and the ICU shared libraries installed. No phone or AI service
is contacted. This supplements JVM tests, whose OpenJDK regex syntax differs.
"""
from pathlib import Path
import ctypes
import ctypes.util
import json
import re

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'app/src/main/java/app/kalima/Localization.kt').read_text()
literal = re.search(r'PLACEHOLDER_PATTERN\s*=\s*("(?:[^"\\]|\\.)*")', source)
assert literal, 'Cannot find the production placeholder pattern'
placeholder = json.loads(literal.group(1))
name = ctypes.util.find_library('icui18n')
if not name:
    raise SystemExit('Native ICU is required for this Android regex regression check.')
icu = ctypes.CDLL(name)

def function(name):
    for suffix in [''] + ['_' + str(x) for x in range(100, 49, -1)]:
        try:
            return getattr(icu, name + suffix)
        except AttributeError:
            pass
    raise RuntimeError('ICU regex API is unavailable')

open_regex = function('uregex_open')
open_regex.restype = ctypes.c_void_p
open_regex.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int32)]
close_regex = function('uregex_close')
close_regex.argtypes = [ctypes.c_void_p]
set_text = function('uregex_setText')
set_text.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_int32)]
matches = function('uregex_matches')
matches.restype = ctypes.c_int8
matches.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_int32)]

def encoded(s):
    b = s.encode('utf-16-le')
    return ctypes.create_string_buffer(b), len(b) // 2

def compile_pattern(pattern):
    data, length = encoded(pattern)
    status = ctypes.c_int32(0)
    handle = open_regex(data, length, 32, None, ctypes.byref(status))
    return handle, status.value

def check(pattern, sample=None):
    handle, status = compile_pattern(pattern)
    assert status <= 0 and handle, f'ICU rejected {pattern!r}: {status}'
    try:
        if sample is not None:
            data, length = encoded(sample)
            status = ctypes.c_int32(0)
            set_text(handle, data, length, ctypes.byref(status))
            assert status.value <= 0
            assert matches(handle, 0, ctypes.byref(status)) and status.value <= 0, sample
    finally:
        close_regex(handle)

# Establish the regression on this engine; production must use the fixed form.
old, old_status = compile_pattern(r'\{[0-9]+}')
if old:
    close_regex(old)
check(placeholder, '{12}')
assert re.split(placeholder, 'App language: {0}') == ['App language: ', '']

catalog = json.loads((ROOT / 'app/src/main/assets/ui-translations.json').read_text())
count = 0
for language, table in catalog.items():
    for key in table:
        if '{0}' not in key:
            continue
        # Same Pattern.quote semantics as Kotlin Regex.escape; test the final
        # generated pattern as well as the placeholder splitter itself.
        quote = lambda s: r'\Q' + s.replace(r'\E', r'\E\\E\Q') + r'\E'
        pattern = '^' + '(.*?)'.join(quote(p) for p in re.split(placeholder, key)) + '$'
        sample = re.sub(placeholder, 'Français (اردو) + ✨', key)
        check(pattern, sample)
        count += 1
print(json.dumps({'engine': name, 'production_placeholder': placeholder,
    'old_pattern_icu_error': old_status, 'languages': len(catalog),
    'generated_template_checks': count, 'status': 'passed'}, indent=2))
