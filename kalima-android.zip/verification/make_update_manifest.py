"""Create release metadata after the APK has passed signing/package verification."""
import argparse, hashlib, json, re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repository',required=True);p.add_argument('--apk',type=Path,required=True)
p.add_argument('--version-code',type=int,required=True);p.add_argument('--version-name',required=True)
p.add_argument('--min-sdk',type=int,required=True)
p.add_argument('--output',type=Path,required=True);p.add_argument('--notes',type=Path,required=True)
a=p.parse_args()
assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*',a.repository)
assert a.min_sdk>=24
assert a.version_code>0 and re.fullmatch(r'[0-9][A-Za-z0-9._-]{0,49}',a.version_name)
assert re.fullmatch(r'Kalima-[A-Za-z0-9._-]+\.apk',a.apk.name)
notes=a.notes.read_text().strip();assert len(notes)<=4000
size=a.apk.stat().st_size;assert 0<size<=100*1024*1024
meta=dict(schema=1,packageName='app.kalima',versionCode=a.version_code,versionName=a.version_name,minSdk=a.min_sdk,
 apkUrl=f'https://github.com/{a.repository}/releases/download/latest/{a.apk.name}',size=size,
 sha256=hashlib.sha256(a.apk.read_bytes()).hexdigest(),notes=notes)
a.output.write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
