# Kalima 1.0 — main Android release

This production project includes the approved Test 22 spring motion, Test 23 sentence Grammar and combined Learn section, Test 24 Words results, and the new sentence history. It preserves the existing Kalima colours, layout, icons, languages and features.

## Upload from your phone

1. Upload the supplied **kalima-android.zip** to the root of **p52vtsd622-hash/Kalima-android**, replacing the existing ZIP. Keep its exact name. Do not extract or repack it.
2. Commit the replacement on main. The existing **Build Kalima APK** workflow runs automatically; alternatively run it from Actions.
3. Wait for the workflow to finish successfully. It publishes the signed APK and update feed to the existing latest release.

The existing .github/workflows/build.yml is compatible and unchanged. Keep all four existing KALIMA signing secrets. The workflow signs the APK using the permanent Kalima key and generates update metadata for that exact APK. Do not manually upload the local verification manifest.

## Updates and existing data

Production identity: app.kalima, versionName 1.0, versionCode 10. It upgrades the published main 0.9 / code 9 while preserving main-app data. Kalima Test remains a separate app; its data is not automatically imported.

Once GitHub successfully publishes the release, main installations with the existing updater can see Update / Later on their next online opening. Uploading the source ZIP alone does not publish an update. Installation still requires Android user confirmation. Later postpones the prompt until another opening.

## Sentence history

The sentence screen now has the same clock icon as Lookup. It keeps up to 60 recent successfully analysed sentences separately from word history. Tap an entry to analyse it again online. Clear offers Undo. History stores sentence queries, not complete offline results; differing vowel marks remain distinct.

Grammar explanations remain Arabic. Words meanings follow the selected app language, with simple Arabic explanations for Arabic users. Saved words and practice are together in Learn. Test 22 motion and reduced-motion support are retained.

See VALIDATION.md and RELEASE-NOTES.txt. This package has been built locally; no GitHub upload or release publication has been performed on your behalf.
