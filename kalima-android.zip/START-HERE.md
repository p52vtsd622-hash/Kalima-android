# Kalima 0.9 — approved breathing-room layout

This is the main Kalima project: application ID **app.kalima**, label **Kalima**, versionName **0.9**, versionCode **9**. It includes the approved Test Revision 21 layout: slimmer bottom controls, roomier result sections, and the scrolled word in the existing header instead of a separate word/Listen strip. Main 0.8's features and updater remain. The separate Test app and its data remain separate.

Upload **kalima-android.zip** to your existing GitHub repository root and replace your actual **.github/workflows/build.yml** with the supplied **build.yml**. Keep the project zipped. Merely uploading the ZIP does not replace the repository's outer workflow. Keep one active Kalima build workflow and the same four permanent signing secrets. Read Kalima-Setup.md for the phone-friendly steps.

GitHub builds the distributable APK and injects its repository address into the updater. The source ZIP has no private signing key, provider key or GitHub credential. Upload the ZIP as **kalima-android.zip**, keeping it zipped with no extra enclosing folder. The required verification directory is included and the workflow now checks the archive layout before building.

## Updates for friends

The GitHub workflow embeds its own public repository address, builds and verifies the signed main APK, then publishes a version-specific APK, the convenient Kalima.apk download and update.json to the existing `latest` release. Metadata is uploaded last so it never intentionally announces an APK that has not been uploaded.

Kalima checks this feed on foreground reopening, quietly if offline. A newer compatible version shows Update/Later. Later lasts until the next reopening; changing app language/recreating the activity does not count as a new session. Settings > About > Check for updates performs a manual check. Updates show progress and published release notes, validate file size/SHA-256 plus package/version/signing identity, then request Android installation. Android confirmation is required. On Android 8+, the first in-app install may require allowing this source in system settings; it resumes the installer after permission is granted. Cancelling the download or installer leaves the current app usable.

The repository's release assets must be public so friends do not need a GitHub account. The workflow stops release publishing if the repository is private, retaining the signed APK in the run artifact. Do not embed access tokens in the app. If you want to keep source private, use a separate public distribution repository with an appropriate publishing setup instead.

The live feed was checked on 30 October 2026 and was serving main 0.8 (code 8). After the new workflow finishes successfully and publishes 0.9 (code 9), friends already on main 0.8 can see Update/Later when next opening or returning to Kalima online. It is a foreground app check; no background push notification is sent. Android requires confirmation to install. Later defers the prompt until the next foreground opening.

Anyone still on a version older than 0.8 needs the GitHub-built APK shared manually once to gain the updater. Install over main Kalima without uninstalling. Test and main packages never update each other. Saved words, settings and review data use the same storage names. Keep the original four signing secrets; no reinstall or data reset is part of this update.

## Future releases

Keep **app.kalima** and the same permanent signing key. Increase versionCode beyond every previously distributed main build and update versionName/About/catalog branding. Update RELEASE-NOTES.txt (up to 4,000 characters). The workflow derives APK filenames and metadata from the built APK automatically. Reusing a version code with different APK content is rejected at publication. The current code 8 is higher than the supplied main version 0.7/code 7; if you have distributed a later main build outside this conversation, increase it before building.

Shared access retains the existing Cloudflare service configuration; no Worker change accompanies this port. Backups/import, existing saved-word languages and review progress remain supported. App language defaults to English, with Arabic/Urdu/Farsi/Turkish/Russian/French available. Home Extra translation remains independent.

For reproducible checks use Java 17, SDK 34, Gradle 8.9, the four KALIMA signing environment variables and KALIMA_UPDATE_REPOSITORY=owner/repository. Run `python3 verification/check_android_regex.py` and `gradle testReleaseUnitTest assembleRelease`. Builds without an update repository are development-only and show an unavailable message on manual update checking. See VALIDATION.md for completed checks and the first live-update test still required.
