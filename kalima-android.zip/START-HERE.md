# Kalima — continuing updates to your main app

This project is now **Kalima**, with the original Android identity `app.kalima`. Version 0.6 has version number 6. It includes the combined features and the web app's colours, fonts and spacing.

## Permanent signing key now prepared

A new permanent signing key has been prepared, because the original installed-app key was not available. The separately supplied **Kalima.apk** uses this key. The separately supplied **Kalima-Private-Signing-Backup.zip** contains its backup and the four text files to paste into GitHub Actions secrets. Keep that ZIP private and safe; it is intentionally excluded from this project.

Read **Kalima-Setup.md** in this project for the complete, no-code setup: export saved words first, add four GitHub secrets, replace your existing workflow, and upload **kalima-android.zip**. You may need one reinstall to transition from your old app. Future builds using these secrets can update the new installation normally.

Android accepts updates only with a matching signing key. This newly prepared key has not been matched to the old app. Do not uninstall your old app until your saved-words backup is safe. Settings and account credentials may need to be entered again after reinstalling.

## Future changes

Every future project update should keep the name **Kalima**, the identity `app.kalima`, and the same signing key, while increasing its version number. Upload the updated ZIP as before; signing setup does not need repeating. This project does not auto-install updates: download each new APK and tap it to update.

For the next assistant or developer: never add an applicationIdSuffix or a Preview variant. Increase versionCode above all previously distributed main-app builds. Both debug and release builds accept the same four KALIMA signing environment variables. Local builds without these variables are for development only and must not be distributed as app updates.

## What was combined

- Root, morphological pattern, meanings, examples and grammar analysis.
- Fast and Deep analysis, plus reverse search from English, Urdu, Persian, Turkish and Russian.
- Separate saved translations for Urdu, Persian, Turkish and Russian; add another translation without repeating the entire lookup.
- Common words from the same root, with meanings and links to look them up.
- Qur'an and Nahj al-Balagha examples from the bundled text, with references, highlighting, full-passage expansion and more results.
- On-demand 14-pronoun, seven-column verb conjugations; cached for offline use.
- Listening to words, sentences, conjugation cells and flashcards using Android's Arabic voice.
- Saved-word filtering across Arabic, transliteration, English and saved translations.
- Flashcards, both quiz directions and spaced repetition; an explicit “Practice all words” option when nothing is due.
- Downloadable JSON backups, backup import and CSV export in both Settings and Saved Words.
- Eight recent searches, kept separately from Saved Words.
- Native lookup from Arabic text selected in other Android apps.
- Light, dark and automatic appearance; Amiri, Amiri Quran, Instrument Sans, Noto Nastaliq Urdu and Vazirmatn included inside the app.

## Existing words and backups

Backups from both supplied versions are supported. Importing a word already saved fills in missing translations, conjugations and cached root words without replacing your existing definition or resetting review progress. Existing translations in the same language are kept.

Old Android results did not record which language their translation used. When you open one, you may see a question asking you to identify its language. Tap the correct language once. This avoids accidentally labelling an Urdu translation as Persian, or vice versa.

Offline: saved details, downloaded translations, downloaded conjugations, flashcards, quizzes, and searches in the bundled texts remain usable. New AI lookups, new translations and new root-word lists need internet. Pronunciation also needs an installed Arabic voice; download the voice in your phone's text-to-speech settings if necessary.

## Building locally

The Gradle wrapper is included. Use Java 17 and Android SDK 34. Checks: `./gradlew testDebugUnitTest assembleDebug`. Set the four KALIMA signing environment variables before producing an installable update. No private signing key, account passcode or personal API key is included.

## Accuracy

AI-generated explanations and conjugations still need linguistic judgment. Corpus quotations come from the bundled text files.
