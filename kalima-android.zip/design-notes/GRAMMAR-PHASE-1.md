# Sentence grammar design and acceptance

Audience: Arabic learners who need to understand the grammatical relationships in a sentence. Preserve Kalima's quiet reading layout, green/cream palette, script fonts and existing search/nav geometry.

Apple Design Skill references, translated to Android Compose:
- layout.md › Visual hierarchy: “Use progressive disclosure to make layouts cleaner and easier to interact with.” Formal rows remain readable; longer phrase/clause and alternative-reading sections expand with the existing Test 22 section springs.
- search-fields.md › Best practices: “Use placeholder text to help people know what they can search for.” The same existing BasicTextField now advertises sentences only on the Grammar destination. Submission is explicit because it sends an AI request.
- tab-bars.md › Best practices: “Use a tab bar to support navigation, not to provide actions.” Grammar occupies the previous Practice position; saved and practice content share Learn with internal choices. Existing bookmark icon remains for Learn; the new SVG depicts linked sentence units.
- generative-ai.md › Transparency: “Communicate where your app uses AI.” Disclosure appears before submission and above results. Original text is preserved; uncertainty/alternative readings are requested; the parser does not certify linguistic accuracy.
- accessibility.md › Cognitive and Motion best practices: retain Android animation-off behavior, cancellation and gesture continuity from Test 22. Arabic explanations use the original Arabic font, scalable sp and RTL text direction independently of the app language.

Test on a physical Android phone:
1. Install over Test 22; verify saved words, review progress and preferences survive. Verify main Kalima is separate.
2. Grammar: fill the example, press arrow/keyboard action, check original sentence and Arabic-only i'rab. Test nominative/accusative/genitive, nominal sentences, negation, weak verbs, attached pronouns, one-word imperatives, unvocalized/ambiguous text and longer sentences.
3. Try an isolated noun and incomplete fragment; check recoverable feedback. Try Latin input and over-limit input; check no request is sent.
4. Cancel, Clear or edit during loading; verify no old response appears. Switch to Lookup during a request, then return; word query/results must stay independent.
5. Switch app language through all seven choices: chrome translates, formal analysis stays Arabic. Check RTL, dark mode, large text, TalkBack and keyboard/insets.
6. Learn: switch Saved/Practice, preview/open a word, remove/Undo, flip/swipe cards, quiz and Home due-review shortcut. Confirm review progress persists.
7. Test Test 22 springs on sheets, navigation, pills and expandable grammar sections, including Remove animations.

Phase 2 will add Words as the second view of the same query: contextual word/phrase meanings in the app language, with simple Arabic explanations when Arabic is selected. No non-working Words tab is exposed in phase 1.
