# Kalima 1.0 validation

- Signed production `testReleaseUnitTest assembleRelease` succeeded with Java 17, Gradle 8.9 and Android SDK 34.
- 147 unit tests passed: zero failures, errors or skipped tests, including three sentence-history policy and persistence-format tests.
- Release lint-vital checks passed. Full lint and a new physical-device test were not performed for this release.
- APK package app.kalima; versionName 1.0; versionCode 10; minimum SDK 24; target SDK 34. Release identity check rejects a debug/test APK.
- APK signature verified against the permanent Kalima certificate. Bytecode integrity passed for both DEX files.
- Packaged language catalog matches the current source. All seven language catalogs have matching keys; ICU template validation passed.
- Existing GitHub workflow is byte-for-byte unchanged and its required project paths are present at the ZIP root.
- Existing public update feed was read: app.kalima 0.9 / code 9. Generated local code-10 metadata passed the version guard. GitHub will generate its own metadata for its build.

The grammar, Words, Learn and motion features were accepted by the user in prior test builds. The newly added sentence-history UI still needs device confirmation. Check the clock icon, persistence after reopening, tapping an entry, Clear / Undo and independence from Lookup history.

GitHub Actions and OTA installation have not been run for this release yet. Publication occurs only after the user uploads the source ZIP and the workflow succeeds.
