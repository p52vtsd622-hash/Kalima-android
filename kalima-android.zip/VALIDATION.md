# Validation — Kalima 0.7

This version changes shared-access credentials, optional personal-key selection, Settings layout, service error messages and version numbers.

- Static source checks completed: no passcode UI or request header; default shared route accepts no key; personal settings retained; package app.kalima unchanged; versionCode increased from 6 to 7.
- Seven regression tests added in AccessPolicyTest.kt for fresh installs, empty personal-key fallback, personal routing, saved-but-disabled keys, missing server address, allowance messaging and hiding provider details. Existing 17 tests retained.
- A Gradle test run was attempted but stopped before compilation because this environment could not download Gradle 8.9 (network unreachable). No tests or Android compile are claimed to have passed for version 0.7. The included working GitHub workflow runs release tests and builds the APK.
- No APK was generated or delivered. The permanent signing secrets remain unchanged and outside this archive.
- No device UI or live account request checks completed for this version.
- The Cloudflare Worker is not included. Shared requests now have no X-Passcode header. If the deployed Worker still enforces that header, shared lookups require its corresponding change before this version is distributed.
