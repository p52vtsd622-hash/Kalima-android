# Validation — Kalima main 0.9 (code 9)

Main 0.9 merges the user-approved Test Revision 21 layout into the main 0.8 source, preserving the updater, main identity and saved data. The test and web apps remain separate.

## Completed checks

- Java 17 / SDK 34 / Gradle 8.9 signed release build passed: testReleaseUnitTest, assembleRelease and lint-vital. Full lint was not run.
- 113 JVM tests passed, with no failures, errors or skipped tests: the original 95 feature tests plus 18 update-policy tests. The approved layout itself was reviewed by the user in Test Revision 21.
- Seven catalogs have 316 matching keys. Android ICU regression passed 189 generated template checks. The localized About version is 0.9; packaged catalog bytes match the source.
- APK metadata is app.kalima, Kalima, versionCode 9, versionName 0.9, min SDK 24, target SDK 34. It uses the original permanent certificate SHA-256 b3015109ce8b212b6549381ef0b274b0954f22e382a064b06481135928b84500; v2 signature verifies. Both DEX payloads passed file-size, SHA-1 and Adler32 integrity.
- The validation build embeds p52vtsd622-hash/Kalima-android. Its generated update.json references the version-specific main APK, with matching bytes, size and SHA-256. The version guard accepts 9 over the live feed's 8.
- The public update feed and its current 0.8 APK were retrieved on 30 October 2026. The feed serves version 0.8 / code 8. The published updater URL pattern was also inspected. Local JVM tests validate the compatible newer-main release path and reject Test packages, wrong repositories, malformed metadata and untrusted files.
- Workflow YAML and run-script shell syntax were checked. The main ZIP is flat at its root, includes all required verification scripts, and includes the exact separately supplied build.yml. Archive layout is now checked before building. Metadata publication remains last, after the signed APK upload.
- No private signing material, provider keys, SDK-local files, compiled APK, build output or cache directory is in the source ZIP.

## Update behavior and rollout

GitHub must finish the build and publish the release before an update is discoverable. Existing main 0.8 users get Update/Later when foregrounding Kalima online. Later defers until the next foreground opening. The app downloads only after Update is chosen, verifies file/package/version/signing identity, then asks Android to install. Android confirmation and, where needed, install-source permission are still required. No closed-app push notification is sent.

Versions older than main 0.8 do not have this updater and need one manual installation of the new GitHub-built main APK. Test and main packages do not update one another. Keep the permanent signing secrets and install over the existing main app, without uninstalling or clearing saved data.

No repository push, GitHub Actions run or 0.9 release publication has been performed here. The locally built main APK is used for validation; the distributable APK should be produced by the supplied GitHub workflow. An end-to-end 0.8-to-0.9 installation on a physical device remains a rollout check. The user's approval establishes the layout in Test Revision 21, not independent on-device validation of the main APK.
