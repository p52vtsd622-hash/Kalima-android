# Validation of this combined version

- Main Android build: successful. Package `app.kalima`, label `Kalima`, version `0.6`, versionCode `6`.
- Release build signed successfully with the new permanent Kalima key. Its certificate matches the private signing backup. The supplied Kalima.apk uses this key. This key has not been matched to the old installation; a one-time reinstall may be needed after exporting saved words.
- 17 release automated checks passed, with no failures or errors.
- The previous full lint run reported 0 errors; this edit only changes app identity, version and build/signing configuration.
- Release APK signature verified (v2, valid for the minimum Android version). Label Kalima, package app.kalima and versionCode 6 were checked in the packaged APK.
- GitHub builds without signing settings stop with a clear error. No replacement key is generated.
- The 17 checks were rerun successfully after a clean build with the permanent key.
- Qur'an and Nahj al-Balagha datasets remain byte-for-byte identical to the supplied files: 6,236 verses and 1,754 passages.

The tests cover old Android and web backup formats, translation-language separation, unknown-language migration, duplicate import preservation, matching translated examples to the correct source sentence, conjugation migration, JSON round trips, UTF-8 CSV output, review intervals, Fast-mode prompts, Uthmani spelling, Arabic prefixes and suffixes, verb/noun separation and result ranking.

Live AI requests were not exercised: the supplied archives contain no account passcode or personal API key. Pronunciation depends on the phone's installed Arabic voice. Final testing on the user's own phone is still needed.
