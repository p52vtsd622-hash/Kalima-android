# Revision 18 — Home, search and continuation

All seven proposed Home changes are implemented together. Apple Design references used: searching, search fields, layout, buttons, materials, motion and accessibility. Native Android Compose controls and the existing palette remain the implementation language.

1. The header is compact, names the current screen and exposes Clear only for an active Home search/result. History remains a labeled accessible icon.
2. Save belongs to the displayed word. Arabic/reverse search remains one explicit menu, Fast/Deep moves into Search options, and Extra translation remains directly accessible.
3. The suggested word keeps the existing native pager and timeline. Arabic may wrap, Listen speaks the visible word, and physical previous/next arrows remain alternatives to swiping. Reentering the unfocused body retains the current suggestion position; actual Home refresh events still create a new timeline.
4. One continuation module prioritizes due review, otherwise showing three recent searches. Review opens a fresh due flashcard session, including after a prior quiz/all-cards session.
5. Focus replaces the body with a local search surface. Close, Back, tab changes and keyboard dismissal restore the regular view. The existing incoming fade respects reduced motion. Typing does not animate the entire results surface anew on every character.
6. Local saved-word matching removes combining marks, tatweel and invisible format characters for matching only; Arabic/Persian letter variants and French accents are normalized. Exact Arabic and prefixes rank before definition matches. Full displayed Arabic and distinct vocalized entry identities are preserved. Six results maximum; explicit selection/search invokes existing actions.
7. Language context explicitly distinguishes Arabic plus the app language from optional Extra. Arabic-only mode shows Arabic once. Settings continues to control App language and excludes no supported app language.

New labels are translated offline in all seven catalogs. No provider request runs from query edits, matching or idle continuation display. No new permissions, dependencies or data format.

Phone review: narrow screens, large fonts, keyboard show/hide and hardware Back, both lookup modes, matching Arabic/Latin/cached translations, saved-match opening, due review, Listen and reverse suggestion navigation; all seven languages, RTL, dark mode and animation scale off. Automated checks cannot establish frame rate or visual/touch quality on a phone.
