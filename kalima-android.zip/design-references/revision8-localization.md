# Revision 8 — language and reading direction

Apply the Apple Design skill's typography, right-to-left and accessibility guidance to the existing Android Compose app. Reading order follows the selected app language; original Arabic remains Arabic and optional translations retain their own script. Use the existing Arabic/Urdu fonts, sufficient RTL line height and scrollable language choices with native endonyms. Language is a persistent Settings choice; the home control selects an additional content translation.

The existing navigation and flashcard direct-manipulation controls retain their physical direction with explicit localized labels. Standard interface text and accessibility descriptions share an offline catalog. A missing content translation gets an explicit localized download state rather than mislabelled English. Native framework locale is updated with app language and the activity is recreated after sheet dismissal.

Automated catalog and policy checks support implementation correctness; phone testing and native-speaker review remain necessary for layout and language quality. No claim of live AI or device validation is made.
