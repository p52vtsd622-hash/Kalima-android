# Revision 15 — final Apple Design phase

Kalima remains an Arabic study tool: preserve its word-first reading hierarchy, script fonts, cream/emerald surfaces and signature orange navigation lens. Implement the final four agreed changes with Android Compose conventions.

References read from the Apple Design skill:

- loading.md › Best practices: “Show something as soon as possible.” Static placeholder blocks immediately reserve a useful reading shape while the genuine status remains visible. Blocks are decorative and hidden from TalkBack; no simulated words, shimmer, percentage or completion estimate is shown. Stop, navigation and individual Retry actions remain available.
- motion.md › Providing feedback: “Aim for brevity and precision in feedback animations.” The incoming content uses a 140 ms fade. There is one active screen, with no crossfade copy of outgoing controls or duplicated composition effects. Navigation and search controls stay fixed. Live Android animation-off changes immediately expose content and suppress the new fade/lookup spinner.
- undo-and-redo.md › Best practices: “Help people predict the results of undo and redo as much as possible.” A visible global Undo surface names the removed word or cleared history. Each successful saved-word deletion snapshots the complete entry; Undo preserves translations and review scheduling. Multiple changes unwind in reverse order. Dismiss clears the chain; undo is session-only and ends when the process closes. No automatic timeout forces a reading-speed decision. This surface adapts the principle to Android rather than importing iOS shake/three-finger gestures.
- playing-haptics.md › Best practices: “Make haptics optional.” A labeled Settings switch defaults off. Native View haptic feedback plays only for a committed dock selection, confirmed local save, or successful Undo. There are no drag-preview, loading, retry, failed-save or automatic-background haptics. The framework respects system haptic settings; no vibrator permission or custom waveform is added.

Layout, typography, accessibility, color, feedback, designing-for-ios and cross-platform references informed the existing visual/accessibility constraints. Palette and type choices remain those documented for Revisions 12/14. Motion timing, placeholder shape, undo presentation and specific haptic event selection are implementation judgments.

Persistence safeguards: a failed deletion creates no undo record; failed restoration keeps its record. An entry re-saved after deletion is not overwritten by an older snapshot. Restored history is deduplicated, preserves searches made after clearing and retains the existing eight-word limit. Disk persistence remains the existing saved-store format. Session undo snapshots stay in the ViewModel across configuration recreation and are not a backup format.

No phone/emulator visual, touch, TalkBack or physical-haptic review was available. Verify all seven languages and large text on device, particularly the Undo surface and reduced-motion behavior. See VALIDATION.md for the automated checks actually completed.
