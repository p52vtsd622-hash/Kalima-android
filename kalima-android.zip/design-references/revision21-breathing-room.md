# Revision 21 — quieter controls and one reading header

The result screen's job is to make Arabic and its explanation easy to read. Keep Kalima's cream/emerald palette, original icons and orange navigation lens; let the word and explanation dominate over the controls. This is an Android Compose implementation informed by Apple design principles, retaining Android touch semantics.

At normal text size the dock's nominal height drops from 208dp to 168dp. The search field is 48dp instead of 56dp, with a 36dp send circle inside its 48dp target. The navigation surface is 48dp instead of 60dp; its lens is 40dp, with 23/21dp icons. Pills have 36dp visible surfaces inside 48dp touch rows, with 12sp labels. All four equal-width controls and their existing bottom sheets stay. Dock outer vertical padding drops from 12dp to 6dp per side; the gaps become 4/8dp. Colors and their previously verified contrast roles remain.

The original header has a 56dp minimum instead of 64dp. Once the result has scrolled past the existing threshold, the Arabic word replaces Translations in that same header. There is no second overlaid word/Listen surface. Tapping the header word returns to the top (immediately with reduced motion); Listen remains with the main word. The scroll state is hoisted so the header observes the same position as the result. Word changes reset that position. The word-motion anchor follows the visible presentation, retaining source-return behavior.

Result sections have 24dp separation instead of 16dp, and shared reading surfaces use 20dp internal padding instead of 16dp. Body text, Arabic study typography, meanings, section contents and default expanded states remain. This trades a little scroll length for clearer grouping while reclaiming persistent screen space from controls.

References read from the Apple Design skill:

- layout.md › Visual hierarchy: “Group related items to clearly express related information or functions.” More space separates meaning, grammar and root groups.
- toolbars.md › Best practices: “Choose items deliberately to avoid overcrowding.” Removing the duplicate pinned surface avoids a second strip of controls.
- accessibility.md › Vision: “Support larger text sizes.” Height constraints are minima; text continues to use sp and script-aware leading.
- cross-platform.md › Conventions to check: Android uses 48dp targets. Smaller visible surfaces retain those targets.
- motion.md › Best practices: “Add motion purposefully, supporting the experience without overshadowing it.” Existing navigation and save feedback remain; no new scroll-triggered entrance animation is added.

The dimensions are app-specific judgments, not Apple-mandated Android metrics. The user approved the Revision 21 test APK, and this layout is now merged into main 0.9. The main package, permanent signing identity and updater remain. The web app is unchanged. This main source archive is intended for the existing GitHub build workflow.
