# Apple Design polish roadmap

Keep Kalima's cream/emerald identity, Arabic fonts, orange navigation signature and existing features. Adapt the skill's principles to Android Compose.

## Phase 1 — Revision 12

1. Reading hierarchy: Arabic word and primary meaning first; grammatical details and root information below; consistent body styles and script-aware leading.
2. Spacing/surfaces: 20 dp outer inset, 16 dp card inset, 24 dp major group spacing, 16 dp result-card gaps, 20 dp surface radius and 12 dp control radius. Use quiet borders without extra shadows or glass on reading content.
3. Grouped Settings: General (App language and Appearance), personal key, backups, Advanced and About. Show selected values, wrap rows at narrow widths/large text, retain language selection and all existing actions.

## Phase 2 — Revision 14

4. Search focus, input and keyboard interaction.
5. Saved/history row layout and press feedback.
6. Conjugation table alignment and readability.

## Phase 3 — Revision 15

7. Stable loading placeholders.
8. Gentle screen/result transitions.
9. Deletion with Undo.
10. Optional, restrained haptics.

Dark-mode, RTL, text scaling and accessibility checks apply throughout. This roadmap records the agreed three/three/four grouping; All ten changes are implemented across Revisions 12, 14 and 15. Phone verification remains necessary for each release.
