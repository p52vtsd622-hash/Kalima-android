# Revision 12 — reading hierarchy, surfaces and Settings

Thesis: make the word and its meaning the first things a learner reads, then reveal linguistic depth in consistent groups. Keep Kalima's established fonts, cream/emerald palette and navigation identity.

References read from the Apple Design skill:

- typography.md › Conveying hierarchy: “Adjust font weight, size, and color as needed” to express hierarchy.
- layout.md › Visual hierarchy: “Group related items” and use alignment and progressive disclosure.
- settings.md › Best practices: “Put general, infrequently changed settings in your custom settings area.” Preserve the existing Android appearance preference.
- accessibility.md › Vision and Mobility: readable scaling, sufficient contrast and comfortable controls.

The word hero is 58 sp, while primary prose uses 20 sp Latin, 24 sp Arabic, 22 sp Urdu or 20 sp Farsi. Supporting prose uses 17/21/19/18 sp respectively. Line-height multipliers are 1.55 Latin, 1.7 Arabic, 2.2 Urdu and 1.8 Farsi. These are implementation choices, not Apple-prescribed Android values. Arabic vowel marks and Nastaliq need space above and below the glyphs.

Reading surfaces share 16 dp padding, 20 dp corners and a quiet 1 dp border; result cards use 16 dp gaps and Settings groups use 24 dp gaps. Navigation, flashcard gestures, suggestion swiping and sheet geometry retain their specialized dimensions. Native content remains readable in its original script and is not passed through the UI-string catalog by the new prose component.

Settings value rows have a 64 dp minimum height, merge their labels and values for accessibility, and stack at content widths under 340 dp or font scales above 1.25. Disclosures announce expanded/collapsed state. The personal-key switch shares a single labeled, tappable row. API keys remain masked and unsaved key text is not persisted through recreation.

Measured existing palette contrast: muted #6A7A71 on white 4.53:1; muted #828683 on dark surface #1B1D1C 4.59:1; dark ink #E0E2E0 on that surface 13.01:1. Selected-value/action text uses the existing stronger foreground #335C41 in light mode and #8AB89B in dark mode (7.64:1 and 7.59:1 against their reading surfaces). Root tiles retain large white Arabic letters on the original green fill; they grow with font scale and the root row scrolls horizontally when needed. Text-button colors preserve the framework's disabled-state treatment.

No Android emulator or physical-device rendering was available. Compilation, catalog checks and package inspection support implementation correctness; they do not establish layout at 200% text, TalkBack behavior or visual quality on a phone. Phone review must cover all seven languages, the Settings disclosures, long meaning text and a large Arabic root/word.
