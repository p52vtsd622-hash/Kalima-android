# Revision 19 — Restore the familiar action row

Revision 19 restores the four equal-width pills above search: animated Save/Saved, Ar Word/Reverse, Fast/Deep and the selected extra translation language/Off. Fast/Deep again opens its compact menu; language opens the existing dedicated extra-translation sheet. The mixed-width text/icon controls and result-adjacent Save are removed. All other Revision 18 Home/search/continuation/suggestion improvements remain.

This is a targeted visual correction requested by the user. Existing colors, spacing (8 dp), equal widths, 48 dp minimum pill targets and compact localized labels are reused. Save retains its existing successful-write feedback and optional haptic; no result means Save is disabled. The header, focused local search, continuation card, language rules, Listen, suggestion timeline, root recovery and Undo are unchanged.

Check on phone: all four pills on a single aligned row; Save/Unsave/Undo, reverse toggle, Fast/Deep menu and extra-language sheet; dark mode, RTL and large text. No phone rendering or performance claims.
