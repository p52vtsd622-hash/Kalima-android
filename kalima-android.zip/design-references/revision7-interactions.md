# Revision 7 — result exploration and practice

Thesis: keep the Arabic word and meaning readable, progressively reveal linguistic depth, and make practice feel directly controlled by the student. Retain Kalima's cream/emerald surfaces, orange navigation signature and bundled Arabic/Urdu fonts. No new colour or type family.

References read from Apple Design Skill: hig-lookup.md; disclosure-controls.md > Best practices; sheets.md > Best practices and Mobile; gestures.md > Best practices and Custom gestures; motion.md > Providing feedback; loading.md > Best practices and Showing progress; accessibility.md, layout.md, typography.md, color.md, designing-for-ios.md and cross-platform.md.

Android adaptation uses Material ModalBottomSheet rather than Apple APIs. The sheet scrolls, marks selected language and has a Close control plus native dismissal. Native-script labels allow 44 sp line height for Urdu. Section headers have 48 dp minimum height, state descriptions and top-anchored expansion. New prose uses existing 15–18 sp styles; headings use 20–22 sp. No glass on reading content.

Timing choices are ours: expansion 220 ms/collapse 180 ms; flip 300 ms; grading exit 160 ms. Arabic faces counter-rotate so the back remains readable. Both faces are measured for a stable card height; only the visible face is exposed to screen readers. Explicit reveal and grading buttons supplement gestures. The physical left/right grading directions are labelled and do not depend on script direction. Review writes are checked before advancing.

Requests remain cached as before and are only initiated by the same explicit actions. Retrying affects one request. Changing word/language or clearing invalidates pending requests and clears errors. New UI animations do not generate AI requests. Corpus loading is local and gets its own retry.

Limits: JVM tests can exercise swipe thresholds and existing data/request policies, but cannot establish gesture dispatch or perceived smoothness on a phone. No live account or physical-device testing is claimed.
