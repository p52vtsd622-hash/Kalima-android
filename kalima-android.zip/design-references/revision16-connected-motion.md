# Revision 16 — connected reading motion, Phase 1

Thesis: preserve a learner's place as a word moves from a list into its explanation, then keep the word available while reading. Kalima keeps its Arabic font families, cream/emerald reading surfaces and orange lens.

References read from the Apple Design skill:

- motion.md › Providing feedback: “Strive for realistic feedback motion that follows people’s gestures and expectations.” A word travels from its measured list position to its measured detail position, and can return to its source. One active screen remains; a decorative Canvas word is the only overlay. Font size and line height interpolate while Arabic is remeasured with the real font, preserving glyph shape and vowel marks. A critically damped spring (stiffness 420) controls travel. Missing destinations expire; wrapped words and uncached history use the normal fade. New actions interrupt old motion, and Clear/word changes cancel stale travel. Back returns to the originating saved/history tab while that route remains valid.
- undo-and-redo.md › Best practices: “Show the results of an undo or redo.” A restored saved word scrolls into view, clearing a filter that excludes it, and receives a 2 dp emerald outline for 1.4 seconds. Review and translation data still use the Revision 15 snapshot logic. Saved/history items use stable keys and placement springs (damping .86, stiffness 420), with 140/100 ms entry/exit fades. Reduced motion uses immediate placement and reveal scrolling.
- liquid-glass.md › The two layers: custom material remains in floating controls/navigation. The original lens geometry, continuous finger tracking, active-ink clipping, colors and icons remain. The new contact shadow and narrow edge highlight share the existing bounded Canvas; no background capture, blur dependency or continuous animation is added. High contrast and reduced motion suppress the additions.
- layout.md › Visual hierarchy and accessibility.md informed the fixed reading controls. A compact word header appears once the large word scrolls away, retains a visible Listen action, and offers a labeled Back to top action. Original Arabic remains selectable by accessibility semantics and does not pass through UI translation. The word overlay is hidden from TalkBack. A 12 dp edge fade marks the reading boundary without covering dock controls.

Exact spring settings, thresholds and timings are implementation choices rather than Apple-prescribed Android values. No new motion is added to practice numbers, flashcard drag depth, long-press previews or language selection in this phase.

No Android emulator or physical phone was available for visual/touch/TalkBack/large-font checks. See VALIDATION.md for actual automated checks and the phone checklist.
