# Further Apple Design refinement roadmap

The original ten-item roadmap is complete. This is the subsequent eight-item plan agreed in two phases of four.

## Phase 1 — Revision 16

1. Word-to-detail transitions: cached saved/history word movement and a reverse return when its source row is available. Wrapped or uncached entries use the existing fade.
2. Spring-driven list movement: keyed saved/history items animate placement; Undo reveals and briefly outlines a restored saved word.
3. Scroll-responsive word header: compact word/Listen/Back to top while reading long results, with an unobtrusive scroll edge.
4. Refined glass navigation: restrained contact depth and top-edge sheen; original geometry, colors, icon clipping and direct drag tracking remain.

## Phase 2 — Revision 17

5. Long-press word previews.
6. More tactile flashcard dragging.
7. Animated practice numbers.
8. Spring-settled language-sheet selection.

All additions must retain script shaping, RTL, font scaling, reduced motion and accessible controls. Physical-device validation is required for appearance and interaction.

Revision 17 also replaces expandable explanation/Settings down-arrow font glyphs with a rounded native vector chevron. Both phases are implemented; phone validation is required.
