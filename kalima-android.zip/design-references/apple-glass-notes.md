# Revision 5 — navigation motion and glass treatment

Goal: preserve Kalima's four icons and orange palette while making the shared highlight feel attached to touch. Android/Kotlin Compose implementation, inspired by the supplied HTML and the installed Apple Design Skill. This is a custom shading approximation, not Apple's native material or true backdrop refraction.

References consulted:
- hig-lookup.md — routing table.
- liquid-glass.md, The two layers and Review checklist: keep glass in navigation; limit effects; provide readable icons and reduced-motion/contrast treatment.
- motion.md, Providing feedback: follow gestures and expectations; keep feedback brief, precise and interruptible.
- tab-bars.md, Best practices: retain stable destinations and selected-state semantics.
- accessibility.md, layout.md, typography.md, color.md, materials.md, designing-for-ios.md and cross-platform.md: translate principles to Android, rather than imposing Apple-specific conventions.

Implementation choices (our judgments, not numerical Apple specifications):
- Stop the settling spring on initial finger contact, before the 3 dp swipe threshold. No movement on an off-centre grab.
- Use continuous finger coordinates during dragging. Select the nearest destination only on release; cancellation returns to the current destination.
- Keep spring stiffness 460, damping 31 and bounded 8 ms integration substeps, matching the HTML.
- Soften decorative stretch from 20% to 10%, add 2.5% contact expansion, and ease only these decorative values. Position is not eased while dragging.
- Reveal active icon ink at the exact lens outline instead of fading an entire icon based on its distance to tab centres.
- Keep the 46 dp visual pill within 48 dp touch targets. Preserve icons, fonts, orange fill and the existing dock layout.
- In light appearance use the existing dark navigation ink on the orange lens: nominal contrast 5.79:1, compared with 2.76:1 for white. Dark appearance keeps white active ink (3.43:1 nominal before shading).
- Observe Android animation-off and high-text-contrast preferences while running. Disable gloss and deformation for either, keep direct manipulation and provide an opaque fill. No expensive blur or new dependency.

Limits: reference principles do not provide the touch implementation or exact animation settings. Unit tests cannot prove touch dispatch or physical-device frame smoothness. Real phone testing is still required.
