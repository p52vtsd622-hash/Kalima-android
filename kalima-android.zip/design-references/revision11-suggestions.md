# Revision 11 — swipeable suggestions

Apple Design references read: gestures.md › Best practices and Custom gestures (responsive direct manipulation and more than one input); motion.md › Providing feedback (predictable motion, brief transitions, cancellable motion). Apply these principles through Android Compose HorizontalPager. Existing cream/emerald surfaces and Arabic type remain.

Swiping directly moves a page; native pager settling determines whether a short drag changes pages. Visible previous/next controls supplement the gesture and have localized accessibility labels and 48 dp touch targets. Arrow navigation jumps immediately under the existing reduced-motion preference. Physical direction is stable in RTL interfaces; Arabic words keep RTL text direction. No autoplay or decorative bounce. A localized hint makes swiping discoverable.

Each position retains its original suggestion until the next Home refresh. Fresh suggestions are local, drawn from a shuffled pool; only tapping performs an existing lookup. Changing direction traverses history. Foregrounding, returning Home and Clear reset browsing; only the last displayed word is persisted to avoid an immediate repeat after a cold restart.

Automated tests validate the model and compiled refresh hooks. No physical-device touch, TalkBack, large-text or visual motion validation is claimed.
