# Revision 20 — Pill sheets and complete History vector

Revision 20 keeps the four equal-width action pills and opens Arabic word/Reverse search and Fast/Deep choices in native sliding bottom sheets, with Close, Back, outside-tap and drag dismissal. A shared sheet gate prevents overlapping pickers; selection applies immediately and closes with the native sheet animation. The History icon now includes the previously missing lower circular outline, with rounded stroke ends and joins. All other Home features remain.

Both new pickers reuse the translation sheet treatment: rounded top corners, drag handle, 64 dp minimum selectable rows, spring radio indicator, pending selection and duplicate-close guard. Existing translated labels are reused in all seven languages. Native system animation scaling is retained. No data format, request trigger or language policy changes.

History is a 24 by 24 native vector with its outline inside 2–22 units including stroke, in the existing accessible 48 dp IconButton. The previous geometry only drew the upper arc; this corrects the geometry rather than resizing the header.

Phone review: sheet entrance/exit, choice update and rapid taps; dismiss using Close, Back, outside and drag; History outline at normal size in both themes, RTL and large text.
