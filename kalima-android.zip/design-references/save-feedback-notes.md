# Experiment 2 — Save feedback

References: Apple Design Skill, buttons.md > Best practices (include a press state); sf-symbols.md > Animations (Replace, Bounce and Draw On); motion.md > Providing feedback (brief, precise, interruptible); feedback.md > Best practices (integrate feedback into the interface); accessibility.md and cross-platform.md (Android semantics, 48 dp targets and reduced motion).

Android adaptation: use the established emerald colours and type, a small bookmark/check icon, clear Save/Saved text, and one brief success response. These exact timings and shapes are implementation choices, not Apple requirements. Draw the check with the existing Compose graphics tools rather than importing Apple artwork. No paid service or additional AI request.

Success is confirmed from saved-entry state after the existing save operation. A failed write retains its existing error message and does not celebrate. State feedback also remains available without animation, including a screen-reader description and an action label.
