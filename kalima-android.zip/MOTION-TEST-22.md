# Kalima Test 22 — native spring motion

Reference: approved Android 0.9 main source. Test application ID: app.kalima.test. Main Kalima and the web app are unchanged.

## Compatibility

Kalima uses Kotlin, Jetpack Compose and Material 3, not a WebView or React Native. motiondivision/motion targets JavaScript, React and Vue and cannot be used as a native Compose dependency. No JavaScript runtime, WebView or Motion package was introduced. Native Compose spring animation is the appropriate implementation here.

## Changes

- Expandable result sections use critically damped size springs; the existing visibility transition reverses from its current progress rather than remounting content.
- Explanation-card resizing uses the same 420 stiffness / 1.0 damping spring.
- Search and practice actions gain subtle press/release feedback. Home pills and Save press/release use restrained 700 stiffness / 0.82 damping springs. Hit targets, labels, colors and actions stay the same.
- Language, extra translation, reverse search and Fast/Deep sheets use native Compose dialogs with one shared drag/settle offset. Handle gestures cancel settling immediately; content nested scrolling hands downward motion to the sheet when the list reaches the top. Release uses distance and velocity; upward release returns the sheet. Close, outside tap and Android Back remain available.
- Navigation keeps fractional finger tracking and existing geometry. Release retains bounded measured velocity; changing targets continues the running spring.
- Android's animator-duration scale of zero disables decorative motion. Explicit finger-driven sheet/navigation positioning remains available. Turning this setting on during settling snaps to the intended state.

## Design references

Apple Design Skill: motion.md › Best practices, “Let people cancel motion.” accessibility.md › Cognitive recommends tracking motion directly with gestures and reducing spring bounce. Sheets and buttons references guide reversible interaction and accessible alternatives. These principles are applied using Android APIs; no colors, icons, typography or content layout were redesigned.

## On-device acceptance checks

1. Install over Kalima Test 21. Main Kalima should remain separately installed. Export a backup before testing.
2. Rapidly expand/collapse Sentences, Verb details and nested conjugations. Reverse midway; watch for snapping or clipped final content.
3. Open all four sheets. Catch an opening sheet by its handle, reverse a drag, release upward/downward and scroll the language list before dragging at its top. Test Back, Close and outside tap.
4. Press/cancel the pills by moving off them; verify no unintended action. Tap Save repeatedly and check the final saved state.
5. Drag the navigation across all tabs, reverse and catch it while settling; the lens must stay attached to your finger.
6. Enable Accessibility → Remove animations (or Developer options → Animator duration scale → Off). Repeat the above and confirm actions still work immediately. Check large text, RTL and dark mode.

Physical-device gesture feel and TalkBack must be checked on the test APK. Automated compilation/tests do not certify those interactions.
